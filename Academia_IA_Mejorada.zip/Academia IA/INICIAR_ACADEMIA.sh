#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/academia_dinero_v2"
if command -v node >/dev/null 2>&1; then
  node server.js
elif command -v python3 >/dev/null 2>&1; then
  echo 'Abrí http://localhost:8000 en tu navegador'
  python3 -m http.server 8000 --bind 127.0.0.1
else
  echo 'Necesitás Node.js o Python 3 para iniciar Academia IA.' >&2
  exit 1
fi
