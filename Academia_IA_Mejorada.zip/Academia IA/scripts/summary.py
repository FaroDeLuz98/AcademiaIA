﻿import os,json
os.chdir('estudiar - copia')
for i in range(1,10):
    try:
        exec(open(f'data_l{i}.py',encoding='utf-8').read())
        data = locals()[f'L{i}']
        print(i, len(data.get('parts',[])), len(data.get('exam',[])), data.get('name'))
    except Exception as e:
        print('err',i,e)
