# -*- coding: utf-8 -*-
"""
Patch Academia del Dinero.html with:
1. Pistas (hint button, max 3 hints per session)
2. Resumen (summary button)
3. Salto de niveles (click locked level to take comprehensive skip exam of all prior levels)
4. Shuffle options in the raw LEVELS data so correct answers are not always option 0.
"""
import os, re, json, random

random.seed(42)

for filepath in ['Academia del Dinero.html', os.path.join('estudiar - copia', 'Academia del Dinero.html')]:
    if not os.path.exists(filepath):
        continue
    print(f"Patching {filepath}...")
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update startRun to initialize hints and summary
    old_startrun = """function startRun(opts) {
  // Preparar preguntas con barajado dinámico de opciones
  const preparedQs = (opts.qs || []).map(q => prepareQuestion(q));
  R = {
    ...opts,
    qs: preparedQs,
    i: 0,
    sel: [],
    checked: false,
    res: []
  };"""

    new_startrun = """function startRun(opts) {
  // Preparar preguntas con barajado dinámico de opciones
  const preparedQs = (opts.qs || []).map(q => prepareQuestion(q));
  R = {
    ...opts,
    qs: preparedQs,
    i: 0,
    sel: [],
    checked: false,
    res: [],
    hintsUsed: 0,
    maxHints: 3,
    hintShown: false,
    showSummary: false
  };"""

    if old_startrun in content:
        content = content.replace(old_startrun, new_startrun)
        print("  Applied startRun patch.")

    # 2. Add hint and summary buttons to renderQ
    old_renderq_buttons = """      <div style="margin-top:16px">
        <button class="btn tq" ${R.sel.length ? '' : 'disabled'} onclick="${isExam ? 'nextExamQ()' : ch ? 'nextQuizQ()' : 'checkAnswer()'}">"""

    new_renderq_buttons = """      <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap">
        ${R.hintsUsed < R.maxHints && !R.hintShown ? `<button class="btn g" onclick="useHint()">💡 Pista (${R.maxHints - R.hintsUsed} restantes)</button>` : (R.hintsUsed >= R.maxHints && !R.hintShown ? `<span class="mu" style="font-size:12px">Sin pistas restantes (máx 3)</span>` : '')}
        <button class="btn g" onclick="toggleSummary()">📋 Resumen</button>
      </div>
      ${R.hintShown ? `<div class="card" style="background:#282312;border:1px solid #f59e0b;color:#fde68a;margin-top:10px;padding:10px 14px">💡 <b>Pista:</b> ${q.c ? 'Concepto clave: ' + q.c : (q.e ? q.e.slice(0, 100) + '...' : 'Revisá la teoría de este bloque')}</div>` : ''}
      ${R.showSummary ? renderSummaryBox() : ''}

      <div style="margin-top:16px">
        <button class="btn tq" ${R.sel.length ? '' : 'disabled'} onclick="${isExam ? 'nextExamQ()' : ch ? 'nextQuizQ()' : 'checkAnswer()'}">"""

    if old_renderq_buttons in content:
        content = content.replace(old_renderq_buttons, new_renderq_buttons)
        print("  Applied renderQ buttons patch.")

    # 3. Add useHint, toggleSummary, renderSummaryBox, askSkipLevel
    helper_funcs = """
/* ---- FUNCIONALIDADES: PISTAS, RESUMEN Y SALTO DE NIVELES ---- */
function useHint() {
  if (!R || R.hintsUsed >= R.maxHints) return;
  R.hintsUsed++;
  R.hintShown = true;
  renderQ();
}

function toggleSummary() {
  if (!R) return;
  R.showSummary = !R.showSummary;
  renderQ();
}

function renderSummaryBox() {
  if (!R) return '';
  if (R.mode === 'skip_exam') {
    const priorLevels = LEVELS.slice(0, R.lvl - 1);
    return `
      <div class="card" style="background:#151b3a;border:1px solid #3b4e7a;margin-top:10px;padding:12px 16px">
        <div class="row" style="justify-content:space-between;margin-bottom:6px">
          <b>📋 Resumen de todos los niveles anteriores (1 a ${R.lvl - 1})</b>
          <button class="btn g" style="font-size:11px;padding:2px 8px" onclick="toggleSummary()">Cerrar</button>
        </div>
        <div style="max-height:220px;overflow:auto">
          ${priorLevels.map(lvl => `
            <div style="margin-bottom:8px">
              <strong style="color:var(--tq)">Nivel ${lvl.id}: ${lvl.name}</strong>
              <ul style="padding-left:18px;margin:3px 0;font-size:12.5px">
                ${lvl.parts.map(p => `<li><b>${p.title}</b>: ${p.quiz.map(q => q.c).slice(0, 3).join(', ')}</li>`).join('')}
              </ul>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
  const lvlId = R.lvl || 1;
  const L = LEVELS[lvlId - 1];
  if (!L) return '';
  return `
    <div class="card" style="background:#151b3a;border:1px solid #3b4e7a;margin-top:10px;padding:12px 16px">
      <div class="row" style="justify-content:space-between;margin-bottom:6px">
        <b>📋 Resumen · Nivel ${L.id}: ${L.name}</b>
        <button class="btn g" style="font-size:11px;padding:2px 8px" onclick="toggleSummary()">Cerrar</button>
      </div>
      <ul style="padding-left:18px;margin:6px 0;font-size:13.5px">
        ${L.parts.map((p, idx) => `
          <li style="margin:4px 0">
            <b>Bloque ${idx + 1}: ${p.title}</b>
            <div class="mu" style="font-size:12.5px">${p.quiz.map(q => q.c).filter((v, i, a) => a.indexOf(v) === i).slice(0, 3).join(', ')}</div>
          </li>
        `).join('')}
      </ul>
    </div>
  `;
}

function askSkipLevel(targetLvlId) {
  const targetLvl = LEVELS[targetLvlId - 1];
  const priorLevels = LEVELS.slice(0, targetLvlId - 1);
  if (!priorLevels.length) {
    alert("El Nivel 1 ya es el nivel inicial.");
    return;
  }
  const ok = confirm(`¿Deseás rendir el examen integrador para saltear directamente al Nivel ${targetLvlId} (${targetLvl.name})?\\n\\nEste examen contiene preguntas combinadas de todos los niveles anteriores (Niveles 1 a ${targetLvlId - 1}) y necesitás 80% para aprobar.`);
  if (!ok) return;

  const pool = [];
  priorLevels.forEach(lvl => {
    pool.push(...lvl.exam);
  });
  const sampled = shuffle(pool).slice(0, Math.min(15, pool.length));
  startRun({
    qs: sampled,
    mode: 'skip_exam',
    lvl: targetLvlId,
    priorLevelsCount: priorLevels.length,
    title: `Examen Integrador de Salto al Nivel ${targetLvlId}`
  });
}
"""

    if "function useHint()" not in content:
        content = content.replace("function pickOpt(idx) {", helper_funcs + "\nfunction pickOpt(idx) {")
        print("  Added helper functions.")

    # 4. Update nextQuizQ and nextExamQ to reset hintShown
    old_nextquiz = """    R.i++;
    R.sel = [];
    R.checked = false;
    saveActiveSession();
    renderQ();"""
    new_nextquiz = """    R.i++;
    R.sel = [];
    R.checked = false;
    R.hintShown = false;
    R.showSummary = false;
    saveActiveSession();
    renderQ();"""
    if old_nextquiz in content:
        content = content.replace(old_nextquiz, new_nextquiz)
        print("  Updated nextQuizQ.")

    old_nextexam = """    R.i++;
    R.sel = [];
    saveActiveSession();
    renderQ();"""
    new_nextexam = """    R.i++;
    R.sel = [];
    R.hintShown = false;
    R.showSummary = false;
    saveActiveSession();
    renderQ();"""
    if old_nextexam in content:
        content = content.replace(old_nextexam, new_nextexam)
        print("  Updated nextExamQ.")

    # 5. Update finishExam to handle skip_exam unlocking prior levels
    old_finishexam = """  if (pass && !e.passed) {
    gain += 100; // 100 XP por aprobar por primera vez
    e.passed = true;
  }"""
    new_finishexam = """  if (pass && !e.passed) {
    gain += 100; // 100 XP por aprobar por primera vez
    e.passed = true;
  }
  if (R.mode === 'skip_exam' && pass) {
    for (let l = 1; l < R.lvl; l++) {
      S.exams[l] = S.exams[l] || {};
      S.exams[l].passed = true;
      S.exams[l].best = Math.max(S.exams[l].best || 0, pct);
      for (let p = 0; p < 3; p++) {
        S.parts[`${l}-${p}`] = 1;
      }
    }
  }"""
    if old_finishexam in content and "R.mode === 'skip_exam'" not in content:
        content = content.replace(old_finishexam, new_finishexam)
        print("  Updated finishExam for skip_exam.")

    # 6. Update home() to enable clicking locked level for skip
    old_home_node = """        <div class="node ${s}" tabindex="0" onclick="${s === 'locked' ? '' : `go('level',{l:${L.id}})`}" onkeydown="if(event.key==='Enter')this.click()">
          ${L.icon}${ic ? `<small>${ic}</small>` : ''}
        </div>
        <div class="lbl">${L.id}. ${L.name}</div>"""

    new_home_node = """        <div class="node ${s}" tabindex="0" onclick="${s === 'locked' ? `askSkipLevel(${L.id})` : `go('level',{l:${L.id}})`}" onkeydown="if(event.key==='Enter')this.click()" title="${s === 'locked' ? 'Rendir examen para saltear a este nivel' : ''}">
          ${L.icon}${ic ? `<small>${ic}</small>` : ''}
        </div>
        <div class="lbl">${L.id}. ${L.name}</div>
        ${s === 'locked' ? `<button class="btn g" style="font-size:11px;padding:3px 8px;margin-top:4px" onclick="askSkipLevel(${L.id})">⚡ Saltear</button>` : ''}"""

    if old_home_node in content:
        content = content.replace(old_home_node, new_home_node)
        print("  Updated home() level nodes.")

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

print("Done patching HTML files!")
