﻿import fs from 'fs';
const raw = JSON.parse(fs.readFileSync('academia_dinero_v2/src/moneyCourse.json', 'utf8'));
const out = 'export const economicsCourseDefinition = ' + JSON.stringify(raw) + ';\n';
fs.writeFileSync('academia_dinero_v2/src/economicsCourseData.js', out, 'utf8');
console.log('levels', raw.levels.length, 'bytes', out.length);
