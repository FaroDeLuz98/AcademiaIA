﻿# -*- coding: utf-8 -*-
import os, json, re

os.chdir('estudiar - copia')

levels_out = []

for i in range(1, 10):
    try:
        exec(open(f'data_l{i}.py', encoding='utf-8').read())
        data = locals()[f'L{i}']
    except Exception as e:
        raise
    
    level_blocks = []
    for pidx, part in enumerate(data.get('parts', [])):
        b_id = f'add-l{i}-b{pidx+1}'
        theory_html = part.get('theory', '')
        # Convert theory HTML to structured form - put full HTML as paragraphs or extract simply
        # The new engine's getTheoryViewModel expects paragraphs/examples etc; but in our app's theoryHTML it just displays vm.paragraphs/examples etc.
        # Looking at how it's used - in app.js theoryHTML does vm.paragraphs.map(p=><p></p>) etc. Also it takes the raw structure.
        # But easier to just put the whole HTML content as a single paragraph or store as-is? Let us look up - vm.paragraphs come from theory.paragraphs. 
        # The demo course puts plain text paragraphs. But the original has rich HTML. We need to preserve content.
        # Maybe store the HTML in paragraphs as a single string? Or split - but easier to adapt. Let us look up how the UI renders.
        # In theoryHTML: vm.paragraphs mapped as <p></p> - so they get escaped. That would break HTML. Also it has cases/examples separately.
        # But the original HTML has tags. That's a problem. Let us look up the actual rendering again.
        # Looking at app.js: m.paragraphs.map((p) => \<p></p>\) - so paragraphs are escaped as text. That can't render HTML. That means we need to convert HTML to plain text or restructure.
        # But the requirement says "recuperar también su contenido educativo completo" and "conservar su contenido original". 
        # Maybe the UI needs to be updated to support HTML content? Let us look up the full requirements again - "Al entrar en uno, deben aparecer los tres bloques de teoría y quizzes" - similar structure to original.
        # But the new engine/UI was built for the demo format. We need to make it compatible. Let us look up how theoryHTML is used more closely.
        # Also in the demo, paragraphs are plain strings. Maybe we should put the HTML as a single paragraph string but render it differently? Or better, update the renderer to use innerHTML for HTML content if it contains tags.
        # That would be better to preserve formatting. Let us check - easier to modify the renderer.
        block = {
            'id': b_id,
            'order': pidx + 1,
            'title': part.get('title', f'Bloque {pidx+1}'),
            'theory': {
                'title': part.get('title', f'Bloque {pidx+1}'),
                'paragraphs': [theory_html],  # store full HTML
                'examples': [],
                'cases': [],
                'formulas': [],
                'procedure': [],
                'code': None
            },
            'quiz': {
                'id': b_id + '-quiz',
                'questions': []
            }
        }
        # convert quiz questions
        for qidx, qq in enumerate(part.get('quiz', [])):
            qid = f'add-l{i}-b{pidx+1}-q{qidx+1}'
            options = []
            # old format: o is list of strings, a is list of correct indices
            for oidx, opt in enumerate(qq.get('o', [])):
                options.append({'id': chr(ord('a')+oidx), 'text': opt})
            correct_idx = qq.get('a', [0])[0] if qq.get('a') else 0
            correct_id = chr(ord('a')+correct_idx)
            block['quiz']['questions'].append({
                'id': qid,
                'type': 'mcq',
                'prompt': qq.get('t', ''),
                'options': options,
                'correctOptionId': correct_id,
                'explanation': qq.get('e', ''),
                'relatedConcept': qq.get('c', '')
            })
        level_blocks.append(block)
    
    # exam
    exam_questions = []
    for eqidx, eqq in enumerate(data.get('exam', [])):
        eqid = f'add-l{i}-exam-q{eqidx+1}'
        options = []
        for oidx, opt in enumerate(eqq.get('o', [])):
            options.append({'id': chr(ord('a')+oidx), 'text': opt})
        correct_idx = eqq.get('a', [0])[0] if eqq.get('a') else 0
        correct_id = chr(ord('a')+correct_idx)
        exam_questions.append({
            'id': eqid,
            'type': 'mcq',
            'prompt': eqq.get('t', ''),
            'options': options,
            'correctOptionId': correct_id,
            'explanation': eqq.get('e', ''),
            'relatedConcept': eqq.get('c', '')
        })
    
    level_out = {
        'id': f'money-l{i}',
        'order': i,
        'title': data.get('name', f'Nivel {i}'),
        'methodology': 'theory',
        'blocks': level_blocks,
        'exam': {
            'id': f'money-l{i}-exam',
            'passScore': 12,
            'questions': exam_questions
        }
    }
    levels_out.append(level_out)

course = {
    'schemaVersion': 1,
    'id': 'academia-del-dinero',
    'title': 'Academia del Dinero',
    'description': 'Curso completo de Academia del Dinero - 9 niveles',
    'methodology': 'theory',
    'source': 'imported',
    'levels': levels_out
}

with open('../academia_dinero_v2/src/moneyCourse.json', 'w', encoding='utf-8') as f:
    json.dump(course, f, ensure_ascii=False, indent=2)

print('done')
