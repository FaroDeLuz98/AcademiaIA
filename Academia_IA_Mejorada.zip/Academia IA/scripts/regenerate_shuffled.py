# -*- coding: utf-8 -*-
"""
Regenera moneyCourse.json y economicsCourseData.js con opciones barajadas
para que la respuesta correcta NO sea siempre la primera.
"""
import os, json, random

random.seed(42)  # semilla fija para reproducibilidad

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'estudiar - copia'))

levels_out = []

for i in range(1, 10):
    try:
        exec(open(f'data_l{i}.py', encoding='utf-8').read())
        data = locals()[f'L{i}']
    except Exception as e:
        raise

    level_blocks = []
    for pidx, part in enumerate(data.get('parts', [])):
        b_id = f'add-l{i}-b{pidx+1}'
        theory_html = part.get('theory', '')
        block = {
            'id': b_id,
            'order': pidx + 1,
            'title': part.get('title', f'Bloque {pidx+1}'),
            'theory': {
                'title': part.get('title', f'Bloque {pidx+1}'),
                'paragraphs': [theory_html],
                'examples': [],
                'cases': [],
                'formulas': [],
                'procedure': [],
                'code': None
            },
            'quiz': {
                'id': b_id + '-quiz',
                'questions': []
            }
        }
        for qidx, qq in enumerate(part.get('quiz', [])):
            qid = f'add-l{i}-b{pidx+1}-q{qidx+1}'
            # Build options with original indices
            original_options = []
            for oidx, opt in enumerate(qq.get('o', [])):
                original_options.append({'id': chr(ord('a')+oidx), 'text': opt, 'orig_idx': oidx})

            correct_indices = set(qq.get('a', [0]))

            # Shuffle options
            shuffled = list(original_options)
            random.shuffle(shuffled)

            # Reassign IDs based on new position
            new_options = []
            correct_id = None
            for new_idx, item in enumerate(shuffled):
                new_id = chr(ord('a') + new_idx)
                new_options.append({'id': new_id, 'text': item['text']})
                if item['orig_idx'] in correct_indices:
                    # For single-answer questions, take the first correct
                    if correct_id is None:
                        correct_id = new_id

            if correct_id is None:
                correct_id = 'a'

            # Build hint from the explanation (first sentence or partial)
            explanation = qq.get('e', '')
            hint = ''
            if explanation:
                # Use related concept as hint
                concept = qq.get('c', '')
                if concept:
                    hint = f'Pensá en el concepto: {concept}'
                else:
                    hint = explanation[:80] + '...' if len(explanation) > 80 else explanation

            block['quiz']['questions'].append({
                'id': qid,
                'type': 'mcq',
                'prompt': qq.get('t', ''),
                'options': new_options,
                'correctOptionId': correct_id,
                'explanation': explanation,
                'relatedConcept': qq.get('c', ''),
                'hint': hint
            })
        level_blocks.append(block)

    # exam
    exam_questions = []
    for eqidx, eqq in enumerate(data.get('exam', [])):
        eqid = f'add-l{i}-exam-q{eqidx+1}'
        original_options = []
        for oidx, opt in enumerate(eqq.get('o', [])):
            original_options.append({'id': chr(ord('a')+oidx), 'text': opt, 'orig_idx': oidx})

        correct_indices = set(eqq.get('a', [0]))

        shuffled = list(original_options)
        random.shuffle(shuffled)

        new_options = []
        correct_id = None
        for new_idx, item in enumerate(shuffled):
            new_id = chr(ord('a') + new_idx)
            new_options.append({'id': new_id, 'text': item['text']})
            if item['orig_idx'] in correct_indices:
                if correct_id is None:
                    correct_id = new_id

        if correct_id is None:
            correct_id = 'a'

        explanation = eqq.get('e', '')
        hint = ''
        concept = eqq.get('c', '')
        if concept:
            hint = f'Pensá en el concepto: {concept}'
        elif explanation:
            hint = explanation[:80] + '...' if len(explanation) > 80 else explanation

        exam_questions.append({
            'id': eqid,
            'type': 'mcq',
            'prompt': eqq.get('t', ''),
            'options': new_options,
            'correctOptionId': correct_id,
            'explanation': explanation,
            'relatedConcept': concept,
            'hint': hint
        })

    level_out = {
        'id': f'money-l{i}',
        'order': i,
        'title': data.get('name', f'Nivel {i}'),
        'methodology': 'theory',
        'blocks': level_blocks,
        'exam': {
            'id': f'money-l{i}-exam',
            'passScore': 12,
            'questions': exam_questions
        }
    }
    levels_out.append(level_out)

course = {
    'schemaVersion': 1,
    'id': 'academia-del-dinero',
    'title': 'Academia del Dinero',
    'description': 'Curso completo de Academia del Dinero - 9 niveles',
    'methodology': 'theory',
    'source': 'imported',
    'levels': levels_out
}

# Write moneyCourse.json
json_path = os.path.join('..', 'academia_dinero_v2', 'src', 'moneyCourse.json')
with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(course, f, ensure_ascii=False, indent=2)

# Write economicsCourseData.js
js_path = os.path.join('..', 'academia_dinero_v2', 'src', 'economicsCourseData.js')
with open(js_path, 'w', encoding='utf-8') as f:
    f.write('export const economicsCourseDefinition = ')
    json.dump(course, f, ensure_ascii=False)
    f.write(';\n')

# Verify: count how many questions have correctOptionId != 'a'
total = 0
non_a = 0
for level in course['levels']:
    for block in level['blocks']:
        for q in block['quiz']['questions']:
            total += 1
            if q['correctOptionId'] != 'a':
                non_a += 1
    for q in level['exam']['questions']:
        total += 1
        if q['correctOptionId'] != 'a':
            non_a += 1

print(f'Done! Total questions: {total}, answers NOT "a": {non_a} ({non_a*100//total}%)')
