﻿const fs = require('fs');
let app = fs.readFileSync('academia_dinero_v2/src/app.js','utf8');
if(!app.includes('createEconomicsCourseDefinition')){
  app = app.replace("import { createDemoCourseDefinition } from \"./demoCourse.js\";",
    "import { createDemoCourseDefinition } from \"./demoCourse.js\";\nimport { createEconomicsCourseDefinition } from \"./economicsCourse.js\";");
  fs.writeFileSync('academia_dinero_v2/src/app.js', app);
  console.log('ok');
} else {
  console.log('skip');
}
