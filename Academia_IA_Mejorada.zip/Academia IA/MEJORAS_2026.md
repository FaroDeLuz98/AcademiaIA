# Academia IA — Renovación visual y funcional

## Qué se renovó

La plataforma principal sigue siendo **`academia_dinero_v2`**. El motor original de cursos, perfiles, cuestionarios, exámenes, progreso y materiales sigue funcionando sin migrar tus datos.

- Interfaz renovada: diseño premium, tarjetas, navegación clara, mejores estados y adaptación a celular.
- Temas **oscuro y claro** con preferencia persistente.
- **Buscador rápido** de materias y acciones (Ctrl+K o `/` cuando no estás escribiendo).
- **Mis apuntes** por perfil, materia y lección: guardado automático local, edición y exportación a TXT.
- **Temporizador de estudio** con sesiones de 25/50 minutos, iniciar/pausar y reiniciar. Continúa su cuenta si refrescás la web.
- **Buscador de niveles y lecciones** dentro de cada materia.
- **Tamaño de lectura ajustable** durante las sesiones.
- Menú lateral en móvil, controles de teclado, estados de foco y preferencia de movimiento reducido.
- Diálogos mejorados y datos de nombres protegidos al mostrarse en pantalla.
- App Android sincronizada con la nueva interfaz; el botón físico Atrás cierra paneles antes de salir.

## Cómo ejecutarla

**Windows:** abrí `INICIAR_ACADEMIA.bat` desde la carpeta principal. Si tenés Node.js, levanta el servidor local y abre el navegador. Si no, intenta con Python. No es necesario ejecutar `npm install` para usar la web.

**Linux/macOS:** en la carpeta principal ejecutá `bash INICIAR_ACADEMIA.sh`. Alternativamente entrá a `academia_dinero_v2` y ejecutá `node server.js`. Abrí `http://localhost:8000`.

**Android:** el proyecto Android Studio está en `app/`; la interfaz está copiada en `app/src/main/assets/`. Para generar un APK, abrí la carpeta principal del proyecto en Android Studio y compilá el módulo `app`. **Este ZIP incluye el código Android, no un APK compilado.**

## Datos y privacidad

- La base de datos de materias y progresos continúa en **IndexedDB** del navegador o WebView.
- Las notas y preferencias de interfaz se guardan en **localStorage** de cada dispositivo.
- Si reinstalás, cambiás de navegador o borrás datos del sitio, podés perder los datos locales. Exportá el perfil y, por separado, los apuntes que quieras conservar.
- **No hay conexión a un servicio de IA generativa** en este paquete; se conserva el motor educativo ya existente. Los textos que prometen funciones futuras siguen siendo planes, no funciones activas.
- La app Android y la web conservan almacenamiento local separado; no sincronizan automáticamente entre dispositivos.

## Archivos importantes

- `academia_dinero_v2/index.html`: interfaz web principal.
- `academia_dinero_v2/src/experience.css`: sistema visual y responsive.
- `academia_dinero_v2/src/experience.js`: búsqueda, notas, tema, lector, navegación, temporizador.
- `academia_dinero_v2/src/app.js`: motor de pantallas (con integración para nuevos controles).
- `app/src/main/assets/`: copia de la interfaz para Android.

La versión antigua `Academia del Dinero.html`, incluida como respaldo en la raíz, no fue rediseñada para evitar mezclar su estructura de datos con la app principal.
