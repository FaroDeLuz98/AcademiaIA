@echo off
setlocal
title Academia IA - Nueva version
cd /d "%~dp0"
echo.
echo ==============================================
echo       ACADEMIA IA - VERSION MEJORADA
echo ==============================================
echo.
where node >nul 2>&1
if not errorlevel 1 (
  cd /d "%~dp0academia_dinero_v2"
  node server.js
  pause
  exit /b 0
)
where py >nul 2>&1
if not errorlevel 1 (
  echo Node.js no disponible. Iniciando con Python...
  start "" "http://localhost:8000"
  py -m http.server 8000 --directory "%~dp0academia_dinero_v2"
  pause
  exit /b 0
)
where python >nul 2>&1
if not errorlevel 1 (
  start "" "http://localhost:8000"
  python -m http.server 8000 --directory "%~dp0academia_dinero_v2"
  pause
  exit /b 0
)
echo No se encontro Node.js ni Python.
echo Instala Node.js desde https://nodejs.org/ y vuelve a intentar.
pause
exit /b 1
