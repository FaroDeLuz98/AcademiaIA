// server.js - Servidor web nativo para Academia IA
// Cero dependencias externas. Inicia al instante con Node.js y abre el navegador al estar listo.

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let PORT = Number(process.env.PORT) || 8000;
const HOST = "0.0.0.0";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".pdf": "application/pdf",
  ".txt": "text/plain; charset=utf-8",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
};

const server = http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "*");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  let safePath = decodeURIComponent(parsedUrl.pathname);
  if (safePath === "/" || safePath === "") safePath = "/index.html";

  const normalized = path.normalize(safePath).replace(/^(\.\.[\/\\])+/, "");
  let filePath = path.join(__dirname, normalized);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
      res.end(`<h1>404 No Encontrado</h1><p>Archivo <code>${safePath}</code> no encontrado.</p>`);
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || "application/octet-stream";

    res.writeHead(200, {
      "Content-Type": contentType,
      "Content-Length": stats.size,
      "Cache-Control": "no-cache, no-store, must-revalidate",
    });

    fs.createReadStream(filePath).pipe(res);
  });
});

function startServer(portToTry) {
  server.listen(portToTry, HOST, () => {
    const url = `http://localhost:${portToTry}`;
    console.log("=======================================================");
    console.log("  🎓 ACADEMIA IA - SERVIDOR WEB ACTIVO");
    console.log(`  URL Local:   ${url}`);
    console.log(`  URL en red:  http://127.0.0.1:${portToTry}`);
    console.log("=======================================================");
    console.log("  Abriendo navegador...");
    console.log("  Mantené esta ventana abierta mientras usás la app.");
    console.log("  Presioná Ctrl+C para detener el servidor.\n");

    // Abrir navegador una vez que el servidor está escuchando
    if (process.env.NO_OPEN !== "1") {
      exec(`start "" "${url}"`, (err) => {
        if (err) {
          console.log(`  (Copiá y abrí este enlace en tu navegador: ${url})`);
        }
      });
    }
  });
}

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.log(`[AVISO] El puerto ${PORT} está ocupado. Probando puerto ${PORT + 1}...`);
    PORT += 1;
    startServer(PORT);
  } else {
    console.error("[ERROR]", err);
  }
});

startServer(PORT);
