﻿// src/economicsCourse.js
// Curso "Academia del Dinero" importado desde la aplicación original.
// Es un curso disponible para importar a una materia; no se agrega solo.

import { economicsCourseDefinition as rawDefinition } from "./economicsCourseData.js";

export function createEconomicsCourseDefinition() {
  return JSON.parse(JSON.stringify(rawDefinition));
}

export const economicsCourseDefinition = createEconomicsCourseDefinition();

export const ECONOMICS_COURSE_ID = "academia-del-dinero";
