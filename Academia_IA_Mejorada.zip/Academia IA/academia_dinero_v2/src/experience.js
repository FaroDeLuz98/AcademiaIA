// Academia IA · enhancements: navigation, search, notes, reader, accessibility, timer.
// This layer keeps the original course engine and IndexedDB progress intact.
import { getActiveProfileId, getActiveSubjectId, getSubjectsByProfile } from './storage.js';

const $ = (id) => document.getElementById(id);
const state = { menuOpen:false, commandItems:[], selected:0, noteKey:null, saveTimer:null };
const supportsStorage = (()=>{ try{ localStorage.setItem('__academia_test','1');localStorage.removeItem('__academia_test');return true;}catch{return false;} })();
const read = (key, fallback='') => { try { return localStorage.getItem(key) ?? fallback; } catch {return fallback;} };
const write = (key, value) => { try {localStorage.setItem(key,value);return true;}catch{return false;} };

const toast = (message) => {
  const el=document.createElement('div');el.className='toast';el.textContent=message;$('toastStack').appendChild(el);
  setTimeout(()=>el.remove(),3600);
};
const norm = (value) => String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const context = () => window.getAcademiaContext?.() || {profileId:getActiveProfileId(),subjectId:getActiveSubjectId(),view:'dashboard'};

// Appearance
const theme = read('academia_theme_v3','dark') === 'light' ? 'light' : 'dark';
const applyTheme = (mode) => {
  document.body.classList.toggle('theme-light',mode==='light');
  $('toggleThemeBtn').textContent = mode==='light' ? '☾' : '☀';
  $('toggleThemeBtn').setAttribute('aria-label',mode==='light'?'Activar tema oscuro':'Activar tema claro');
  write('academia_theme_v3',mode);
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content',mode==='light'?'#f4f7fb':'#090d18');
};
applyTheme(theme);
$('toggleThemeBtn').addEventListener('click',()=>applyTheme(document.body.classList.contains('theme-light')?'dark':'light'));

// Main navigation, mobile menu
const closeMenu=()=>{document.body.classList.remove('sidebar-open');$('mobileMenuBtn').setAttribute('aria-expanded','false');};
const openMenu=()=>{document.body.classList.add('sidebar-open');$('mobileMenuBtn').setAttribute('aria-expanded','true');};
$('mobileMenuBtn').addEventListener('click',()=>document.body.classList.contains('sidebar-open')?closeMenu():openMenu());
$('mobileSidebarOverlay').addEventListener('click',closeMenu);
$('navDashboard').addEventListener('click',()=>{closeMenu();window.academiaGoHome?.();});
$('navSubjects').addEventListener('click',()=>{
  if(window.matchMedia('(max-width:830px)').matches){openMenu();$('subjectPanel').scrollIntoView({block:'start'});}else{$('subjectPanel').scrollIntoView({behavior:'smooth',block:'start'});}
});
$('navNotes').addEventListener('click',()=>openNotes());
document.addEventListener('click',(e)=>{
  if(e.target.closest('[data-open-subject],.subject-item [data-action="open"],#continueStudyBtn'))closeMenu();
});

// Command palette
const commandBackdrop=$('commandBackdrop'),commandInput=$('commandInput'),commandResults=$('commandResults');
function closeCommand(){commandBackdrop.hidden=true;commandInput.value='';}
const actions = [
  {title:'Ir al inicio',caption:'Volver al panel de estudio',icon:'⌂',action:()=>window.academiaGoHome?.()},
  {title:'Crear materia',caption:'Organizá una nueva materia',icon:'▦',action:()=>{closeMenu();$('addSubjectBtn').click();}},
  {title:'Crear perfil',caption:'Empezá otro espacio de estudio',icon:'◉',action:()=>$('addProfileBtn').click()},
  {title:'Mis apuntes',caption:'Abrir tu cuaderno personal',icon:'✎',action:openNotes},
  {title:'Cambiar tema',caption:'Alterná entre claro y oscuro',icon:'◐',action:()=>$('toggleThemeBtn').click()},
  {title:'Exportar perfil',caption:'Hacé una copia de seguridad',icon:'↓',action:()=>$('exportProfileBtn').click()},
];
async function openCommand(){
  closeNotes();closeMenu();commandBackdrop.hidden=false;commandInput.value='';
  await updateCommands();commandInput.focus();
}
async function updateCommands(){
  const profileId=getActiveProfileId();
  let subjects=[];
  try{if(profileId)subjects=await getSubjectsByProfile(profileId);}catch(e){console.warn('No se pudieron cargar las materias',e);}
  state.commandItems=[
    ...subjects.map(subject=>({title:subject.name,caption:`Materia${subject.level?' · '+subject.level:''}`,icon:'▦',action:()=>window.openAcademiaSubject?.(subject.id)})),
    ...actions,
  ];
  filterCommands();
}
function filterCommands(){
  const query=norm(commandInput.value);
  const items=state.commandItems.filter(item=>norm(item.title+' '+item.caption).includes(query)).slice(0,12);
  state.visibleCommands=items;state.selected=0;commandResults.replaceChildren();
  if(items.length===0){const e=document.createElement('p');e.className='command-empty';e.textContent='No encontramos resultados. Probá con otra palabra.';commandResults.appendChild(e);return;}
  items.forEach((item,i)=>{
    const btn=document.createElement('button');btn.type='button';btn.className='command-item'+(i===0?' selected':'');btn.setAttribute('role','option');btn.setAttribute('aria-selected',String(i===0));
    const icon=document.createElement('span');icon.className='command-item-icon';icon.textContent=item.icon;
    const content=document.createElement('span');const title=document.createElement('strong');title.textContent=item.title;
    const caption=document.createElement('small');caption.textContent=item.caption;content.append(title,caption);btn.append(icon,content);
    btn.addEventListener('mouseenter',()=>selectCommand(i));
    btn.addEventListener('click',()=>runCommand(item));commandResults.appendChild(btn);
  });
}
function selectCommand(i){
  state.selected=Math.max(0,Math.min(i,(state.visibleCommands?.length||1)-1));
  Array.from(commandResults.querySelectorAll('.command-item')).forEach((btn,j)=>{
    btn.classList.toggle('selected',j===state.selected);btn.setAttribute('aria-selected',String(j===state.selected));
  });
}
function runCommand(item){closeCommand();item?.action?.();}
$('openSearchBtn').addEventListener('click',openCommand);
$('closeCommandBtn').addEventListener('click',closeCommand);
commandBackdrop.addEventListener('click',(e)=>{if(e.target===commandBackdrop)closeCommand();});
commandInput.addEventListener('input',filterCommands);
commandInput.addEventListener('keydown',(e)=>{
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();selectCommand((state.selected+(e.key==='ArrowDown'?1:-1)+(state.visibleCommands?.length||0))%(state.visibleCommands?.length||1));}
  if(e.key==='Enter'){e.preventDefault();runCommand(state.visibleCommands?.[state.selected]);}
});

// Local notes, scoped to profile, subject and optional study level.
function currentNoteKey(){
  const c=context(); if(!c.profileId)return null;
  return `academia_notes_v3_${c.profileId}_${c.subjectId||'general'}_${c.view==='study'&&c.levelId?c.levelId:'general'}`;
}
function noteTitle(){
  const c=context();
  if(c.view==='study'&&c.levelTitle)return `Lección · ${c.levelTitle}`;
  if(c.view==='subject')return `Materia · ${c.subjectTitle?.replace(/^📘\s*/,'')||'Apuntes'}`;
  return 'Notas generales del perfil';
}
function storeActiveNote(){
  if(!state.noteKey)return;
  const ok=write(state.noteKey,$('notesTextarea').value);
  $('notesSaveStatus').textContent=ok?'✓ Guardado en este dispositivo':'No se pudo guardar; revisá el almacenamiento del navegador';
}
function refreshNotes(){
  const key=currentNoteKey();const hasProfile=Boolean(context().profileId);
  if(key!==state.noteKey){
    if(state.saveTimer){clearTimeout(state.saveTimer);state.saveTimer=null;storeActiveNote();}
    state.noteKey=key;$('notesTextarea').value=key?read(key):'';
  }
  $('notesContext').textContent=hasProfile?noteTitle():'Creá o seleccioná un perfil para guardar tus notas.';
  $('notesTextarea').disabled=!hasProfile;
  $('notesSaveStatus').textContent=hasProfile?'✓ Se guarda automáticamente en este dispositivo':'Seleccioná un perfil para comenzar';
}
function openNotes(){closeCommand();closeMenu();refreshNotes();$('notesBackdrop').hidden=false;$('notesDrawer').classList.add('open');$('notesDrawer').setAttribute('aria-hidden','false');$('notesTextarea').focus();}
function closeNotes(){
  if(state.saveTimer){clearTimeout(state.saveTimer);state.saveTimer=null;storeActiveNote();}
  $('notesBackdrop').hidden=true;$('notesDrawer').classList.remove('open');$('notesDrawer').setAttribute('aria-hidden','true');
}
$('openNotesBtn').addEventListener('click',openNotes);
$('closeNotesBtn').addEventListener('click',closeNotes);
$('notesBackdrop').addEventListener('click',closeNotes);
$('notesTextarea').addEventListener('input',()=>{
  $('notesSaveStatus').textContent='Guardando…';clearTimeout(state.saveTimer);
  state.saveTimer=setTimeout(()=>{state.saveTimer=null;storeActiveNote();},420);
});
$('clearNotesBtn').addEventListener('click',()=>{
  if(!$('notesTextarea').value.trim())return;
  if(!confirm('¿Querés borrar los apuntes de esta sección?'))return;
  $('notesTextarea').value='';clearTimeout(state.saveTimer);state.saveTimer=null;storeActiveNote();toast('Apuntes de esta sección limpiados');
});
$('exportNotesBtn').addEventListener('click',()=>{
  if(!context().profileId){toast('Primero seleccioná un perfil');return;}
  storeActiveNote();
  const text=`Academia IA · Mis apuntes\n${noteTitle()}\nFecha: ${new Date().toLocaleDateString('es-UY')}\n\n${$('notesTextarea').value}`;
  const file=new Blob([text],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(file),link=document.createElement('a');
  link.href=url;link.download='academia-apuntes.txt';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Apuntes exportados');
});

// Study timer: pause/resume, 25 or 50 min, survives reloads.
const TIMER_KEY='academia_timer_v3';
let timer;
try{timer=JSON.parse(read(TIMER_KEY,'null'));}catch{}
if(!timer||![25,50].includes(timer.duration)){timer={duration:25,remaining:25*60,endsAt:null,running:false};}
function secondsRemaining(){return timer.running?Math.max(0,Math.ceil((timer.endsAt-Date.now())/1000)):timer.remaining;}
function persistTimer(){write(TIMER_KEY,JSON.stringify(timer));}
function updateTimer(){
  const remaining=secondsRemaining();
  if(timer.running&&remaining===0){timer.running=false;timer.remaining=0;timer.endsAt=null;persistTimer();toast('¡Sesión completada! Tomate un descanso.');}
  const mm=Math.floor(remaining/60),ss=remaining%60;$('timerValue').textContent=`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
  $('timerBtn').classList.toggle('running',timer.running);
  $('startTimerBtn').textContent=timer.running?'Pausar':remaining===0?'Empezar otra':'Iniciar / Seguir';
  $('timerBtn').setAttribute('aria-label',`Temporizador de estudio, ${mm} minutos ${ss} segundos`);
}
$('timerBtn').addEventListener('click',()=>{const open=$('timerPopover').hidden;$('timerPopover').hidden=!open;$('timerBtn').setAttribute('aria-expanded',String(open));});
$('timerPopover').querySelectorAll('[data-duration]').forEach(btn=>btn.addEventListener('click',()=>{timer.duration=Number(btn.dataset.duration);timer.remaining=timer.duration*60;timer.running=false;timer.endsAt=null;persistTimer();updateTimer();toast(`Sesión de ${timer.duration} minutos lista`);}));
$('startTimerBtn').addEventListener('click',()=>{
  if(timer.running){timer.remaining=secondsRemaining();timer.running=false;timer.endsAt=null;}
  else{if(timer.remaining===0)timer.remaining=timer.duration*60;timer.running=true;timer.endsAt=Date.now()+timer.remaining*1000;}
  persistTimer();updateTimer();
});
$('resetTimerBtn').addEventListener('click',()=>{timer.remaining=timer.duration*60;timer.running=false;timer.endsAt=null;persistTimer();updateTimer();});
updateTimer();setInterval(updateTimer,1000);
document.addEventListener('click',(e)=>{if(!e.target.closest('.timer-wrap')){$('timerPopover').hidden=true;$('timerBtn').setAttribute('aria-expanded','false');}});

// Reader and level search, added as each view renders. No course engine changes.
const READER_KEY='academia_reader_v3';
let readerScale=Math.max(.9,Math.min(1.3,Number(read(READER_KEY,'1'))||1));
const applyReader=()=>document.documentElement.style.setProperty('--reading-scale',readerScale);
applyReader();
function syncMain(){
  const c=context(),main=$('main');if(!main)return;
  const isStudy=c.view==='study'&&!!main.querySelector('.study-top');
  if(isStudy&&!main.querySelector('.study-quickbar')){
    const bar=document.createElement('div');bar.className='study-quickbar';
    bar.innerHTML=`<span class="quickbar-label">Herramientas de estudio</span><button type="button" class="secondary" data-quick-notes>✎ Apuntes de esta lección</button><button type="button" class="secondary text-size" data-reader-change="-.1" aria-label="Reducir tamaño de texto">A−</button><button type="button" class="secondary text-size" data-reader-change=".1" aria-label="Aumentar tamaño de texto">A+</button>`;
    const nav=main.querySelector('.study-nav');
    if(nav)nav.before(bar);else main.querySelector('.study-top').after(bar);
    bar.querySelector('[data-quick-notes]').addEventListener('click',openNotes);
    bar.querySelectorAll('[data-reader-change]').forEach(btn=>btn.addEventListener('click',()=>{
      readerScale=Math.round(Math.max(.9,Math.min(1.3,readerScale+Number(btn.dataset.readerChange)))*10)/10;
      applyReader();write(READER_KEY,String(readerScale));toast(`Tamaño de lectura: ${Math.round(readerScale*100)}%`);
    }));
  }
  const path=main.querySelector('.level-path');
  if(c.view==='subject'&&path&&!main.querySelector('.lesson-search')){
    const filter=document.createElement('div');filter.className='lesson-search';
    const input=document.createElement('input');input.type='search';input.placeholder='Buscar niveles y lecciones…';input.setAttribute('aria-label','Buscar niveles y lecciones');
    const count=document.createElement('span');filter.append(input,count);path.before(filter);
    const nodes=Array.from(path.querySelectorAll(':scope > .level-node'));
    const match=()=>{let visible=0;const term=norm(input.value);nodes.forEach(node=>{const found=norm(node.textContent).includes(term);node.hidden=!found;if(found)visible++;});count.textContent=`${visible} de ${nodes.length} niveles`;const empty=main.querySelector('.lesson-search-empty');if(empty)empty.remove();if(visible===0){const p=document.createElement('div');p.className='lesson-search-empty';p.textContent='No encontramos niveles con ese nombre.';path.before(p);}};
    input.addEventListener('input',match);match();
  }
  const navHome=$('navDashboard'),navSubject=$('navSubjects');
  navHome.classList.toggle('active',c.view==='dashboard'||c.view==='welcome');
  navSubject.classList.toggle('active',c.view==='subject'||c.view==='study');
  if($('notesDrawer').classList.contains('open'))refreshNotes();
}
let scheduled=false;
const mainObserver=new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;syncMain();});});
mainObserver.observe($('main'),{childList:true,subtree:true});
setTimeout(syncMain,0);

// Existing modal accessibility / overlay; preserves the original profile/subject workflows.
const modalElements=[$('profileModal'),$('subjectModal')];
function syncModals(){
  const opened=modalElements.find(el=>getComputedStyle(el).display!=='none');
  $('modalBackdrop').hidden=!opened;
  modalElements.forEach(el=>{el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label',el.id==='profileModal'?'Editar perfil':'Editar materia');});
  if(opened&&document.activeElement!==opened.querySelector('input'))opened.querySelector('input')?.focus();
}
modalElements.forEach(modal=>new MutationObserver(syncModals).observe(modal,{attributes:true,attributeFilter:['style']}));
$('modalBackdrop').addEventListener('click',()=>{const opened=modalElements.find(el=>getComputedStyle(el).display!=='none');opened?.querySelector('button[id^="close"]')?.click();});

// Keyboard accessibility.
document.addEventListener('keydown',(e)=>{
  const typing=e.target.matches?.('input,textarea,[contenteditable="true"]');
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand();return;}
  if(e.key==='Escape'){
    if(!commandBackdrop.hidden){closeCommand();return;}
    if($('notesDrawer').classList.contains('open')){closeNotes();return;}
    if(!$('timerPopover').hidden){$('timerPopover').hidden=true;return;}
    const modal=modalElements.find(el=>getComputedStyle(el).display!=='none');if(modal){modal.querySelector('button[id^="close"]')?.click();return;}
    const preview=$('materialPreviewPanel');if(preview&&preview.style.display!=='none'){preview.querySelector('#closeMaterialPreview')?.click();return;}
    closeMenu();
  }
  if(!typing&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key==='/'&&commandBackdrop.hidden){e.preventDefault();openCommand();}
});

// Android hardware back: close the current overlay before leaving the app.
window.academiaHandleBack=()=>{
  if(!commandBackdrop.hidden){closeCommand();return true;}
  if($('notesDrawer').classList.contains('open')){closeNotes();return true;}
  if(!$('timerPopover').hidden){$('timerPopover').hidden=true;return true;}
  const modal=modalElements.find(el=>getComputedStyle(el).display!=='none');
  if(modal){modal.querySelector('button[id^="close"]')?.click();return true;}
  const preview=$('materialPreviewPanel');
  if(preview&&preview.style.display!=='none'){preview.querySelector('#closeMaterialPreview')?.click();return true;}
  if(document.body.classList.contains('sidebar-open')){closeMenu();return true;}
  if(context().view==='study'||context().view==='subject'){window.academiaGoHome?.();return true;}
  return false;
};

// Visibility/interaction niceties.
window.addEventListener('storage',(e)=>{if(e.key==='academia_theme_v3')applyTheme(e.newValue==='light'?'light':'dark');});
window.addEventListener('pagehide',()=>{if(state.saveTimer)storeActiveNote();});
