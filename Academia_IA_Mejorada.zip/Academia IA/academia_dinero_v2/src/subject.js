// src/subject.js
// UI & logic for managing subjects (materias) per profile
import { addSubject, getSubjectsByProfile, updateSubject, deleteSubject, getActiveSubjectId, setActiveSubjectId } from "./storage.js";

const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));

const subjectListEl = document.getElementById("subjectList");
const subjectFormEl = document.getElementById("subjectForm");
const subjectNameInput = document.getElementById("subjectNameInput");
const subjectLevelInput = document.getElementById("subjectLevelInput");
const subjectModal = document.getElementById("subjectModal");
let editingSubjectId = null;

function closeModal(){
  subjectModal.style.display = "none";
  subjectNameInput.value = "";
  subjectLevelInput.value = "";
  editingSubjectId = null;
}
function openModal(edit=false, subject=null){
  subjectModal.style.display = "block";
  if(edit && subject){
    editingSubjectId = subject.id;
    subjectNameInput.value = subject.name;
    subjectLevelInput.value = subject.level || "";
  } else {
    editingSubjectId = null;
    subjectNameInput.value = "";
    subjectLevelInput.value = "";
  }
}

export async function renderSubjects(){
  const activeProfileId = Number(localStorage.getItem("academia_ia_current_profile"));
  if(!activeProfileId) {
    subjectListEl.innerHTML = "<p class='muted'>Selecciona o crea un perfil para gestionar materias.</p>";
    return;
  }
  const subjects = await getSubjectsByProfile(activeProfileId);
  const selectedId = getActiveSubjectId();
  if (!subjects.length) {
    subjectListEl.innerHTML = "<p class='muted'>No hay materias en este perfil.</p>";
    return;
  }
  subjectListEl.innerHTML = subjects.map(s=>`
    <li class="subject-item ${s.id===selectedId?"active":""}">
      <span>${escapeHTML(s.name)}${s.level ? " (" + escapeHTML(s.level) + ")" : ""}</span>
      <button class="secondary" data-action="open" data-id="${s.id}">Estudiar</button>
      <button class="secondary" data-action="edit" data-id="${s.id}">Editar</button>
      <button class="secondary" data-action="delete" data-id="${s.id}">Eliminar</button>
    </li>`).join("");
  subjectListEl.querySelectorAll('button').forEach(btn=>{
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id);
    btn.onclick = async()=>{
      if(action==='open'){
        setActiveSubjectId(id);
        window._currentSubjectId = id;
        if (window.refreshMaterials) window.refreshMaterials(id);
        renderSubjects();
        if (window.openAcademiaSubject) window.openAcademiaSubject(id);
      } else if(action==='edit'){
        const subj = subjects.find(s=>s.id===id);
        openModal(true, subj);
      } else if(action==='delete'){
        if(confirm('¿Eliminar la materia?')){
          await deleteSubject(id);
          for(const key of Object.keys(localStorage)) {
            if(key.startsWith(`academia_notes_v3_${activeProfileId}_${id}_`)) localStorage.removeItem(key);
          }
          if (selectedId === id) {
            setActiveSubjectId(null);
            window._currentSubjectId = null;
          }
          renderSubjects();
          if (window.renderMainPanel) window.renderMainPanel();
        }
      }
    };
  });
}

subjectFormEl.onsubmit = async(e)=>{
  e.preventDefault();
  const name = subjectNameInput.value.trim();
  const level = subjectLevelInput.value.trim();
  if(!name) return;
  const activeProfileId = Number(localStorage.getItem("academia_ia_current_profile"));
  if(editingSubjectId!==null){
    await updateSubject(editingSubjectId, {name, level});
  } else {
    await addSubject(activeProfileId, name, level);
  }
  closeModal();
  renderSubjects();
};

document.getElementById("addSubjectBtn").onclick = ()=>openModal();

document.getElementById("closeSubjectModal").onclick = closeModal;

// expose for other scripts (e.g., profile.js after profile change)
window.renderSubjects = renderSubjects;

// initial render
renderSubjects();
