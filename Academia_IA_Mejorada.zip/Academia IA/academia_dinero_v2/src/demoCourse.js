// src/demoCourse.js
// Curso de demostración: técnicas de estudio. No se agrega solo a las materias.

import { COURSE_SCHEMA_VERSION } from "./courseEngine.js";

function q(id, prompt, options, correct, explanation, concept, extra = {}) {
  return {
    id,
    type: extra.type || "mcq",
    prompt,
    options: options.map((text, i) => ({ id: ["a", "b", "c", "d"][i], text })),
    correctOptionId: correct,
    explanation,
    relatedConcept: concept,
    ...extra,
  };
}

function block(id, order, theory, questions) {
  return {
    id,
    order,
    title: theory.title,
    theory,
    quiz: { id: id + "-quiz", questions },
  };
}

export function createDemoCourseDefinition() {
  return {
    schemaVersion: COURSE_SCHEMA_VERSION,
    id: "demo-study-skills",
    title: "Técnicas de estudio, comprensión y exámenes",
    description: "Curso demo para probar el motor sin Gemini. Tres niveles con teoría, quizzes y examen final.",
    methodology: "theory",
    source: "demo",
    levels: [levelStudyMethods(), levelComprehension(), levelExamPrep()],
  };
}

function levelStudyMethods() {
  return {
    id: "demo-l1",
    order: 1,
    title: "Técnicas de estudio",
    methodology: "theory",
    blocks: [
      block(
        "demo-l1-b1",
        1,
        {
          title: "Atención y entorno",
          paragraphs: [
            "Estudiar no es estar frente a un apunte: es dirigir la atención durante bloques cortos y medibles.",
            "Un entorno predecible reduce la carga mental. Silenciá notificaciones, definí un lugar y un tiempo de inicio.",
            "La técnica Pomodoro (25 minutos de foco + 5 de pausa) sirve como punto de partida, no como dogma.",
          ],
          examples: [
            { title: "Bloque útil", kind: "case", body: "Leés un apartado, anotás 3 ideas en tus palabras y cerrás el celular. Eso vale más que 40 minutos de relectura pasiva." },
          ],
          cases: [
            { title: "Caso", body: "Si cada 2 minutos mirás el teléfono, el cerebro reaprende a interrumpir. Guardalo en otra habitación durante el bloque." },
          ],
        },
        [
          q("l1b1q1", "¿Cuál es el objetivo principal de un bloque de estudio?", ["Estar sentado el mayor tiempo posible", "Dirigir la atención a una tarea concreta", "Leer todo el material de una vez", "Memorizar sin comprender"], "b", "El bloque sirve para focalizar, no para acumular horas vacías.", "Atención"),
          q("l1b1q2", "¿Qué reduce más la carga mental al estudiar?", ["Cambiar de lugar cada cinco minutos", "Dejar notificaciones activas para no perderse nada", "Un entorno predecible y sin interrupciones", "Estudiar con varias pantallas a la vez"], "c", "Menos decisiones y menos interrupciones = más atención disponible.", "Entorno"),
          q("l1b1q3", "El Pomodoro se usa mejor como:", ["Una regla rígida de 25 minutos para cualquier tema", "Un punto de partida para medir foco y pausas", "Una forma de evitar hacer ejercicios", "Un reemplazo de dormir"], "b", "Adaptá la duración al tipo de tarea, pero medí el foco.", "Pomodoro"),
          q("l1b1q4", "Releer el mismo párrafo diez veces sin anotar suele ser:", ["La estrategia más eficiente", "Estudio pasivo de bajo rendimiento", "Igual de efectivo que autoevaluarse", "Obligatorio antes de un quiz"], "b", "La relectura da sensación de familiaridad, no de dominio.", "Estudio activo"),
          q("l1b1q5", "Si el teléfono interrumpe cada dos minutos, lo más eficaz es:", ["Subir el volumen para escuchar menos", "Dejarlo fuera de alcance durante el bloque", "Responder rápido y volver", "Estudiar de noche para compensar"], "b", "Quitar la tentación funciona mejor que la fuerza de voluntad constante.", "Atención"),
        ]
      ),
      block(
        "demo-l1-b2",
        2,
        {
          title: "Recuperación activa",
          paragraphs: [
            "La práctica de recuperación consiste en intentar recordar sin mirar el texto.",
            "Cerrar el apunte y responder: ¿qué acabo de aprender? ¿qué ejemplo lo demuestra?",
            "Equivocarse en este intento no es fracaso: es información sobre qué repasar.",
          ],
          examples: [
            { title: "Tarjeta mínima", kind: "text", body: "Frente: '¿Qué es inflación?'. Dorso: definición + un ejemplo de tu país. No copies párrafos enteros." },
          ],
        },
        [
          q("l1b2q1", "La recuperación activa consiste en:", ["Subrayar todo el texto", "Intentar recordar sin mirar el material", "Escuchar un podcast de fondo", "Copiar el libro a mano"], "b", "El esfuerzo de recordar fortalece la memoria más que volver a leer.", "Recuperación activa"),
          q("l1b2q2", "Equivocarse al autoevaluarse indica:", ["Que no sirve seguir", "Qué conceptos hay que reforzar", "Que el método es incorrecto", "Que hay que cambiar de materia"], "b", "El error es un mapa de repaso, no una etiqueta de capacidad.", "Errores útiles"),
          q("l1b2q3", "¿Cuál es mejor pregunta de estudio?", ["¿Leí el capítulo?", "¿Puedo explicar el concepto con un ejemplo?", "¿Cuántas páginas avanzé?", "¿Está subrayado de color?"], "b", "Si podés explicar y ejemplificar, hay comprensión.", "Comprensión"),
          q("l1b2q4", "Una flashcard efectiva suele incluir:", ["Un capítulo completo en el dorso", "Una idea y un ejemplo breve", "Solo la definición copiada literal", "Diez preguntas a la vez"], "b", "Una idea por tarjeta permite practicar con precisión.", "Recuperación activa"),
          q("l1b2q5", "Estudiar solo releyendo produce sobre todo:", ["Dominio demostrable", "Sensación de familiaridad", "Transferencia automática al examen", "Menos necesidad de dormir"], "b", "Familiaridad no es lo mismo que poder recuperar la idea bajo presión.", "Estudio pasivo"),
        ]
      ),
      block(
        "demo-l1-b3",
        3,
        {
          title: "Espaciado y planificación",
          paragraphs: [
            "Distribuir el estudio en varios días rinde más que un maratón la noche anterior.",
            "Planificá sesiones cortas: hoy teoría, mañana recuperación, pasado un mix de ejercicios.",
            "Dejá un margen para errores: el plan sirve si se puede ajustar.",
          ],
          procedure: [
            { step: "1", detail: "Elegí 3 objetivos concretos para la semana, no 15." },
            { step: "2", detail: "Reservá bloques en el calendario como si fueran clases." },
            { step: "3", detail: "Al final de cada bloque, anotá qué vas a recuperar mañana." },
          ],
        },
        [
          q("l1b3q1", "El estudio espaciado funciona mejor que el maratón porque:", ["Cansa más y eso memoriza", "Permite olvido parcial y reaprendizaje más estable", "Evita tener que autoevaluarse", "Solo sirve para idiomas"], "b", "Recordar después de un intervalo fortalece la memoria a largo plazo.", "Espaciado"),
          q("l1b3q2", "Un plan semanal realista prioriza:", ["Todas las materias al 100%", "Pocos objetivos concretos y medibles", "Solo las materias fáciles", "Estudiar cuando haya inspiración"], "b", "Tres objetivos claros se cumplen; quince se abandonan.", "Planificación"),
          q("l1b3q3", "¿Qué conviene anotar al cerrar un bloque?", ["Nada, para no perder tiempo", "La próxima pregunta o tarea de recuperación", "El número de páginas como único dato", "Una lista de distracciones ajenas"], "b", "Dejá preparado el siguiente recuerdo activo.", "Planificación"),
          q("l1b3q4", "Tratar el horario de estudio como una clase ayuda a:", ["Estudiar solo si apetece", "Proteger el bloque de otras tareas", "Alargar las sesiones sin pausas", "Evitar la recuperación activa"], "b", "Lo agendado compite mejor con las urgencias falsas.", "Hábitos"),
          q("l1b3q5", "Un buen plan incluye margen para errores porque:", ["Los errores invalidan el método", "El estudio real se desvía y hay que reajustar", "Así se estudia menos", "Los exámenes nunca cambian"], "b", "La flexibilidad mantiene el hábito cuando la semana se complica.", "Planificación"),
        ]
      ),
    ],
    exam: {
      id: "demo-l1-exam",
      passScore: 12,
      questions: [
        q("l1e1", "El estudio eficaz se mide mejor por:", ["Horas sentado", "Capacidad de recuperar y aplicar ideas", "Cantidad de subrayado", "Cantidad de PDFs abiertos"], "b", "El resultado es poder usar el conocimiento, no exhibir esfuerzo.", "Estudio activo"),
        q("l1e2", "Una interrupción breve y repetida suele:", ["Mejorar la creatividad siempre", "Romper el foco y encarecer volver a concentrarse", "Ser igual que una pausa planificada", "Reemplazar el Pomodoro"], "b", "La pausa planificada recupera; la interrupción fragmenta.", "Atención"),
        q("l1e3", "¿Qué describe mejor la recuperación activa?", ["Mirar el resumen otra vez", "Intentar responder sin el texto", "Copiar el título del capítulo", "Cambiar el color del resaltador"], "b", "El intento de recuerdo es el entrenamiento.", "Recuperación activa"),
        q("l1e4", "El entorno de estudio ideal prioriza:", ["Novedad constante", "Predicción y pocas distracciones", "Música con letra a volumen alto", "Varias conversaciones"], "b", "Menos ruido cognitivo, más recursos para el contenido.", "Entorno"),
        q("l1e5", "Subrayar todo el párrafo indica sobre todo:", ["Selección de ideas clave", "Falta de criterio de importancia", "Dominio del tema", "Un plan espaciado"], "b", "Si todo es clave, nada es clave.", "Estudio pasivo"),
        q("l1e6", "Espaciar el estudio significa:", ["Dejar pasar meses sin tocar el tema", "Repetir en intervalos, no todo de una vez", "Estudiar solo los fines de semana", "Leer más rápido"], "b", "Intervalos razonables > una sola sentada.", "Espaciado"),
        q("l1e7", "Una flashcard sobrecargada es un problema porque:", ["Obliga a pensar más", "Mezcla demasiadas ideas y no aísla el fallo", "Nunca se puede revisar", "Solo sirve en programación"], "b", "Si fallás, no sabés qué parte falló.", "Recuperación activa"),
        q("l1e8", "La noche previa al examen, lo más útil suele ser:", ["Aprender un temario entero nuevo", "Repaso de recuperación y dormir", "Desvelarse para leer más", "Cambiar el método por completo"], "b", "El sueño consolida; el maratón nuevo suele fallar.", "Espaciado"),
        q("l1e9", "Un objetivo concreto de bloque sería:", ["Estudiar economía", "Explicar en voz alta las 3 causas de...", "Avanzar lo más posible", "Estar motivado"], "b", "Lo concreto se puede verificar al terminar.", "Planificación"),
        q("l1e10", "Sentir que 'ya me lo sé' después de releer puede ser:", ["Prueba de dominio", "Ilusión de competencia", "Señal de aprobar seguro", "Igual que un examen"], "b", "Hay que comprobarlo con preguntas.", "Estudio pasivo"),
        q("l1e11", "Las pausas cortas entre bloques sirven para:", ["Perder el hilo a propósito", "Recuperar atención sin abandonar el plan", "Revisar redes 40 minutos", "Evitar la práctica"], "b", "Descanso dosificado, no escape.", "Pomodoro"),
        q("l1e12", "Si fallás una autoevaluación, el siguiente paso es:", ["Ocultar el tema", "Volver a la teoría de ese concepto y reintentar", "Cambiar de carrera", "Subrayar el índice"], "b", "Repaso dirigido al hueco detectado.", "Errores útiles"),
        q("l1e13", "Agendar el estudio como clase ayuda porque:", ["Impide cualquier ajuste", "Compite con otras tareas en el calendario", "Reemplaza la comprensión", "Hace innecesario el quiz"], "b", "Lo que no tiene hora, pierde.", "Hábitos"),
        q("l1e14", "¿Qué práctica combina mejor atención y memoria?", ["Multitarea con chat", "Bloque de foco + pregunta de recuperación", "Releer mientras se mira series", "Solo resúmenes ajenos"], "b", "Foco para entrar; recuperación para fijar.", "Estudio activo"),
        q("l1e15", "Un plan semanal de 15 metas vagas suele fracasar por:", ["Exceso de realismo", "Falta de priorización y verificación", "Demasiado espaciado", "Exceso de quizzes"], "b", "Sin prioridad no hay cierre.", "Planificación"),
      ],
    },
  };
}

function levelComprehension() {
  return {
    id: "demo-l2",
    order: 2,
    title: "Comprensión",
    methodology: "theory",
    blocks: [
      block(
        "demo-l2-b1",
        1,
        {
          title: "Leer para entender, no para terminar",
          paragraphs: [
            "Antes de leer, formulá una pregunta: ¿qué problema resuelve este texto?",
            "Durante la lectura, distinguí hechos, definiciones y opiniones.",
            "Después, resumí en 4 líneas sin mirar. Si no podés, volvé al apartado, no al capítulo entero.",
          ],
          examples: [
            { title: "Pregunta guía", kind: "text", body: "En un texto de oferta y demanda: '¿Qué mueve el precio en este modelo y qué no?'" },
          ],
        },
        [
          q("l2b1q1", "Una lectura eficaz empieza por:", ["Contar las páginas", "Una pregunta sobre el problema del texto", "Memorizar la primera frase", "Traducir todo a otro idioma"], "b", "La pregunta orienta la atención.", "Lectura activa"),
          q("l2b1q2", "Si no podés resumir 4 líneas, conviene:", ["Pasar al siguiente libro", "Releer el apartado concreto", "Subrayar el índice", "Aumentar la velocidad"], "b", "El hueco está localizado: no penalices todo el capítulo.", "Comprensión"),
          q("l2b1q3", "Hecho, definición y opinión se mezclan cuando:", ["No se etiquetan al leer", "Se usa Pomodoro", "Se espacia el estudio", "Se duerme bien"], "a", "Etiquetar evita tragar interpretaciones como si fueran datos.", "Lectura activa"),
          q("l2b1q4", "Terminar un PDF no garantiza comprensión porque:", ["Los PDF no se pueden estudiar", "Avance visual ≠ poder explicar", "Solo cuentan los exámenes orales", "La velocidad es el único indicador"], "b", "El indicador es explicar y aplicar.", "Comprensión"),
          q("l2b1q5", "Una buena pregunta post-lectura es:", ["¿Llegué al final?", "¿Qué cambiaría si esta premisa fuera falsa?", "¿Qué color usé?", "¿Cuánto pesa el archivo?"], "b", "Cuestionar premisas revela si entendiste la estructura.", "Pensamiento crítico"),
        ]
      ),
      block(
        "demo-l2-b2",
        2,
        {
          title: "Modelos mentales y transferencia",
          paragraphs: [
            "Un modelo mental es una versión simplificada de cómo funciona algo.",
            "Para transferir, cambiá el contexto: el mismo principio en otro ejemplo.",
            "Si solo funciona con el ejemplo del libro, todavía no está generalizado.",
          ],
          examples: [
            { title: "Transferencia", kind: "case", body: "Aprendiste escasez con entradas de recital. Probá explicarlo con turnos en un trámite." },
          ],
        },
        [
          q("l2b2q1", "Un modelo mental es:", ["Una cita textual", "Una simplificación útil de cómo funciona algo", "Un truco para no estudiar", "Una nota al pie"], "b", "Sirve para predecir y explicar, no para decorar.", "Modelos mentales"),
          q("l2b2q2", "Hay transferencia cuando:", ["Repetís el ejemplo original", "Aplicás el principio en un contexto nuevo", "Memorizás la página", "Copiás la definición"], "b", "Cambiar el escenario pone a prueba el principio.", "Transferencia"),
          q("l2b2q3", "Si solo funciona el ejemplo del libro:", ["Ya está dominado", "Falta generalizar el principio", "No hace falta más práctica", "El examen será idéntico"], "b", "El conocimiento sigue atado a un caso.", "Transferencia"),
          q("l2b2q4", "¿Qué pregunta entrena un modelo mental?", ["¿En qué página está?", "Si X sube, ¿qué debería pasar con Y y por qué?", "¿Cuántas palabras tiene?", "¿Quién publicó el PDF?"], "b", "Causa y efecto: eso es un modelo.", "Modelos mentales"),
          q("l2b2q5", "Explicar con tus palabras ayuda porque:", ["Alarga el tiempo de estudio", "Obliga a reconstruir la idea, no a recitarla", "Reemplaza a los ejercicios", "Evita ejemplos"], "b", "La reconstrucción es comprensión.", "Comprensión"),
        ]
      ),
      block(
        "demo-l2-b3",
        3,
        {
          title: "Números, fórmulas y lectura técnica",
          methodology: "stem",
          paragraphs: [
            "En textos con fórmulas, primero nombrá cada símbolo y las unidades.",
            "Después, describí el procedimiento: qué se conoce, qué se busca, qué fórmula aplica.",
            "Finalmente, estimá si el resultado tiene orden de magnitud razonable.",
          ],
          formulas: [
            { name: "Velocidad de lectura útil", expression: "páginas comprendidas / minutos de foco", note: "No cuenta lo hojeado sin poder resumir." },
          ],
          procedure: [
            { step: "Datos", detail: "Anotá lo que da el problema." },
            { step: "Incógnita", detail: "Escribí qué hay que obtener." },
            { step: "Puente", detail: "Elegí la relación o fórmula que conecta ambos." },
            { step: "Chequeo", detail: "¿El resultado tiene sentido?" },
          ],
        },
        [
          q("l2b3q1", "Ante una fórmula, el primer paso útil es:", ["Memorizar el número de página", "Nombrar símbolos y unidades", "Cambiar todos los signos", "Buscar un atajo sin leer"], "b", "Sin saber qué es cada letra, el álgebra es teatro.", "Procedimiento", { type: "calculation" }),
          q("l2b3q2", "Un procedimiento claro incluye:", ["Solo el resultado final", "Datos, incógnita, puente y chequeo", "Copiar la solución del compañero", "Usar la calculadora sin criterio"], "b", "El orden evita saltos mágicos.", "Procedimiento"),
          q("l2b3q3", "Chequear el orden de magnitud sirve para:", ["Alargar el examen", "Detectar resultados absurdos a tiempo", "Reemplazar la fórmula", "Evitar unidades"], "b", "Si el auto 'viaja' a 30000 km/h, algo falló.", "Estimación"),
          q("l2b3q4", "La 'velocidad de lectura útil' debería contar:", ["Páginas hojeadas", "Páginas que podés resumir", "Palabras por minuto de cualquier texto", "Cantidad de pestañas"], "b", "Comprensión, no turismo visual.", "Comprensión"),
          q("l2b3q5", "Si no sabés qué se busca en un ejercicio:", ["Igual aplicá la primera fórmula que recuerdes", "Detenete y definí la incógnita", "Multiplicá todos los datos", "Salteá el chequeo"], "b", "Sin incógnita no hay puente.", "Procedimiento"),
        ]
      ),
    ],
    exam: {
      id: "demo-l2-exam",
      passScore: 12,
      questions: [
        q("l2e1", "Leer para entender implica:", ["Priorizar terminar el archivo", "Salir pudiendo explicar el problema del texto", "Memorizar el diseño", "Evitar resumir"], "b", "El producto es comprensión.", "Lectura activa"),
        q("l2e2", "Etiquetar hechos y opiniones evita:", ["El Pomodoro", "Tratar interpretaciones como datos", "El espaciado", "Dormir"], "b", "Clasificar es pensar.", "Pensamiento crítico"),
        q("l2e3", "Un resumen de 4 líneas sirve como:", ["Decoración", "Prueba rápida de comprensión", "Reemplazo del examen final", "Evidencia de horas"], "b", "Si no sale, hay un hueco.", "Comprensión"),
        q("l2e4", "Transferir un concepto es:", ["Repetirlo igual", "Usarlo en un caso nuevo", "Traducirlo palabra por palabra", "Subrayarlo en neón"], "b", "Cambio de contexto.", "Transferencia"),
        q("l2e5", "Un modelo mental permite:", ["Solo recitar", "Predecir qué pasa si cambia una variable", "Evitar ejemplos", "Saltar definiciones"], "b", "Predicción = modelo en uso.", "Modelos mentales"),
        q("l2e6", "En un problema STEM, 'puente' significa:", ["El título del PDF", "La relación que une datos e incógnita", "La respuesta del compañero", "La calculadora"], "b", "La fórmula o el razonamiento conector.", "Procedimiento"),
        q("l2e7", "Un resultado sin unidades en física suele ser:", ["Más elegante", "Incompleto o ambiguo", "Siempre correcto", "Prueba de estimación"], "b", "Las unidades son parte de la respuesta.", "Procedimiento"),
        q("l2e8", "Si el ejemplo del libro es el único que te sale:", ["Ya transferiste", "El saber está anclado a ese caso", "No hace falta otro contexto", "El modelo es robusto"], "b", "Falta generalización.", "Transferencia"),
        q("l2e9", "Preguntar '¿qué pasaría si la premisa es falsa?' entrena:", ["Velocidad lectora vacía", "Pensamiento crítico", "Subrayado", "Multitarea"], "b", "Ataca la estructura del argumento.", "Pensamiento crítico"),
        q("l2e10", "Nombrar símbolos antes de calcular reduce:", ["La claridad", "Errores por confundir variables", "La necesidad de chequeo", "Las unidades"], "b", "Sabés qué estás moviendo.", "Procedimiento"),
        q("l2e11", "La lectura pasiva de un manual técnico suele fallar porque:", ["Los manuales no tienen ideas", "No hay pregunta ni reconstrucción", "Siempre faltan fórmulas", "No se puede subrayar"], "b", "Sin actividad, hay ilusión de avance.", "Lectura activa"),
        q("l2e12", "Un chequeo de magnitud pregunta:", ["Si el número 'se siente' razonable en el mundo real", "Si el PDF tiene más de 10 páginas", "Si el resaltador es amarillo", "Si copiaste la clave"], "a", "Sentido común cuantitativo.", "Estimación"),
        q("l2e13", "Explicar a otra persona (o a la pared) sirve para:", ["Perder tiempo", "Detectar lagunas al reconstruir", "Evitar modelos", "Saltar el resumen"], "b", "Lo que no sale oral, no está sólido.", "Comprensión"),
        q("l2e14", "¿Cuál es una pregunta guía útil?", ["¿Cuánto falta para el final?", "¿Qué problema está resolviendo este apartado?", "¿Qué fuente usó el diseñador?", "¿Cuántos títulos hay?"], "b", "Problema primero.", "Lectura activa"),
        q("l2e15", "Datos + incógnita sin puente producen:", ["Una solución inevitable", "Álgebra a ciegas", "Un modelo mental", "Transferencia"], "b", "Falta la relación.", "Procedimiento"),
      ],
    },
  };
}

function levelExamPrep() {
  return {
    id: "demo-l3",
    order: 3,
    title: "Preparación de exámenes",
    methodology: "theory",
    blocks: [
      block(
        "demo-l3-b1",
        1,
        {
          title: "Simulacros y condiciones reales",
          paragraphs: [
            "El examen se entrena con condiciones parecidas: tiempo, sin pistas y sin mirar apuntes.",
            "Un simulacro semanal revela qué falla: contenido, tiempo o nervios.",
            "Después del simulacro, clasificá errores: no sabía / sabía pero dudé / error tonto.",
          ],
          examples: [
            { title: "Protocolo", kind: "case", body: "15 preguntas, 20 minutos, sin teléfono. Al terminar, corrección completa y lista de 3 repasos." },
          ],
        },
        [
          q("l3b1q1", "Un simulacro útil imita:", ["Solo el contenido, con el libro abierto", "Tiempo, reglas y sin pistas", "El diseño de la app", "La conversación con amigos"], "b", "La transferencia al examen real exige condiciones parecidas.", "Simulacro"),
          q("l3b1q2", "Clasificar errores sirve para:", ["Sentirse peor", "Elegir el tipo de repaso correcto", "Evitar el siguiente intento", "Sumar XP infinito"], "b", "No saber ≠ error de atención.", "Errores útiles"),
          q("l3b1q3", "Hacer el simulacro mirando pistas:", ["Entrena el examen real", "Entrena otra tarea más fácil", "Mejora el tiempo límite", "Reemplaza dormir"], "b", "Estás practicando con andamios que el día del examen no tendrás.", "Simulacro"),
          q("l3b1q4", "Si se acaba el tiempo con temas sabidos:", ["Falta contenido solamente", "Falta gestión de tiempo y orden de preguntas", "Hay que subrayar más", "El método Pomodoro es inútil siempre"], "b", "Priorizá preguntas de alto valor y volvé a las dudosas.", "Tiempo de examen"),
          q("l3b1q5", "Después del simulacro, el producto más útil es:", ["La nota sola", "Una lista corta de conceptos a recuperar", "Borrar el intento", "Cambiar de materia"], "b", "La nota informa; el plan de repaso mejora.", "Repaso"),
        ]
      ),
      block(
        "demo-l3-b2",
        2,
        {
          title: "Estrategia durante el examen",
          paragraphs: [
            "Primera pasada: respondé lo seguro. Segunda: lo dudoso. Tercera: las difíciles.",
            "No dejes que una pregunta te robe 8 minutos al inicio.",
            "En opciones múltiples, eliminá absurdos antes de elegir.",
          ],
          code: {
            language: "text",
            source: "para cada pregunta:\n  si es clara y segura: responder\n  si no: marcar y seguir\nrevisar marcadas\nchequear tiempo restante",
            walkthrough: [
              { line: 1, comment: "Recorré todo el examen una vez." },
              { line: 2, comment: "Asegurá puntos fáciles primero." },
              { line: 3, comment: "No te atasques." },
              { line: 4, comment: "Volvé con tiempo reservado." },
              { line: 5, comment: "Los últimos minutos son para revisión, no para panico-leer." },
            ],
          },
        },
        [
          q("l3b2q1", "La primera pasada del examen debería:", ["Atacar la pregunta más difícil", "Asegurar lo que sabés con claridad", "Dejar todo en blanco", "Discutir cada opción 10 minutos"], "b", "Los puntos seguros no se pueden perder por un atasco.", "Estrategia de examen"),
          q("l3b2q2", "Marcar y seguir sirve para:", ["Olvidar las difíciles", "Proteger el tiempo global", "Evitar la corrección", "Copiar después"], "b", "El tiempo es un recurso del conjunto, no de una sola pregunta.", "Tiempo de examen"),
          q("l3b2q3", "Eliminar opciones absurdas es útil porque:", ["Siempre deja una sola respuesta", "Reduce el espacio de error y aclara la comparación", "Está prohibido en exámenes", "Reemplaza estudiar"], "b", "Menos candidatos, mejor juicio.", "Estrategia de examen"),
          q("l3b2q4", "Un algoritmo de examen es útil porque:", ["Hace innecesaria la teoría", "Reduce decisiones bajo estrés", "Garantiza 15/15", "Permite pistas"], "b", "Bajo presión, un procedimiento simple sostiene el rendimiento.", "Estrategia de examen", { type: "fill_code" }),
          q("l3b2q5", "Revisar al final conviene cuando:", ["Cambiás todas las respuestas por nervios", "Hay tiempo y un motivo concreto para dudar", "El enunciado te cae mal", "Querés gastar los minutos"], "b", "Cambiar sin motivo suele empeorar.", "Estrategia de examen"),
        ]
      ),
      block(
        "demo-l3-b3",
        3,
        {
          title: "Repaso inteligente y reintentos",
          paragraphs: [
            "Reintentar el mismo examen memorizando letras (b, c, a) no es aprender.",
            "Rehacé las preguntas falladas con enunciados parafraseados o ejemplos nuevos.",
            "El XP de esta academia no premia repetir exactamente el mismo examen: premia el primer trabajo real.",
          ],
          examples: [
            { title: "Repaso dirigido", kind: "text", body: "Tres conceptos con más fallos → teoría breve → 5 preguntas nuevas de esos conceptos." },
          ],
        },
        [
          q("l3b3q1", "Memorizar la clave 'b-c-a' del intento anterior es:", ["Dominio del tema", "Aprendizaje superficial frágil", "La mejor transferencia", "Un simulacro válido"], "b", "En un examen nuevo esas letras no existen.", "Repaso"),
          q("l3b3q2", "Un reintento útil cambia:", ["Solo el color de la interfaz", "El ángulo de la pregunta o el ejemplo", "La materia completa cada vez", "Las reglas de aprobación"], "b", "Así entrenás el concepto, no la huella visual.", "Repaso"),
          q("l3b3q3", "Repetir el mismo examen para farmar puntos:", ["Demuestra maestría", "No debería sumar XP extra", "Desbloquea siempre un nivel nuevo", "Reemplaza la teoría"], "b", "El motor evita recompensar la repetición idéntica.", "XP"),
          q("l3b3q4", "Si no aprobás (menos de 12/15), lo correcto es:", ["Desbloquear igual el siguiente nivel", "Repasar conceptos débiles y volver a intentar", "Borrar el perfil", "Saltar al examen 3"], "b", "El desbloqueo exige evidencia de dominio.", "Desbloqueo"),
          q("l3b3q5", "Los errores frecuentes deberían convertirse en:", ["Una etiqueta permanente", "Una cola de repaso prioritaria", "Motivo para abandonar", "Prueba de que el quiz es injusto"], "b", "El sistema de recomendaciones existe para eso.", "Errores útiles"),
        ]
      ),
    ],
    exam: {
      id: "demo-l3-exam",
      passScore: 12,
      questions: [
        q("l3e1", "Condiciones reales de simulacro incluyen:", ["WhatsApp abierto", "Tiempo límite y sin pistas", "Libro al lado", "Pistas del quiz guiado"], "b", "El andamiaje se retira en el examen.", "Simulacro"),
        q("l3e2", "Un error 'sabía pero dudé' pide:", ["Más teoría desde cero", "Más práctica cronometrada de discriminación", "Abandonar la materia", "Solo dormir"], "b", "El contenido está; falta decisión bajo tiempo.", "Errores útiles"),
        q("l3e3", "Pasadas del examen: orden recomendado:", ["Difícil → fácil → revisar", "Seguro → dudoso → difícil", "Aleatorio absoluto", "Solo las últimas"], "b", "Asegurá puntos, luego invertí tiempo.", "Estrategia de examen"),
        q("l3e4", "Atascarse 8 minutos en la pregunta 1 suele:", ["Maximizar la nota", "Robar tiempo a preguntas más rentables", "Calmar nervios siempre", "Mejorar la estimación"], "b", "Costo de oportunidad.", "Tiempo de examen"),
        q("l3e5", "Eliminar absurdos es un ejemplo de:", ["Estudio pasivo", "Estrategia de opciones múltiples", "Farm de XP", "Lectura de entretenimiento"], "b", "Reduce alternativas.", "Estrategia de examen"),
        q("l3e6", "El producto de un simulacro no es solo la nota, también:", ["Un ranking social", "Un plan de 3 repasos concretos", "Un cambio de perfil", "Borrar materiales"], "b", "Cierra el ciclo de mejora.", "Repaso"),
        q("l3e7", "Parafrasear una pregunta fallada entrena:", ["La memoria de la letra correcta", "El concepto independiente del wording", "El diseño visual", "La importación JSON"], "b", "Evita anclarte a una frase.", "Repaso"),
        q("l3e8", "Aprobar con 12/15 significa:", ["Perfección absoluta", "Umbral de dominio suficiente para avanzar", "Que no hay que repasar nunca", "Que el nivel siguiente se bloquea"], "b", "12/15 es el criterio de este motor por defecto.", "Desbloqueo"),
        q("l3e9", "Si rehacés el mismo examen idéntico:", ["Deberías ganar otra vez todo el XP", "El XP extra no debe repetirse", "Se borra el progreso anterior", "Se desbloquean dos niveles"], "b", "Anti-granjeo.", "XP"),
        q("l3e10", "Un algoritmo escrito de examen ayuda a:", ["Sustituir estudiar", "Ejecutar bajo estrés un orden simple", "Mostrar pistas", "Saltar bloques de teoría"], "b", "Procedimiento > improvisación paniqueada.", "Estrategia de examen"),
        q("l3e11", "Revisar cambiando respuestas 'por si acaso':", ["Siempre mejora", "Puede empeorar si no hay motivo", "Es obligatorio", "Desbloquea niveles"], "b", "Cambio justificado.", "Estrategia de examen"),
        q("l3e12", "Un error 'no sabía' pide:", ["Solo más velocidad", "Volver a la teoría del concepto", "Memorizar claves ajenas", "Saltar el quiz"], "b", "Hueco de contenido.", "Repaso"),
        q("l3e13", "La recomendación de repaso debería basarse en:", ["El color del botón", "Conceptos con más fallos", "El nombre del perfil", "Archivos más pesados"], "b", "Errores frecuentes.", "Errores útiles"),
        q("l3e14", "Entrenar sin tiempo y rendir con tiempo suele fallar por:", ["Exceso de teoría pura", "Falta de práctica en condiciones reales", "Demasiados resúmenes", "IndexedDB"], "b", "El contexto forma parte de la habilidad.", "Simulacro"),
        q("l3e15", "El siguiente nivel se desbloquea cuando:", ["Abrís la materia", "Aprobás el examen del nivel actual", "Subís un PDF", "Ganás 1 XP"], "b", "Evidencia de dominio del nivel.", "Desbloqueo"),
      ],
    },
  };
}

export function isDemoCourse(definition) {
  return definition?.id === "demo-study-skills" || definition?.source === "demo";
}
