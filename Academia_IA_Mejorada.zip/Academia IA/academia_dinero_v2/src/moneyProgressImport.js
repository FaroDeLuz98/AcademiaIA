// src/moneyProgressImport.js
// Importación explícita y opcional del progreso de la app original Academia del Dinero.
// Nunca se ejecuta sola: la interfaz pide confirmación al estudiante.

import { sortedLevels, sortedBlocks } from "./courseEngine.js";

export const LEGACY_MONEY_KEY = "academia-dinero-v1";

export function readLegacyMoneyState(storage = globalThis.localStorage) {
  if (!storage) return null;
  let raw = null;
  try {
    raw = storage.getItem(LEGACY_MONEY_KEY);
  } catch {
    return null;
  }
  if (!raw) return null;
  try {
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return null;
    return data;
  } catch {
    return null;
  }
}

export function summarizeLegacyMoneyState(legacy) {
  if (!legacy) return { available: false };
  const parts = legacy.parts && typeof legacy.parts === "object" ? legacy.parts : {};
  const exams = legacy.exams && typeof legacy.exams === "object" ? legacy.exams : {};
  const completedParts = Object.values(parts).filter(Boolean).length;
  const passedLevels = Object.values(exams).filter((e) => e && e.passed).length;
  const xp = Number.isFinite(legacy.xp) ? legacy.xp : 0;
  return {
    available: true,
    completedParts,
    passedLevels,
    xp,
    hasData: completedParts > 0 || passedLevels > 0 || xp > 0,
  };
}

export function mergeLegacyMoneyProgress(progress, course, legacy) {
  if (!legacy) return progress;
  const next = JSON.parse(JSON.stringify(progress));
  const levels = sortedLevels(course);
  const byOrder = new Map(levels.map((level) => [level.order ?? levels.indexOf(level) + 1, level]));

  next.completedBlocks = next.completedBlocks || {};
  next.quizAnswers = next.quizAnswers || {};
  next.awardedQuestionIds = next.awardedQuestionIds || [];
  next.awardedExamKeys = next.awardedExamKeys || [];
  next.examAttempts = next.examAttempts || [];
  next.passedLevelIds = next.passedLevelIds || [];
  next.unlockedLevelIds = next.unlockedLevelIds || [];
  next.frequentErrors = next.frequentErrors || {};

  const parts = legacy.parts && typeof legacy.parts === "object" ? legacy.parts : {};
  for (const [key, done] of Object.entries(parts)) {
    if (!done) continue;
    const match = /^(\d+)-(\d+)$/.exec(key);
    if (!match) continue;
    const level = byOrder.get(Number(match[1]));
    const partIndex = Number(match[2]);
    if (!level) continue;
    const block = sortedBlocks(level)[partIndex];
    if (!block) continue;
    const list = next.completedBlocks[level.id] || [];
    if (!list.includes(block.id)) list.push(block.id);
    next.completedBlocks[level.id] = list;
  }

  const exams = legacy.exams && typeof legacy.exams === "object" ? legacy.exams : {};
  for (const [key, exam] of Object.entries(exams)) {
    if (!exam) continue;
    const level = byOrder.get(Number(key));
    if (!level) continue;
    if (exam.passed && !next.passedLevelIds.includes(level.id)) {
      next.passedLevelIds.push(level.id);
    }
    const total = level.exam?.questions?.length || 0;
    const best = Number(exam.best);
    if (Number.isFinite(best) && total > 0) {
      const already = next.examAttempts.some(
        (a) => a.levelId === level.id && a.importedFrom === "academia-del-dinero"
      );
      if (!already) {
        next.examAttempts.push({
          levelId: level.id,
          examId: level.exam?.id || "exam",
          contentKey: level.id + ":imported:" + key,
          correct: Math.round((best / 100) * total),
          total,
          passed: !!exam.passed,
          answers: {},
          xpGained: 0,
          at: new Date().toISOString(),
          importedFrom: "academia-del-dinero",
          importedBestPercent: best,
          source: exam.source || "",
        });
      }
    }
  }

  if (levels[0] && !next.unlockedLevelIds.includes(levels[0].id)) {
    next.unlockedLevelIds.unshift(levels[0].id);
  }
  const passedSet = new Set(next.passedLevelIds);
  levels.forEach((level, index) => {
    if (!passedSet.has(level.id)) return;
    const follower = levels[index + 1];
    if (follower && !next.unlockedLevelIds.includes(follower.id)) {
      next.unlockedLevelIds.push(follower.id);
    }
  });

  const legacyXp = Number(legacy.xp);
  if (Number.isFinite(legacyXp) && legacyXp > (next.xp || 0)) next.xp = legacyXp;

  const firstOpen = levels.find((l) => !passedSet.has(l.id)) || levels[levels.length - 1] || null;
  next.lastSession = {
    view: "path",
    levelId: firstOpen?.id || null,
    blockId: null,
    phase: null,
    blockIndex: 0,
    questionIndex: 0,
    at: new Date().toISOString(),
  };
  next.importedFrom = "academia-del-dinero";
  next.importedAt = new Date().toISOString();
  next.updatedAt = new Date().toISOString();
  return next;
}
