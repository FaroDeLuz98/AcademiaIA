// src/exportImport.js
import { getActiveProfileId, setActiveProfileId } from "./storage.js";
import { buildExportPayload, importPayload } from "./courseStore.js";

const exportBtn = document.getElementById("exportProfileBtn");
const importBtn = document.getElementById("importProfileBtn");

function downloadJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

exportBtn?.addEventListener("click", async () => {
  const profileId = getActiveProfileId();
  if (!profileId) {
    alert("Selecciona un perfil antes de exportar");
    return;
  }
  try {
    const payload = await buildExportPayload(profileId);
    downloadJSON(payload, `perfil_${payload.profile.id}.json`);
  } catch (err) {
    alert("Error al exportar: " + err.message);
  }
});

async function handleImportFile(file) {
  const text = await file.text();
  const data = JSON.parse(text);
  const result = await importPayload(data);
  setActiveProfileId(result.profileId);
  if (window.renderProfiles) window.renderProfiles();
  if (window.renderSubjects) window.renderSubjects();
  if (window.renderMainPanel) window.renderMainPanel();
  alert("Perfil importado exitosamente");
  return result;
}

importBtn?.addEventListener("click", async () => {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json";
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      await handleImportFile(file);
    } catch (err) {
      console.error(err);
      alert("Error al importar: " + err.message);
    }
  };
  input.click();
});

window.importAcademiaPayload = async function (data) {
  const result = await importPayload(data);
  setActiveProfileId(result.profileId);
  if (window.renderProfiles) await window.renderProfiles();
  if (window.renderSubjects) await window.renderSubjects();
  if (window.renderMainPanel) await window.renderMainPanel();
  return result;
};
