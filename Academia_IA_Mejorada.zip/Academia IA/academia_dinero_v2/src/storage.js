// src/storage.js
// IndexedDB storage layer for Academia IA

const DB_NAME = "academia_ia";
const DB_VERSION = 3;
const PROFILE_STORE = "profiles";
const SUBJECT_STORE = "subjects";
const MATERIAL_STORE = "materials";
export const COURSE_STORE = "courses";
export const PROGRESS_STORE = "progress";
export const BACKUP_STORE = "backups";

let pendingUpgradeBackup = false;

export function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      resolve(db);
      if (pendingUpgradeBackup) {
        pendingUpgradeBackup = false;
        snapshotBackup("upgrade-to-v3").catch(() => {});
      }
    };
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (event.oldVersion > 0 && event.oldVersion < DB_VERSION) {
        pendingUpgradeBackup = true;
      }
      if (!db.objectStoreNames.contains(PROFILE_STORE)) {
        db.createObjectStore(PROFILE_STORE, { keyPath: "id", autoIncrement: true });
      }
      if (!db.objectStoreNames.contains(SUBJECT_STORE)) {
        const subjectStore = db.createObjectStore(SUBJECT_STORE, { keyPath: "id", autoIncrement: true });
        subjectStore.createIndex("profileId", "profileId", { unique: false });
      }
      if (!db.objectStoreNames.contains(MATERIAL_STORE)) {
        const materialStore = db.createObjectStore(MATERIAL_STORE, { keyPath: "id", autoIncrement: true });
        materialStore.createIndex("subjectId", "subjectId", { unique: false });
        materialStore.createIndex("profileId", "profileId", { unique: false });
      }
      if (!db.objectStoreNames.contains(COURSE_STORE)) {
        const courseStore = db.createObjectStore(COURSE_STORE, { keyPath: "id", autoIncrement: true });
        courseStore.createIndex("profileId", "profileId", { unique: false });
        courseStore.createIndex("subjectId", "subjectId", { unique: false });
        courseStore.createIndex("profileSubject", ["profileId", "subjectId"], { unique: false });
      }
      if (!db.objectStoreNames.contains(PROGRESS_STORE)) {
        const progressStore = db.createObjectStore(PROGRESS_STORE, { keyPath: "id", autoIncrement: true });
        progressStore.createIndex("profileId", "profileId", { unique: false });
        progressStore.createIndex("subjectId", "subjectId", { unique: false });
        progressStore.createIndex("courseId", "courseId", { unique: false });
        progressStore.createIndex("profileSubject", ["profileId", "subjectId"], { unique: false });
      } else {
        const progressStore = event.target.transaction.objectStore(PROGRESS_STORE);
        if (!progressStore.indexNames.contains("subjectId")) {
          progressStore.createIndex("subjectId", "subjectId", { unique: false });
        }
      }
      if (!db.objectStoreNames.contains(BACKUP_STORE)) {
        db.createObjectStore(BACKUP_STORE, { keyPath: "id", autoIncrement: true });
      }
    };
  });
}

function txGetAll(db, storeName) {
  if (!db.objectStoreNames.contains(storeName)) return Promise.resolve([]);
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const request = tx.objectStore(storeName).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function snapshotBackup(reason = "manual") {
  const db = await openDB();
  const profiles = await txGetAll(db, PROFILE_STORE);
  const subjects = await txGetAll(db, SUBJECT_STORE);
  const materials = await txGetAll(db, MATERIAL_STORE);
  const courses = await txGetAll(db, COURSE_STORE);
  const progress = await txGetAll(db, PROGRESS_STORE);
  const record = {
    reason,
    createdAt: new Date().toISOString(),
    dbVersion: DB_VERSION,
    profiles,
    subjects,
    courses,
    progress,
    materials: materials.map((m) => ({
      ...m,
      content: typeof m.content === "string" ? m.content.slice(0, 8000) : m.content,
    })),
  };
  return new Promise((resolve, reject) => {
    const tx = db.transaction(BACKUP_STORE, "readwrite");
    const request = tx.objectStore(BACKUP_STORE).add(record);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function deleteByIndex(storeName, indexName, value) {
  const db = await openDB();
  if (!db.objectStoreNames.contains(storeName)) return;
  const items = await new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    if (!store.indexNames.contains(indexName)) {
      resolve([]);
      return;
    }
    const request = store.index(indexName).getAll(value);
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
  for (const item of items) {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      const request = tx.objectStore(storeName).delete(item.id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
}

// ── Profile CRUD ──

export async function addProfile(name) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROFILE_STORE, "readwrite");
    const store = tx.objectStore(PROFILE_STORE);
    const request = store.add({ name });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllProfiles() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROFILE_STORE, "readonly");
    const store = tx.objectStore(PROFILE_STORE);
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function updateProfile(id, name) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROFILE_STORE, "readwrite");
    const store = tx.objectStore(PROFILE_STORE);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const profile = getReq.result;
      if (!profile) { reject(new Error("Profile not found")); return; }
      profile.name = name;
      const putReq = store.put(profile);
      putReq.onsuccess = () => resolve();
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function deleteProfile(id) {
  // cascade delete subjects and materials for this profile
  const subjects = await getSubjectsByProfile(id);
  for (const sub of subjects) {
    await deleteSubject(sub.id);
  }
  // delete any remaining materials linked to profile
  const materials = await getMaterials(id);
  for (const mat of materials) {
    await deleteMaterial(mat.id);
  }
  await deleteByIndex(COURSE_STORE, "profileId", id);
  await deleteByIndex(PROGRESS_STORE, "profileId", id);
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PROFILE_STORE, "readwrite");
    const store = tx.objectStore(PROFILE_STORE);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// ── Subject CRUD ──

export async function addSubject(profileId, name, level) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SUBJECT_STORE, "readwrite");
    const store = tx.objectStore(SUBJECT_STORE);
    const request = store.add({ profileId, name, level: level || "" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getSubjectsByProfile(profileId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SUBJECT_STORE, "readonly");
    const store = tx.objectStore(SUBJECT_STORE);
    const index = store.index("profileId");
    const request = index.getAll(profileId);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function updateSubject(id, data) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SUBJECT_STORE, "readwrite");
    const store = tx.objectStore(SUBJECT_STORE);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const subject = getReq.result;
      if (!subject) { reject(new Error("Subject not found")); return; }
      if (data.name !== undefined) subject.name = data.name;
      if (data.level !== undefined) subject.level = data.level;
      const putReq = store.put(subject);
      putReq.onsuccess = () => resolve();
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function deleteSubject(id) {
  // cascade delete materials for this subject
  const db = await openDB();
  const materials = await new Promise((resolve, reject) => {
    const tx = db.transaction(MATERIAL_STORE, "readonly");
    const store = tx.objectStore(MATERIAL_STORE);
    const index = store.index("subjectId");
    const request = index.getAll(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  for (const mat of materials) {
    await deleteMaterial(mat.id);
  }
  await deleteByIndex(COURSE_STORE, "subjectId", id);
  await deleteByIndex(PROGRESS_STORE, "subjectId", id);
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SUBJECT_STORE, "readwrite");
    const store = tx.objectStore(SUBJECT_STORE);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// ── Material CRUD ──

export async function addMaterial(material) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(MATERIAL_STORE, "readwrite");
    const store = tx.objectStore(MATERIAL_STORE);
    const request = store.add(material);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getMaterials(profileId, subjectId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(MATERIAL_STORE, "readonly");
    const store = tx.objectStore(MATERIAL_STORE);
    if (subjectId !== undefined) {
      const index = store.index("subjectId");
      const request = index.getAll(subjectId);
      request.onsuccess = () => {
        const results = request.result.filter(m => m.profileId === profileId);
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    } else {
      const index = store.index("profileId");
      const request = index.getAll(profileId);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    }
  });
}

export async function updateMaterial(id, data) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(MATERIAL_STORE, "readwrite");
    const store = tx.objectStore(MATERIAL_STORE);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const material = getReq.result;
      if (!material) { reject(new Error("Material not found")); return; }
      if (data.name !== undefined) material.name = data.name;
      if (data.content !== undefined) material.content = data.content;
      if (data.fileType !== undefined) material.fileType = data.fileType;
      const putReq = store.put(material);
      putReq.onsuccess = () => resolve();
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function deleteMaterial(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(MATERIAL_STORE, "readwrite");
    const store = tx.objectStore(MATERIAL_STORE);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// ── Active Profile ──

export function setActiveProfileId(id) {
  localStorage.setItem("academia_ia_current_profile", String(id));
}

export function getActiveProfileId() {
  const val = localStorage.getItem("academia_ia_current_profile");
  return val ? Number(val) : null;
}

export function setActiveSubjectId(id) {
  if (id == null) localStorage.removeItem("academia_ia_current_subject");
  else localStorage.setItem("academia_ia_current_subject", String(id));
}

export function getActiveSubjectId() {
  const val = localStorage.getItem("academia_ia_current_subject");
  return val ? Number(val) : null;
}
