// src/material.js
// UI & logic for managing materials (documents) per subject
import { getActiveProfileId, addMaterial, getMaterials, deleteMaterial, updateMaterial } from "./storage.js";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const ALLOWED_TYPES = [".pdf", ".docx", ".txt"];

/**
 * Extract text content from a File object.
 * @param {File} file
 * @returns {Promise<string>} extracted text
 */
export async function extractFile(file) {
  const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();

  if (!ALLOWED_TYPES.includes(ext)) {
    throw new Error("Tipo de archivo no soportado. Solo se permiten: " + ALLOWED_TYPES.join(", "));
  }
  if (file.size > MAX_FILE_SIZE) {
    throw new Error("El archivo excede el tamaño máximo de 10 MB.");
  }

  if (ext === ".txt") {
    return await file.text();
  }

  if (ext === ".pdf") {
    const pdfjsLib = await import("./libs/pdf.min.mjs");
    pdfjsLib.GlobalWorkerOptions.workerSrc = "./libs/pdf.worker.min.mjs";
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items.map((item) => item.str).join(" ");
      fullText += `[Página ${i}]\n${pageText}\n\n`;
    }
    if (!fullText.replace(/\[Página \d+\]\s*/g, "").trim()) {
      return "Este PDF parece ser una imagen escaneada. Se necesita OCR para extraer el texto.";
    }
    return fullText.trim();
  }

  if (ext === ".docx") {
    // mammoth is loaded as a global script from local libs
    if (typeof mammoth === "undefined") {
      // Try to load it dynamically
      await new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "./libs/mammoth.browser.min.js";
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
    }
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  }

  throw new Error("Tipo de archivo no soportado.");
}

function getFileTypeIcon(name) {
  const ext = name.slice(name.lastIndexOf(".")).toLowerCase();
  if (ext === ".pdf") return "📄";
  if (ext === ".docx") return "📝";
  if (ext === ".txt") return "📃";
  return "📎";
}

// ── Material list rendering ──

async function renderMaterials(subjectId) {
  const container = document.getElementById("materialList");
  if (!container) return;
  const profileId = getActiveProfileId();
  if (!profileId || !subjectId) {
    container.innerHTML = "<p class='muted'>Selecciona una materia para ver materiales.</p>";
    return;
  }
  const materials = await getMaterials(profileId, subjectId);
  if (materials.length === 0) {
    container.innerHTML = "<p class='muted'>No hay materiales. Sube un archivo para comenzar.</p>";
    return;
  }
  container.innerHTML = materials
    .map(
      (m) => `
    <li class="material-item" data-id="${m.id}">
      <span class="material-icon">${getFileTypeIcon(m.name)}</span>
      <span class="material-name">${m.name}</span>
      <button class="secondary" data-action="view" data-id="${m.id}">Ver</button>
      <button class="secondary" data-action="rename" data-id="${m.id}">Renombrar</button>
      <button class="secondary" data-action="delete" data-id="${m.id}">Eliminar</button>
    </li>`
    )
    .join("");

  // Attach listeners
  container.querySelectorAll("button").forEach((btn) => {
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id);
    btn.onclick = async () => {
      if (action === "view") {
        const mat = materials.find((m) => m.id === id);
        showPreviewPanel(mat);
      } else if (action === "rename") {
        const newName = prompt("Nuevo nombre:");
        if (newName && newName.trim()) {
          await updateMaterial(id, { name: newName.trim() });
          renderMaterials(subjectId);
        }
      } else if (action === "delete") {
        if (confirm("¿Eliminar este material?")) {
          await deleteMaterial(id);
          renderMaterials(subjectId);
        }
      }
    };
  });
}

function showPreviewPanel(material) {
  let panel = document.getElementById("materialPreview");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "materialPreview";
    panel.className = "material-preview";
    document.body.appendChild(panel);
  }
  panel.innerHTML = `
    <div class="preview-header">
      <h3>${getFileTypeIcon(material.name)} ${material.name}</h3>
      <button id="closePreview" class="secondary">Cerrar</button>
    </div>
    <pre class="preview-content">${escapeHtml(material.content)}</pre>
  `;
  panel.style.display = "block";
  document.getElementById("closePreview").onclick = () => {
    panel.style.display = "none";
  };
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text || "";
  return div.innerHTML;
}

// ── File upload handling ──

function setupUpload() {
  const uploadBtn = document.getElementById("uploadMaterialBtn");
  const fileInput = document.getElementById("materialFileInput");
  if (!uploadBtn || !fileInput) return;

  uploadBtn.onclick = () => fileInput.click();

  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();
    if (!ALLOWED_TYPES.includes(ext)) {
      alert("Tipo de archivo no soportado. Solo se permiten: " + ALLOWED_TYPES.join(", "));
      fileInput.value = "";
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      alert("El archivo excede el tamaño máximo de 10 MB.");
      fileInput.value = "";
      return;
    }

    // Show loading
    const loadingEl = document.getElementById("materialLoading");
    if (loadingEl) loadingEl.style.display = "block";

    try {
      const content = await extractFile(file);

      // Show preview before confirming
      const previewEl = document.getElementById("materialUploadPreview");
      if (previewEl) {
        previewEl.innerHTML = `
          <h4>Vista previa: ${file.name}</h4>
          <pre class="preview-content">${escapeHtml(content.substring(0, 2000))}${content.length > 2000 ? "\n..." : ""}</pre>
          <button id="confirmUpload" class="primary">Confirmar</button>
          <button id="cancelUpload" class="secondary">Cancelar</button>
        `;
        previewEl.style.display = "block";

        document.getElementById("confirmUpload").onclick = async () => {
          const profileId = getActiveProfileId();
          const subjectId = window._currentSubjectId;
          if (!profileId || !subjectId) {
            alert("Selecciona un perfil y una materia.");
            return;
          }
          await addMaterial({
            profileId,
            subjectId,
            name: file.name,
            fileType: ext,
            content,
            createdAt: new Date().toISOString(),
          });
          previewEl.style.display = "none";
          renderMaterials(subjectId);
        };
        document.getElementById("cancelUpload").onclick = () => {
          previewEl.style.display = "none";
        };
      }
    } catch (err) {
      alert("Error al procesar archivo: " + err.message);
    } finally {
      if (loadingEl) loadingEl.style.display = "none";
      fileInput.value = "";
    }
  };
}

// ── Expose refresh function globally ──

window.refreshMaterials = function (subjectId) {
  const sid = subjectId || window._currentSubjectId;
  if (sid) renderMaterials(sid);
};

// Initialize when DOM is ready
if (typeof document !== "undefined" && document.getElementById("materialList")) {
  setupUpload();
}
