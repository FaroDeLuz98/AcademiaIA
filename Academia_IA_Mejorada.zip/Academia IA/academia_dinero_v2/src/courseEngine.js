// src/courseEngine.js
// Motor educativo reutilizable. No está acoplado a Economía ni a un número fijo de niveles.

export const COURSE_SCHEMA_VERSION = 1;

export const XP_RULES = {
  QUIZ_CORRECT: 10,
  EXAM_CORRECT: 4,
  EXAM_PASS_BONUS: 30,
};

export const METHODOLOGIES = {
  theory: "theory",
  stem: "stem",
  programming: "programming",
};

export function validateCourse(definition) {
  if (!definition || typeof definition !== "object") {
    throw new Error("El curso debe ser un objeto JSON.");
  }
  if (definition.schemaVersion !== COURSE_SCHEMA_VERSION) {
    throw new Error("Versión de curso no soportada. Se espera schemaVersion " + COURSE_SCHEMA_VERSION + ".");
  }
  if (!definition.title) throw new Error("El curso necesita un título.");
  if (!definition.methodology || !METHODOLOGIES[definition.methodology]) {
    throw new Error("Metodología inválida. Usá theory, stem o programming.");
  }
  if (!Array.isArray(definition.levels) || definition.levels.length === 0) {
    throw new Error("El curso necesita al menos un nivel.");
  }
  const levelIds = new Set();
  for (const level of definition.levels) {
    if (!level.id || !level.title) throw new Error("Cada nivel necesita id y título.");
    if (levelIds.has(level.id)) throw new Error("Ids de nivel duplicados: " + level.id);
    levelIds.add(level.id);
    if (!Array.isArray(level.blocks) || level.blocks.length === 0) {
      throw new Error("El nivel " + level.id + " necesita bloques de teoría/quiz.");
    }
    for (const block of level.blocks) {
      if (!block.id || !block.theory || !block.quiz) {
        throw new Error("Cada bloque necesita id, theory y quiz.");
      }
      validateQuestionList(block.quiz.questions, "quiz " + block.id);
    }
    if (!level.exam || !Array.isArray(level.exam.questions) || level.exam.questions.length === 0) {
      throw new Error("El nivel " + level.id + " necesita un examen final.");
    }
    validateQuestionList(level.exam.questions, "examen " + level.id);
  }
  return true;
}

function validateQuestionList(questions, label) {
  if (!Array.isArray(questions) || questions.length === 0) {
    throw new Error("No hay preguntas en " + label);
  }
  for (const q of questions) {
    if (!q.id || !q.prompt) throw new Error("Pregunta incompleta en " + label);
    if (!Array.isArray(q.options) || q.options.length < 2) {
      throw new Error("La pregunta " + q.id + " necesita opciones.");
    }
    if (!q.options.some((o) => o.id === q.correctOptionId)) {
      throw new Error("La pregunta " + q.id + " no tiene opción correcta válida.");
    }
  }
}

export function sortedLevels(course) {
  return [...(course?.levels || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

export function sortedBlocks(level) {
  return [...(level?.blocks || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

export function createInitialProgress(profileId, subjectId, courseId, course) {
  const levels = sortedLevels(course);
  const first = levels[0];
  return {
    profileId,
    subjectId,
    courseId,
    xp: 0,
    unlockedLevelIds: first ? [first.id] : [],
    passedLevelIds: [],
    completedBlocks: {},
    awardedQuestionIds: [],
    awardedExamKeys: [],
    quizAnswers: {},
    examAttempts: [],
    frequentErrors: {},
    lastSession: {
      view: "path",
      levelId: first?.id || null,
      blockId: null,
      phase: null,
      questionIndex: 0,
      at: nowIso(),
    },
    updatedAt: nowIso(),
  };
}

export function cloneProgress(progress) {
  return JSON.parse(JSON.stringify(progress));
}

export function getLevelById(course, levelId) {
  return sortedLevels(course).find((l) => l.id === levelId) || null;
}

export function getLevelStatus(course, progress, levelId) {
  const levels = sortedLevels(course);
  const level = levels.find((l) => l.id === levelId);
  if (!level) return "missing";
  if ((progress.passedLevelIds || []).includes(levelId)) return "passed";
  if ((progress.unlockedLevelIds || []).includes(levelId)) return "available";
  return "locked";
}

export function isLevelOpen(progress, levelId) {
  return (progress.unlockedLevelIds || []).includes(levelId);
}

export function getLevelDisplayStatus(course, progress, levelId) {
  const base = getLevelStatus(course, progress, levelId);
  if (base !== "available") return base;
  const level = getLevelById(course, levelId);
  if (!level) return base;
  const startedBlocks = ((progress.completedBlocks || {})[levelId] || []).length > 0;
  const levelQuestionIds = new Set();
  for (const block of sortedBlocks(level)) {
    for (const q of block.quiz?.questions || []) levelQuestionIds.add(q.id);
  }
  for (const q of level.exam?.questions || []) levelQuestionIds.add(q.id);
  const answered = Object.keys(progress.quizAnswers || {}).some((qid) => levelQuestionIds.has(qid));
  const attempted = (progress.examAttempts || []).some((a) => a.levelId === levelId);
  return startedBlocks || answered || attempted ? "in_progress" : "available";
}

export function getLevelExamSummary(progress, levelId) {
  const attempts = (progress.examAttempts || []).filter((a) => a.levelId === levelId);
  if (!attempts.length) return { attempts: 0, bestPercent: null, passed: false, lastPercent: null };
  let best = 0;
  let last = 0;
  let passed = false;
  for (const attempt of attempts) {
    const pct = attempt.total ? Math.round((attempt.correct / attempt.total) * 100) : 0;
    if (pct > best) best = pct;
    last = pct;
    if (attempt.passed) passed = true;
  }
  return { attempts: attempts.length, bestPercent: best, lastPercent: last, passed };
}

export function getCourseProgressPercent(course, progress) {
  const levels = sortedLevels(course);
  if (!levels.length) return 0;
  const passed = levels.filter((l) => (progress.passedLevelIds || []).includes(l.id)).length;
  return Math.round((passed / levels.length) * 100);
}

export function getLevelProgressPercent(level, progress) {
  const blocks = sortedBlocks(level);
  const examWeight = 1;
  const total = blocks.length + examWeight;
  const doneBlocks = blocks.filter((b) => isBlockComplete(progress, level.id, b.id)).length;
  const examDone = (progress.passedLevelIds || []).includes(level.id) ? 1 : 0;
  return Math.round(((doneBlocks + examDone) / total) * 100);
}

export function isBlockComplete(progress, levelId, blockId) {
  return ((progress.completedBlocks || {})[levelId] || []).includes(blockId);
}

export function allBlocksComplete(level, progress) {
  return sortedBlocks(level).every((b) => isBlockComplete(progress, level.id, b.id));
}

export function canStartExam(level, progress) {
  return allBlocksComplete(level, progress);
}

export function nextLevel(course, levelId) {
  const levels = sortedLevels(course);
  const index = levels.findIndex((l) => l.id === levelId);
  if (index < 0 || index === levels.length - 1) return null;
  return levels[index + 1];
}

export function currentAvailableLevel(course, progress) {
  const levels = sortedLevels(course);
  const unlocked = progress.unlockedLevelIds || [];
  const passed = progress.passedLevelIds || [];
  return levels.find((l) => unlocked.includes(l.id) && !passed.includes(l.id)) || levels.find((l) => unlocked.includes(l.id)) || levels[0] || null;
}

export function gradeQuestion(question, optionId) {
  const correct = question.correctOptionId === optionId;
  const selected = (question.options || []).find((o) => o.id === optionId) || null;
  const right = (question.options || []).find((o) => o.id === question.correctOptionId) || null;
  return {
    correct,
    selectedOptionId: optionId,
    correctOptionId: question.correctOptionId,
    selectedText: selected?.text || "",
    correctText: right?.text || "",
    explanation: question.explanation || "",
    relatedConcept: question.relatedConcept || question.concept || "",
    revealCorrect: true,
  };
}

export function answerQuiz(progress, question, optionId) {
  const next = cloneProgress(progress);
  const result = gradeQuestion(question, optionId);
  if (!next.quizAnswers) next.quizAnswers = {};
  next.quizAnswers[question.id] = {
    selectedOptionId: optionId,
    correct: result.correct,
    at: nowIso(),
  };
  let xpGained = 0;
  if (result.correct && !(next.awardedQuestionIds || []).includes(question.id)) {
    xpGained = XP_RULES.QUIZ_CORRECT;
    next.awardedQuestionIds = [...(next.awardedQuestionIds || []), question.id];
    next.xp = (next.xp || 0) + xpGained;
  }
  if (!result.correct) {
    const concept = result.relatedConcept || "general";
    next.frequentErrors = next.frequentErrors || {};
    next.frequentErrors[concept] = (next.frequentErrors[concept] || 0) + 1;
  }
  next.updatedAt = nowIso();
  return { progress: next, result, xpGained };
}

export function completeBlock(progress, levelId, blockId) {
  const next = cloneProgress(progress);
  if (!next.completedBlocks) next.completedBlocks = {};
  const list = next.completedBlocks[levelId] || [];
  if (!list.includes(blockId)) list.push(blockId);
  next.completedBlocks[levelId] = list;
  next.updatedAt = nowIso();
  return next;
}

export function examContentKey(level, exam) {
  const ids = (exam.questions || []).map((q) => q.id).join(",");
  return level.id + ":" + (exam.id || "exam") + ":" + ids;
}

export function gradeExam(exam, answersMap) {
  const details = (exam.questions || []).map((question) => {
    const selectedOptionId = answersMap?.[question.id];
    const graded = gradeQuestion(question, selectedOptionId);
    return {
      questionId: question.id,
      prompt: question.prompt,
      selectedOptionId,
      correct: graded.correct,
      correctOptionId: question.correctOptionId,
      explanation: question.explanation || "",
      relatedConcept: question.relatedConcept || "",
      selectedText: graded.selectedText,
      correctText: graded.correctText,
    };
  });
  const correct = details.filter((d) => d.correct).length;
  const total = details.length;
  const passScore = exam.passScore ?? Math.ceil(total * 0.8);
  return { correct, total, passScore, passed: correct >= passScore, details };
}

export function applyExamResult(progress, course, level, exam, answersMap) {
  const next = cloneProgress(progress);
  const result = gradeExam(exam, answersMap);
  const key = examContentKey(level, exam);
  let xpGained = 0;
  const alreadyAwarded = (next.awardedExamKeys || []).includes(key);
  if (!alreadyAwarded) {
    xpGained = result.correct * XP_RULES.EXAM_CORRECT;
    if (result.passed) xpGained += XP_RULES.EXAM_PASS_BONUS;
    next.awardedExamKeys = [...(next.awardedExamKeys || []), key];
    next.xp = (next.xp || 0) + xpGained;
  }
  next.examAttempts = [
    ...(next.examAttempts || []),
    {
      levelId: level.id,
      examId: exam.id || "exam",
      contentKey: key,
      correct: result.correct,
      total: result.total,
      passed: result.passed,
      answers: answersMap,
      xpGained,
      at: nowIso(),
    },
  ];
  for (const detail of result.details) {
    if (!detail.correct) {
      const concept = detail.relatedConcept || "general";
      next.frequentErrors = next.frequentErrors || {};
      next.frequentErrors[concept] = (next.frequentErrors[concept] || 0) + 1;
    }
  }
  let unlockedLevelId = null;
  if (result.passed && !(next.passedLevelIds || []).includes(level.id)) {
    next.passedLevelIds = [...(next.passedLevelIds || []), level.id];
    const nxt = nextLevel(course, level.id);
    if (nxt && !(next.unlockedLevelIds || []).includes(nxt.id)) {
      next.unlockedLevelIds = [...next.unlockedLevelIds, nxt.id];
      unlockedLevelId = nxt.id;
    }
  }
  next.updatedAt = nowIso();
  return { progress: next, result, xpGained, alreadyAwarded, unlockedLevelId };
}

export function recommendReviews(progress, course, limit = 3) {
  const errors = Object.entries(progress.frequentErrors || {}).sort((a, b) => b[1] - a[1]);
  if (!errors.length) {
    return [{ title: "Seguí el camino", detail: "No hay errores frecuentes. Continuá con el siguiente bloque disponible." }];
  }
  return errors.slice(0, limit).map(([concept, count]) => ({
    title: concept,
    detail: "Fallaste este concepto " + count + " vez(ces). Repasá la teoría relacionada antes de reintentar.",
    concept,
    count,
  }));
}

export function touchSession(progress, patch) {
  const next = cloneProgress(progress);
  next.lastSession = { ...(next.lastSession || {}), ...patch, at: nowIso() };
  next.updatedAt = nowIso();
  return next;
}

export function getTheoryViewModel(block, methodology) {
  const theory = block.theory || {};
  const method = theory.methodology || methodology || METHODOLOGIES.theory;
  return {
    id: block.id,
    title: theory.title || block.title || "Teoría",
    methodology: method,
    paragraphs: theory.paragraphs || [],
    examples: theory.examples || [],
    cases: theory.cases || [],
    formulas: theory.formulas || [],
    procedure: theory.procedure || [],
    code: theory.code || null,
  };
}

export function profileStats(coursesWithProgress) {
  let xp = 0;
  let passedLevels = 0;
  let totalLevels = 0;
  let lastSession = null;
  for (const item of coursesWithProgress) {
    xp += item.progress?.xp || 0;
    const levels = sortedLevels(item.course);
    totalLevels += levels.length;
    passedLevels += (item.progress?.passedLevelIds || []).length;
    const session = item.progress?.lastSession;
    if (session && (!lastSession || session.at > lastSession.at)) {
      lastSession = { ...session, courseId: item.courseRecord?.id, subjectId: item.progress.subjectId };
    }
  }
  const percent = totalLevels ? Math.round((passedLevels / totalLevels) * 100) : 0;
  return { xp, passedLevels, totalLevels, percent, lastSession };
}

export function shuffleOptions(q) {
  if (!q || !Array.isArray(q.options)) return q;
  const shuffled = [...q.options].sort(() => Math.random() - 0.5);
  return { ...q, options: shuffled };
}

export function getPriorLevels(course, targetLevelId) {
  const levels = sortedLevels(course);
  const targetIndex = levels.findIndex((l) => l.id === targetLevelId);
  if (targetIndex <= 0) return [];
  return levels.slice(0, targetIndex);
}

export function createSkipExam(course, targetLevelId) {
  const priorLevels = getPriorLevels(course, targetLevelId);
  if (!priorLevels.length) return null;
  const targetLevel = getLevelById(course, targetLevelId);
  if (!targetLevel) return null;

  const pool = [];
  for (const lvl of priorLevels) {
    for (const q of lvl.exam?.questions || []) {
      pool.push({ ...q, fromLevel: lvl.title });
    }
  }

  const questionsPerLevel = Math.max(2, Math.floor(15 / priorLevels.length));
  let selected = [];
  for (const lvl of priorLevels) {
    const lvlExamQs = lvl.exam?.questions || [];
    const shuffledLvl = [...lvlExamQs].sort(() => Math.random() - 0.5);
    selected.push(...shuffledLvl.slice(0, questionsPerLevel));
  }

  if (selected.length < 10) {
    const remaining = pool.filter((q) => !selected.some((sq) => sq.id === q.id));
    selected.push(...remaining.slice(0, 10 - selected.length));
  }

  selected = selected.sort(() => Math.random() - 0.5).map((q) => shuffleOptions(q));
  const total = selected.length;
  const passScore = Math.ceil(total * 0.75);

  return {
    id: `skip-exam-to-${targetLevelId}`,
    isSkipExam: true,
    targetLevelId,
    targetLevelTitle: targetLevel.title,
    priorLevelsCount: priorLevels.length,
    title: `Examen de suficiencia para acceder a ${targetLevel.title}`,
    description: `Este examen integrador contiene ${total} preguntas que evalúan los contenidos de todos los niveles anteriores (${priorLevels.map((l) => l.title).join(", ")}). Aprobás con ${passScore}/${total}.`,
    passScore,
    questions: selected,
  };
}

export function applySkipExamResult(progress, course, targetLevelId, exam, answersMap) {
  const next = cloneProgress(progress);
  const result = gradeExam(exam, answersMap);
  let xpGained = 0;

  if (result.passed) {
    const priorLevels = getPriorLevels(course, targetLevelId);
    next.passedLevelIds = next.passedLevelIds || [];
    next.unlockedLevelIds = next.unlockedLevelIds || [];
    next.completedBlocks = next.completedBlocks || {};

    for (const lvl of priorLevels) {
      if (!next.passedLevelIds.includes(lvl.id)) next.passedLevelIds.push(lvl.id);
      if (!next.unlockedLevelIds.includes(lvl.id)) next.unlockedLevelIds.push(lvl.id);
      if (!next.completedBlocks[lvl.id]) {
        next.completedBlocks[lvl.id] = (lvl.blocks || []).map((b) => b.id);
      }
    }
    if (!next.unlockedLevelIds.includes(targetLevelId)) {
      next.unlockedLevelIds.push(targetLevelId);
    }
    xpGained = result.correct * XP_RULES.EXAM_CORRECT + 50;
    next.xp = (next.xp || 0) + xpGained;
  }

  next.examAttempts = [
    ...(next.examAttempts || []),
    {
      levelId: targetLevelId,
      examId: exam.id,
      isSkipExam: true,
      correct: result.correct,
      total: result.total,
      passed: result.passed,
      answers: answersMap,
      xpGained,
      at: nowIso(),
    },
  ];

  next.updatedAt = nowIso();
  return { progress: next, result, xpGained };
}

export function getPriorContentQuestions(course, targetLevelId, targetBlockIndex = 0) {
  const levels = sortedLevels(course);
  const targetLvlIndex = levels.findIndex((l) => l.id === targetLevelId);
  if (targetLvlIndex < 0) return [];

  const pool = [];
  // 1. De todos los niveles anteriores
  for (let i = 0; i < targetLvlIndex; i++) {
    const lvl = levels[i];
    for (const q of lvl.exam?.questions || []) {
      pool.push({ ...q, fromLevel: lvl.title, fromType: "Examen previo" });
    }
    for (const b of lvl.blocks || []) {
      for (const q of b.quiz?.questions || []) {
        pool.push({ ...q, fromLevel: lvl.title, fromBlock: b.theory?.title || b.title });
      }
    }
  }

  // 2. Del nivel actual, todos los bloques previos
  const targetLevel = levels[targetLvlIndex];
  const targetBlocks = sortedBlocks(targetLevel);
  for (let j = 0; j < targetBlockIndex; j++) {
    const b = targetBlocks[j];
    for (const q of b.quiz?.questions || []) {
      pool.push({ ...q, fromLevel: targetLevel.title, fromBlock: b.theory?.title || b.title });
    }
  }

  return pool;
}

export function createSkipLessonExam(course, targetLevelId, targetBlockIndex = 0) {
  const targetLevel = getLevelById(course, targetLevelId);
  if (!targetLevel) return null;
  const targetBlocks = sortedBlocks(targetLevel);
  const isToExam = targetBlockIndex >= targetBlocks.length;
  const targetTitle = isToExam
    ? `Examen Final de ${targetLevel.title}`
    : (targetBlocks[targetBlockIndex]?.theory?.title || targetBlocks[targetBlockIndex]?.title || `Lección ${targetBlockIndex + 1}`);

  const pool = getPriorContentQuestions(course, targetLevelId, targetBlockIndex);
  if (!pool.length) return null;

  const count = Math.min(Math.max(6, Math.min(pool.length, 10)), 15);
  const shuffledPool = [...pool].sort(() => Math.random() - 0.5);
  const seen = new Set();
  const selected = [];
  for (const q of shuffledPool) {
    if (!seen.has(q.prompt)) {
      seen.add(q.prompt);
      selected.push(shuffleOptions(q));
      if (selected.length >= count) break;
    }
  }

  const total = selected.length;
  const passScore = Math.ceil(total * 0.75);

  return {
    id: `skip-to-${targetLevelId}-b${targetBlockIndex}`,
    isSkipExam: true,
    isLessonSkip: true,
    targetLevelId,
    targetLevelTitle: targetLevel.title,
    targetBlockIndex,
    targetTitle,
    title: `Examen de suficiencia para acceder a: ${targetTitle}`,
    description: `Este examen integrador contiene ${total} preguntas que evalúan TODO el contenido aprendido anteriormente. Aprobás con ${passScore}/${total} respuestas correctas.`,
    passScore,
    questions: selected,
  };
}

export function applySkipLessonResult(progress, course, targetLevelId, targetBlockIndex, exam, answersMap) {
  const next = cloneProgress(progress);
  const result = gradeExam(exam, answersMap);
  let xpGained = 0;

  if (result.passed) {
    next.passedLevelIds = next.passedLevelIds || [];
    next.unlockedLevelIds = next.unlockedLevelIds || [];
    next.completedBlocks = next.completedBlocks || {};

    const levels = sortedLevels(course);
    const targetLvlIndex = levels.findIndex((l) => l.id === targetLevelId);

    // Desbloquear y pasar todos los niveles previos
    for (let i = 0; i < targetLvlIndex; i++) {
      const lvl = levels[i];
      if (!next.passedLevelIds.includes(lvl.id)) next.passedLevelIds.push(lvl.id);
      if (!next.unlockedLevelIds.includes(lvl.id)) next.unlockedLevelIds.push(lvl.id);
      if (!next.completedBlocks[lvl.id]) {
        next.completedBlocks[lvl.id] = (lvl.blocks || []).map((b) => b.id);
      }
    }

    if (!next.unlockedLevelIds.includes(targetLevelId)) {
      next.unlockedLevelIds.push(targetLevelId);
    }

    // Marcar como completados todos los bloques del nivel actual hasta targetBlockIndex
    const targetLevel = levels[targetLvlIndex];
    const targetBlocks = sortedBlocks(targetLevel);
    next.completedBlocks[targetLevelId] = next.completedBlocks[targetLevelId] || [];
    for (let j = 0; j < targetBlockIndex; j++) {
      const bId = targetBlocks[j]?.id;
      if (bId && !next.completedBlocks[targetLevelId].includes(bId)) {
        next.completedBlocks[targetLevelId].push(bId);
      }
    }

    xpGained = result.correct * XP_RULES.EXAM_CORRECT + 30;
    next.xp = (next.xp || 0) + xpGained;
  }

  next.examAttempts = [
    ...(next.examAttempts || []),
    {
      levelId: targetLevelId,
      examId: exam.id,
      isSkipExam: true,
      isLessonSkip: true,
      targetBlockIndex,
      correct: result.correct,
      total: result.total,
      passed: result.passed,
      answers: answersMap,
      xpGained,
      at: nowIso(),
    },
  ];

  next.updatedAt = nowIso();
  return { progress: next, result, xpGained };
}

function nowIso() {
  return new Date().toISOString();
}
