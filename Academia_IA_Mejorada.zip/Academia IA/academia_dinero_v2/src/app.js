// src/app.js
// Interfaz principal: dashboard, materia y sesión de estudio.

import {
  getActiveProfileId,
  getActiveSubjectId,
  setActiveSubjectId,
  getAllProfiles,
  getSubjectsByProfile,
  getMaterials,
} from "./storage.js";
import {
  getStudyBundle,
  getProfileStudyData,
  saveCourse,
  saveProgress,
} from "./courseStore.js";
import { createDemoCourseDefinition } from "./demoCourse.js";
import { createEconomicsCourseDefinition } from "./economicsCourse.js";
import {
  sortedLevels,
  sortedBlocks,
  getLevelStatus,
  getLevelDisplayStatus,
  getLevelExamSummary,
  getCourseProgressPercent,
  getLevelProgressPercent,
  currentAvailableLevel,
  getTheoryViewModel,
  answerQuiz,
  completeBlock,
  canStartExam,
  applyExamResult,
  recommendReviews,
  touchSession,
  profileStats,
  getLevelById,
  createSkipExam,
  applySkipExamResult,
  createSkipLessonExam,
  applySkipLessonResult,
  getPriorLevels,
  shuffleOptions,
} from "./courseEngine.js";
import {
  readLegacyMoneyState,
  summarizeLegacyMoneyState,
  mergeLegacyMoneyProgress,
} from "./moneyProgressImport.js";

const mainEl = document.getElementById("main");
const xpEl = document.getElementById("xp");

const ui = {
  view: "dashboard",
  subjectId: null,
  courseId: null,
  bundle: null,
  focusMode: true,
  levelId: null,
  phase: "theory",
  blockIndex: 0,
  questionIndex: 0,
  examAnswers: {},
  feedback: null,
  examPack: null,
  hintsUsed: 0,
  maxHints: 3,
  currentHintShown: false,
  showSummary: false,
  skipExamLevel: null,
  skipExamAnswers: {},
  skipExamQuestionIndex: 0,
  skipExamPack: null,
};

export async function renderMain() {
  await updateXPDisplay();
  const profileId = getActiveProfileId();
  if (!profileId) {
    ui.view = "welcome";
    mainEl.innerHTML = welcomeHTML();
    return;
  }
  if (ui.view === "study" && ui.bundle) {
    renderStudy();
    return;
  }
  if (ui.view === "subject" && (ui.subjectId || getActiveSubjectId())) {
    ui.subjectId = ui.subjectId || getActiveSubjectId();
    await renderSubjectDetail(ui.subjectId);
    return;
  }
  await renderDashboard();
}

async function updateXPDisplay() {
  const pid = getActiveProfileId();
  if (!pid) {
    xpEl.textContent = "⚡ 0 XP";
    return;
  }
  const data = profileStats(await getProfileStudyData(pid));
  xpEl.textContent = "⚡ " + (data.xp || 0) + " XP";
}

function welcomeHTML() {
  return `
    <div class="welcome-icon">🎓</div>
    <h1>¡Bienvenido a Academia IA!</h1>
    <p>Tu plataforma educativa personalizada. Creá un perfil para comenzar.</p>
    <div class="feature-grid">
      <div class="feature-card"><div class="icon">👤</div><h4>Perfiles</h4><p>Estudiantes separados, progreso separado.</p></div>
      <div class="feature-card"><div class="icon">📚</div><h4>Materias</h4><p>Cada materia tiene su propio camino de niveles.</p></div>
      <div class="feature-card"><div class="icon">🧠</div><h4>Estudio</h4><p>Teoría, quizzes guiados y exámenes finales.</p></div>
      <div class="feature-card"><div class="icon">🏆</div><h4>Progreso</h4><p>XP, desbloqueo y continuidad entre sesiones.</p></div>
    </div>`;
}

async function renderDashboard() {
  ui.view = "dashboard";
  const profileId = getActiveProfileId();
  const profiles = await getAllProfiles();
  const profile = profiles.find((p) => p.id === profileId);
  const subjects = await getSubjectsByProfile(profileId);
  const studyData = await getProfileStudyData(profileId);
  const stats = profileStats(studyData);
  let totalMaterials = 0;
  const subjectCards = [];
  for (const s of subjects) {
    const mats = await getMaterials(profileId, s.id);
    totalMaterials += mats.length;
    const bundles = studyData.filter((b) => b.progress?.subjectId === s.id);
    const percent = bundles.reduce(
      (best, b) => Math.max(best, getCourseProgressPercent(b.course, b.progress)),
      0
    );
    subjectCards.push({ s, mats: mats.length, percent });
  }
  const continueTarget = stats.lastSession;

  mainEl.innerHTML = `
    <div class="muted">PERFIL ACTIVO</div>
    <h1>Hola, ${escapeHtml(profile?.name || "estudiante")}</h1>
    <p class="muted">Elegí una materia o continuá donde dejaste.</p>
    <div class="stats">
      <div class="stat"><strong>${stats.xp}</strong><span class="label">XP total</span></div>
      <div class="stat"><strong>${stats.passedLevels}</strong><span class="label">Niveles aprobados</span></div>
      <div class="stat"><strong>${stats.percent}%</strong><span class="label">Progreso</span></div>
      <div class="stat"><strong>${totalMaterials}</strong><span class="label">Materiales</span></div>
    </div>
    ${continueTarget ? `<button class="primary" id="continueStudyBtn">Continuar estudiando</button>` : ""}
    ${subjects.length === 0 ? `
      <div class="empty-note">
        <p>📚 No tenés materias todavía.</p>
        <p class="muted">Usá <strong>+ Crear materia</strong> en la barra lateral.</p>
      </div>` : `
      <h2>Tus materias</h2>
      <div class="feature-grid">
        ${subjectCards.map(({ s, mats, percent }) => `
          <button type="button" class="feature-card subject-card" data-open-subject="${s.id}">
            <h4>📘 ${escapeHtml(s.name)}</h4>
            <p>${s.level ? escapeHtml(s.level) : "Camino de aprendizaje"}</p>
            <div class="progress" aria-hidden="true"><div style="width:${percent}%"></div></div>
            <p class="muted">${percent}% · ${mats} material(es)</p>
          </button>`).join("")}
      </div>`}
  `;
  mainEl.querySelector("#continueStudyBtn")?.addEventListener("click", () => {
    openSubject(continueTarget.subjectId, { resume: true });
  });
  mainEl.querySelectorAll("[data-open-subject]").forEach((btn) => {
    btn.addEventListener("click", () => openSubject(Number(btn.dataset.openSubject)));
  });
}

export async function openSubject(subjectId, options = {}) {
  ui.subjectId = subjectId;
  setActiveSubjectId(subjectId);
  window._currentSubjectId = subjectId;
  if (window.refreshMaterials) window.refreshMaterials(subjectId);
  if (window.renderSubjects) window.renderSubjects();
  document.body.classList.remove("focus-mode");
  if (options.resume) {
    const profileId = getActiveProfileId();
    const bundles = await getStudyBundle(profileId, subjectId);
    const bundle = pickBundle(bundles, options.courseId);
    if (bundle?.progress?.lastSession?.levelId) {
      ui.courseId = bundle.courseRecord.id;
      ui.bundle = bundle;
      ui.levelId = bundle.progress.lastSession.levelId;
      ui.phase = bundle.progress.lastSession.phase || "theory";
      ui.blockIndex = bundle.progress.lastSession.blockIndex || 0;
      ui.questionIndex = bundle.progress.lastSession.questionIndex || 0;
      ui.examAnswers = bundle.progress.lastSession.examAnswers || {};
      ui.feedback = null;
      ui.examPack = null;
      if (bundle.progress.lastSession.view === "study") {
        ui.view = "study";
        await renderMain();
        return;
      }
    }
  }
  ui.view = "subject";
  await renderSubjectDetail(subjectId, options.courseId);
}

function pickBundle(bundles, courseId) {
  if (!bundles || !bundles.length) return null;
  if (courseId != null) {
    const found = bundles.find((b) => b.courseRecord.id === courseId);
    if (found) return found;
  }
  const recency = (b) => {
    const at = b.progress?.lastSession?.at;
    return at ? new Date(at).getTime() : 0;
  };
  return [...bundles].sort((a, b) => recency(b) - recency(a))[0];
}

const COURSE_CATALOG = [
  {
    key: "economics",
    title: "Academia del Dinero",
    description: "Curso completo de 9 niveles con teoría, quizzes guiados y examen final. Contenido original de Academia del Dinero.",
    levelCount: 9,
    source: "imported",
    signature: "academia-del-dinero",
    create: createEconomicsCourseDefinition,
  },
  {
    key: "demo",
    title: "Técnicas de estudio, comprensión y exámenes",
    description: "Curso de demostración con 3 niveles para probar el motor educativo completo.",
    levelCount: 3,
    source: "demo",
    signature: "demo-study-skills",
    create: createDemoCourseDefinition,
  },
];

function courseSignatureOf(definition) {
  return definition?.id || definition?.title || "";
}

function examScoreLabel(summary) {
  if (!summary.attempts) return "Examen: sin rendir";
  return `Examen: ${summary.bestPercent}%${summary.passed ? " ✓" : ""}`;
}

async function renderSubjectDetail(subjectId, courseId) {
  const profileId = getActiveProfileId();
  const subjects = await getSubjectsByProfile(profileId);
  const subject = subjects.find((s) => s.id === subjectId);
  if (!subject) {
    ui.view = "dashboard";
    await renderDashboard();
    return;
  }
  const materials = await getMaterials(profileId, subjectId);
  const bundles = await getStudyBundle(profileId, subjectId);
  const bundle = pickBundle(bundles, courseId ?? ui.courseId);
  ui.courseId = bundle?.courseRecord?.id ?? null;
  ui.bundle = bundle;
  const course = bundle?.course;
  const progress = bundle?.progress;
  const levels = course ? sortedLevels(course) : [];
  const percent = course ? getCourseProgressPercent(course, progress) : 0;
  const current = course ? currentAvailableLevel(course, progress) : null;
  const recs = progress ? recommendReviews(progress, course) : [];
  const isEconomicsSubject = /econom/i.test(subject.name);
  const importedSignatures = new Set(bundles.map((b) => courseSignatureOf(b.course)));
  const availableCatalog = COURSE_CATALOG.filter((entry) => !importedSignatures.has(entry.signature));
  const legacySummary = summarizeLegacyMoneyState(readLegacyMoneyState());
  const showLegacyImport =
    courseSignatureOf(course) === "academia-del-dinero" &&
    legacySummary.available &&
    legacySummary.hasData &&
    !progress?.importedAt;

  const courseSwitcher = bundles.length > 1
    ? `<div class="course-tabs">
        <span class="muted">Curso:</span>
        ${bundles.map((b) => `
          <button type="button" class="nav-chip ${b.courseRecord.id === ui.courseId ? "active" : ""}" data-select-course="${b.courseRecord.id}">
            ${escapeHtml(b.course.title)}
          </button>`).join("")}
      </div>`
    : "";

  const catalogHTML = availableCatalog.length
    ? `<div class="course-catalog">
        <h3>${course ? "Importar otro curso a esta materia" : "Cursos disponibles para importar"}</h3>
        <p class="muted">Cada curso se agrega solo a esta materia y este perfil. No se aplica automáticamente a otros perfiles.</p>
        <div class="feature-grid">
          ${availableCatalog.map((entry) => `
            <div class="feature-card course-catalog-card">
              <h4>${escapeHtml(entry.title)}</h4>
              <p>${escapeHtml(entry.description)}</p>
              <p class="muted">${entry.levelCount} niveles${entry.key === "economics" && isEconomicsSubject ? " · Recomendado para Economía" : ""}</p>
              <button type="button" class="primary" data-start-course="${entry.key}">Importar curso</button>
            </div>`).join("")}
        </div>
      </div>`
    : "";

  const legacyHTML = showLegacyImport
    ? `<div class="legacy-import">
        <h3>Progreso anterior de Academia del Dinero</h3>
        <p>Encontramos datos guardados por la aplicación original en este navegador. Podés importarlos a este curso cuando quieras.</p>
        <p class="muted">Niveles aprobados: ${legacySummary.passedLevels} · Bloques completados: ${legacySummary.completedParts} · XP: ${legacySummary.xp}. No se importa nada hasta que lo confirmes.</p>
        <button type="button" class="secondary" id="importLegacyProgressBtn">Importar progreso anterior</button>
      </div>`
    : "";

  mainEl.innerHTML = `
    <button class="secondary" id="backToDashboard">← Volver al panel</button>
    <h1>📘 ${escapeHtml(subject.name)}</h1>
    <p class="muted">${subject.level ? escapeHtml(subject.level) + " · " : ""}${materials.length} material(es)</p>
    ${course ? `
    <div class="stats">
      <div class="stat"><strong>${percent}%</strong><span class="label">Avance del curso</span></div>
      <div class="stat"><strong>${progress?.xp || 0}</strong><span class="label">XP en esta materia</span></div>
      <div class="stat"><strong>${(progress?.passedLevelIds || []).length}/${levels.length}</strong><span class="label">Niveles aprobados</span></div>
    </div>` : ""}
    ${courseSwitcher}
    ${course ? `
      <div class="path-head">
        <h2>Camino de niveles</h2>
        <div class="path-actions">
          <button class="primary" id="continueLevelBtn">${(progress.passedLevelIds || []).length >= levels.length ? "Curso aprobado" : ((progress.passedLevelIds || []).length || (progress.examAttempts || []).length ? "Continuar" : "Comenzar")}</button>
        </div>
      </div>
      <ol class="level-path">
        ${levels.map((level, i) => {
          const status = getLevelDisplayStatus(course, progress, level.id);
          const lp = getLevelProgressPercent(level, progress);
          const exam = getLevelExamSummary(progress, level.id);
          const currentMark = current && current.id === level.id && status !== "passed";
          const isLocked = status === "locked";
          const blocks = sortedBlocks(level);
          const isLvlDone = status === "passed";

          const lessonsHtml = `
            <div class="level-lessons" style="margin: 6px 0 10px 48px; display: flex; flex-direction: column; gap: 4px;">
              ${blocks.map((b, bIdx) => {
                const bDone = isDone(progress, level.id, b.id);
                const bCanOpen = !isLocked && canJumpBlock(progress, level, bIdx);
                const bTitle = b.theory?.title || b.title || `Lección ${bIdx + 1}`;
                return `
                  <div class="lesson-chip-row" style="display: flex; align-items: center; justify-content: space-between; background: #192440; border: 1px solid #2d3b5e; border-radius: 8px; padding: 6px 12px; font-size: 13px;">
                    <span style="color: ${bDone ? '#53d9bb' : bCanOpen ? '#ecf2ff' : '#a8b5d1'}">
                      ${bDone ? '✓' : bCanOpen ? '○' : '🔒'} <strong>${bIdx + 1}.</strong> ${escapeHtml(bTitle)}
                    </span>
                    <div style="display: flex; gap: 6px;">
                      ${bCanOpen ? `
                        <button type="button" class="secondary" style="font-size: 11px; padding: 2px 8px; margin: 0;" data-open-block="${level.id}:${bIdx}">
                          ${bDone ? 'Repasar' : 'Estudiar'}
                        </button>
                      ` : `
                        <button type="button" class="secondary skip-btn" style="font-size: 11px; padding: 2px 8px; margin: 0;" data-skip-lesson="${level.id}:${bIdx}" title="Rendir examen previo para saltear hasta esta lección">
                          ⚡ Saltear lección
                        </button>
                      `}
                    </div>
                  </div>
                `;
              }).join("")}
              ${!canStartExam(level, progress) && !isLvlDone ? `
                <div class="lesson-chip-row" style="display: flex; align-items: center; justify-content: space-between; background: #192440; border: 1px dashed #7774f8; border-radius: 8px; padding: 6px 12px; font-size: 13px;">
                  <span style="color: #a8b5d1">🔒 <strong>Examen Final</strong> de ${escapeHtml(level.title)}</span>
                  <button type="button" class="secondary skip-btn" style="font-size: 11px; padding: 2px 8px; margin: 0;" data-skip-lesson="${level.id}:${blocks.length}" title="Rendir examen integrador para saltear lecciones e ir directo al examen">
                    ⚡ Saltear lecciones al Examen
                  </button>
                </div>
              ` : ''}
            </div>
          `;

          return `<li class="level-node ${status} ${currentMark ? "current" : ""}">
            <button type="button" data-open-level="${level.id}" ${isLocked ? "disabled" : ""}>
              <span class="lvl-index">${status === "passed" ? "✓" : i + 1}</span>
              <span class="lvl-body">
                <strong>${escapeHtml(level.title)}</strong>
                <small>${labelStatus(status)} · ${lp}% · ${examScoreLabel(exam)}</small>
                <span class="mini-progress"><span style="width:${lp}%"></span></span>
              </span>
              <span class="lvl-cta">${status === "locked" ? "Bloqueado" : status === "passed" ? "Repasar" : status === "in_progress" ? "Continuar" : "Comenzar"}</span>
            </button>
            ${isLocked ? `<button type="button" class="secondary skip-btn" data-skip-level="${level.id}" style="margin:4px 0 6px 48px;font-size:12px;padding:6px 12px">⚡ Saltear nivel completo (Examen previo)</button>` : ""}
            ${lessonsHtml}
          </li>`;
        }).join("")}
      </ol>
      <h3>Recomendaciones</h3>
      <ul class="recs">${recs.map((r) => `<li><strong>${escapeHtml(r.title)}</strong> — ${escapeHtml(r.detail)}</li>`).join("")}</ul>
      ${legacyHTML}
    ` : `
      <div class="study-cta">
        <h2>Elegí un curso para esta materia</h2>
        <p>Academia IA usa un mismo motor para todos los cursos. Podés importar Academia del Dinero, probar el curso demo o, más adelante, generar niveles con Gemini a partir de tus documentos.</p>
      </div>
    `}
    ${catalogHTML}
    <h2>📎 Materiales</h2>
    ${materials.length === 0 ? `<p class="muted">Subí PDFs, DOCX o TXT desde la barra lateral. Más adelante Gemini podrá armar un curso a partir de ellos.</p>` : `
      <div class="feature-grid">
        ${materials.map((m) => `
          <button type="button" class="feature-card" data-mat-id="${m.id}">
            <h4>${escapeHtml(m.name)}</h4>
            <p class="muted">${m.createdAt ? new Date(m.createdAt).toLocaleDateString() : ""}</p>
          </button>`).join("")}
      </div>`}
  `;

  document.getElementById("backToDashboard").onclick = () => {
    document.body.classList.remove("focus-mode");
    ui.view = "dashboard";
    renderMain();
  };
  document.getElementById("continueLevelBtn")?.addEventListener("click", () => {
    const target = currentAvailableLevel(course, progress);
    if (target) openLevel(target.id);
  });
  mainEl.querySelectorAll("[data-select-course]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.selectCourse);
      ui.courseId = id;
      renderSubjectDetail(subjectId, id);
    });
  });
  mainEl.querySelectorAll("[data-start-course]").forEach((btn) => {
    btn.addEventListener("click", () => startCourseByKey(btn.dataset.startCourse));
  });
  document.getElementById("importLegacyProgressBtn")?.addEventListener("click", importLegacyProgress);
  mainEl.querySelectorAll("[data-open-level]").forEach((btn) => {
    btn.addEventListener("click", () => openLevel(btn.dataset.openLevel));
  });
  mainEl.querySelectorAll("[data-skip-level]").forEach((btn) => {
    btn.addEventListener("click", () => startSkipExam(btn.dataset.skipLevel));
  });
  mainEl.querySelectorAll("[data-open-block]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const parts = btn.dataset.openBlock.split(":");
      const lvlId = parts[0];
      const bIdx = Number(parts[1]);
      openLevel(lvlId);
      ui.blockIndex = bIdx;
      ui.phase = "theory";
      ui.questionIndex = 0;
      renderStudy();
    });
  });
  mainEl.querySelectorAll("[data-skip-lesson]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const parts = btn.dataset.skipLesson.split(":");
      const lvlId = parts[0];
      const bIdx = Number(parts[1]);
      startSkipLessonExam(lvlId, bIdx);
    });
  });
  mainEl.querySelectorAll("[data-mat-id]").forEach((card) => {
    card.onclick = () => {
      const mat = materials.find((m) => m.id === Number(card.dataset.matId));
      if (mat) showMaterialPreview(mat);
    };
  });
}

async function startCourseByKey(key) {
  const entry = COURSE_CATALOG.find((c) => c.key === key);
  const profileId = getActiveProfileId();
  const subjectId = ui.subjectId;
  if (!entry || !profileId || !subjectId) return;
  const existing = await getStudyBundle(profileId, subjectId);
  const already = existing.find((b) => courseSignatureOf(b.course) === entry.signature);
  if (already) {
    ui.courseId = already.courseRecord.id;
    await renderSubjectDetail(subjectId, ui.courseId);
    return;
  }
  const saved = await saveCourse({
    profileId,
    subjectId,
    definition: entry.create(),
    source: entry.source,
  });
  ui.courseId = saved.course.id;
  await renderSubjectDetail(subjectId, ui.courseId);
  await updateXPDisplay();
}

async function importLegacyProgress() {
  const profileId = getActiveProfileId();
  const subjectId = ui.subjectId;
  if (!ui.bundle || !profileId || !subjectId) return;
  const legacy = readLegacyMoneyState();
  const summary = summarizeLegacyMoneyState(legacy);
  if (!summary.available || !summary.hasData) {
    window.alert("No encontramos un progreso anterior de Academia del Dinero en este navegador.");
    return;
  }
  const ok = window.confirm(
    `Se importará el progreso guardado de Academia del Dinero a este curso.\n\n` +
      `Niveles aprobados: ${summary.passedLevels}\n` +
      `Bloques completados: ${summary.completedParts}\n` +
      `XP: ${summary.xp}\n\n` +
      "El progreso comprobado se conserva y no se modifica ningún otro curso ni perfil. ¿Continuar?"
  );
  if (!ok) return;
  const merged = mergeLegacyMoneyProgress(ui.bundle.progress, ui.bundle.course, legacy);
  await persist(merged);
  await renderSubjectDetail(subjectId, ui.courseId);
}

async function persist(progress) {
  const id = await saveProgress(progress);
  progress.id = id;
  ui.bundle.progress = progress;
  await updateXPDisplay();
}

async function openLevel(levelId) {
  const { course, progress } = ui.bundle;
  if (getLevelStatus(course, progress, levelId) === "locked") return;
  const level = getLevelById(course, levelId);
  ui.levelId = levelId;
  ui.view = "study";
  ui.phase = "theory";
  ui.blockIndex = 0;
  ui.questionIndex = 0;
  ui.examAnswers = {};
  ui.feedback = null;
  ui.examPack = null;
  const blocks = sortedBlocks(level);
  const firstOpen = blocks.findIndex((b) => !((progress.completedBlocks || {})[levelId] || []).includes(b.id));
  ui.blockIndex = firstOpen >= 0 ? firstOpen : 0;
  await persist(touchSession(progress, { view: "study", levelId, phase: "theory", blockIndex: ui.blockIndex, questionIndex: 0 }));
  renderStudy();
}

function renderStudy() {
  const { course, progress } = ui.bundle;
  const level = getLevelById(course, ui.levelId);
  if (!level) return;
  document.body.classList.toggle("focus-mode", ui.focusMode);

  if (ui.phase === "skip_exam" || ui.phase === "skip_results") {
    mainEl.innerHTML = `
      <div class="study-top">
        <button class="secondary" id="backToSubject">← Camino</button>
        <div class="study-title">
          <div class="muted">${escapeHtml(course.title)}</div>
          <h1>⚡ Salto de nivel: ${escapeHtml(level.title)}</h1>
        </div>
        <button class="secondary" id="toggleFocus">${ui.focusMode ? "Mostrar paneles" : "Ocultar paneles"}</button>
      </div>
      ${ui.phase === "skip_exam" ? skipExamHTML() : skipResultsHTML()}
    `;
    document.getElementById("backToSubject").onclick = async () => {
      ui.view = "subject";
      document.body.classList.remove("focus-mode");
      await persist(touchSession(ui.bundle.progress, { view: "path" }));
      await renderSubjectDetail(ui.subjectId, ui.courseId);
    };
    document.getElementById("toggleFocus")?.addEventListener("click", () => {
      ui.focusMode = !ui.focusMode;
      document.body.classList.toggle("focus-mode", ui.focusMode);
      const btn = document.getElementById("toggleFocus");
      if (btn) btn.textContent = ui.focusMode ? "Mostrar paneles" : "Ocultar paneles";
    });
    bindStudyActions();
    return;
  }

  const blocks = sortedBlocks(level);
  const block = blocks[ui.blockIndex];

  let body = "";
  if (ui.phase === "theory") body = theoryHTML(course, block);
  else if (ui.phase === "quiz") body = quizHTML(block);
  else if (ui.phase === "exam") body = examHTML(level);
  else if (ui.phase === "results") body = resultsHTML();

  mainEl.innerHTML = `
    <div class="study-top">
      <button class="secondary" id="backToSubject">← Camino</button>
      <div class="study-title">
        <div class="muted">${escapeHtml(course.title)}</div>
        <h1>${escapeHtml(level.title)}</h1>
      </div>
      <button class="secondary" id="toggleFocus">${ui.focusMode ? "Mostrar paneles" : "Ocultar paneles"}</button>
    </div>
    <nav class="study-nav">
      ${blocks.map((b, i) => {
        const canJump = canJumpBlock(progress, level, i);
        const done = isDone(progress, level.id, b.id);
        const active = ui.blockIndex === i && (ui.phase === "theory" || ui.phase === "quiz");
        return `
          <button class="nav-chip ${active ? "active" : ""} ${done ? "done" : ""}" 
                  ${canJump ? `data-jump-block="${i}"` : `data-study-skip-block="${i}"`} 
                  title="${canJump ? 'Ir a esta lección' : 'Rendir examen previo para saltear a esta lección'}">
            ${done ? "✓ " : !canJump ? "⚡ " : ""}${i + 1}. ${escapeHtml(b.theory?.title || b.title || "Bloque")}${!canJump ? " (Saltear)" : ""}
          </button>`;
      }).join("")}
      ${canStartExam(level, progress) ? `
        <button class="nav-chip ${ui.phase === "exam" || ui.phase === "results" ? "active" : ""}" id="jumpExam">
          Examen final
        </button>
      ` : `
        <button class="nav-chip ${ui.phase === "exam" || ui.phase === "results" ? "active" : ""}" id="jumpExamSkip" data-study-skip-exam="true" title="Rendir examen integrador para saltear lecciones e ir directo al examen final">
          ⚡ Saltear lecciones al Examen
        </button>
      `}
    </nav>
    ${body}
  `;

  document.getElementById("backToSubject").onclick = async () => {
    ui.view = "subject";
    document.body.classList.remove("focus-mode");
    await persist(touchSession(ui.bundle.progress, { view: "path" }));
    await renderSubjectDetail(ui.subjectId, ui.courseId);
  };
  document.getElementById("toggleFocus")?.addEventListener("click", () => {
    ui.focusMode = !ui.focusMode;
    document.body.classList.toggle("focus-mode", ui.focusMode);
    const btn = document.getElementById("toggleFocus");
    if (btn) btn.textContent = ui.focusMode ? "Mostrar paneles" : "Ocultar paneles";
  });
  mainEl.querySelectorAll("[data-jump-block]").forEach((btn) => {
    btn.onclick = () => {
      ui.blockIndex = Number(btn.dataset.jumpBlock);
      ui.phase = "theory";
      ui.feedback = null;
      ui.questionIndex = 0;
      renderStudy();
    };
  });
  document.getElementById("jumpExam")?.addEventListener("click", () => {
    ui.phase = "exam";
    ui.questionIndex = 0;
    ui.examAnswers = {};
    ui.examPack = null;
    renderStudy();
  });
  bindStudyActions();
}

function sanitizeTheoryHtml(html) {
  return String(html)
    .replace(/<\s*(script|iframe|object|embed|link|meta)\b[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/<\s*(script|iframe|object|embed|link|meta)\b[^>]*\/?\s*>/gi, "")
    .replace(/\son\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/\s(href|src)\s*=\s*(?:"\s*javascript:[^"]*"|'\s*javascript:[^']*')/gi, "");
}

function theoryHTML(course, block) {
  const vm = getTheoryViewModel(block, course.methodology);
  return `
    <article class="theory">
      <h2>${escapeHtml(vm.title)}</h2>
      ${vm.paragraphs.map((p) => (/<[a-z][\s\S]*>/i.test(String(p)) ? `<div class="theory-html">${sanitizeTheoryHtml(p)}</div>` : `<p>${escapeHtml(p)}</p>`)).join("")}
      ${vm.examples.map((ex) => `<div class="callout"><strong>${escapeHtml(ex.title)}</strong><p>${escapeHtml(ex.body)}</p></div>`).join("")}
      ${vm.cases.map((c) => `<div class="callout case"><strong>${escapeHtml(c.title)}</strong><p>${escapeHtml(c.body)}</p></div>`).join("")}
      ${vm.formulas.map((f) => `<div class="formula"><strong>${escapeHtml(f.name)}</strong><pre>${escapeHtml(f.expression)}</pre><p class="muted">${escapeHtml(f.note || "")}</p></div>`).join("")}
      ${vm.procedure.length ? `<ol class="procedure">${vm.procedure.map((s) => `<li><strong>${escapeHtml(s.step)}</strong> ${escapeHtml(s.detail)}</li>`).join("")}</ol>` : ""}
      ${vm.code ? `<pre class="code-block">${escapeHtml(vm.code.source)}</pre>
        <ul class="walkthrough">${vm.code.walkthrough.map((w) => `<li><code>L${w.line}</code> ${escapeHtml(w.comment)}</li>`).join("")}</ul>` : ""}
      <button class="primary" id="toQuizBtn">Ir al quiz guiado</button>
    </article>`;
}

function quizHTML(block) {
  const questions = block.quiz.questions;
  const q = questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  if (ui.feedback) {
    const fb = ui.feedback;
    return `
      <section class="quiz">
        <p class="muted">Pregunta ${n} de ${questions.length}</p>
        <h2>${escapeHtml(q.prompt)}</h2>
        <div class="feedback ${fb.result.correct ? "ok" : "bad"}">
          <strong>${fb.result.correct ? "Correcto" : "Incorrecto"}</strong>
          ${fb.xpGained ? `<span class="xp-gain">+${fb.xpGained} XP</span>` : ""}
          <p>${escapeHtml(fb.result.explanation)}</p>
          <p class="muted">Concepto: ${escapeHtml(fb.result.relatedConcept)}</p>
        </div>
        <button class="primary" id="quizContinueBtn">Continuar</button>
      </section>`;
  }
  const hintText = q.hint || q.relatedConcept || "";
  const canHint = hintText && ui.hintsUsed < ui.maxHints && !ui.currentHintShown;
  const hintsLeft = ui.maxHints - ui.hintsUsed;
  return `
    <section class="quiz">
      <p class="muted">Pregunta ${n} de ${questions.length} · respuesta inmediata</p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${q.options.map((o) => `<button class="option" data-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${canHint ? `<button class="secondary hint-btn" id="showHintBtn">💡 Pista (${hintsLeft} restante${hintsLeft !== 1 ? "s" : ""})</button>` : (ui.hintsUsed >= ui.maxHints && !ui.currentHintShown ? `<span class="muted">Sin pistas restantes</span>` : "")}
        ${ui.currentHintShown ? `<div class="hint-box">💡 <strong>Pista:</strong> ${escapeHtml(hintText)}</div>` : ""}
        <button class="secondary" id="showSummaryBtn">📋 Resumen del nivel</button>
      </div>
      ${ui.showSummary ? summaryHTML() : ""}
    </section>`;
}

function summaryHTML() {
  const { course, progress } = ui.bundle;
  const level = getLevelById(course, ui.levelId);
  if (!level) return "";
  const blocks = sortedBlocks(level);
  return `
    <div class="summary-panel">
      <h3>📋 Resumen: ${escapeHtml(level.title)}</h3>
      <ul class="summary-list">
        ${blocks.map((b, i) => {
          const done = isDone(progress, level.id, b.id);
          const title = b.theory?.title || b.title || "Bloque " + (i + 1);
          const concepts = (b.quiz?.questions || []).map(q => q.relatedConcept || "").filter(Boolean);
          const uniqueConcepts = [...new Set(concepts)];
          return `<li class="${done ? "done" : ""}">
            <strong>${done ? "✓" : "○"} ${escapeHtml(title)}</strong>
            ${uniqueConcepts.length ? `<p class="muted">Conceptos: ${uniqueConcepts.map(c => escapeHtml(c)).join(", ")}</p>` : ""}
          </li>`;
        }).join("")}
      </ul>
      <button class="secondary" id="closeSummaryBtn">Cerrar resumen</button>
    </div>`;
}

function examHTML(level) {
  const exam = level.exam;
  const q = exam.questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  const selected = ui.examAnswers[q.id];
  const last = n === exam.questions.length;
  const hintText = q.hint || q.relatedConcept || "";
  const canHint = hintText && ui.hintsUsed < ui.maxHints && !ui.currentHintShown;
  const hintsLeft = ui.maxHints - ui.hintsUsed;
  return `
    <section class="exam">
      <p class="muted">Examen final · ${n}/${exam.questions.length} · aprobás con ${exam.passScore}/${exam.questions.length} · 💡 ${hintsLeft} pista${hintsLeft !== 1 ? "s" : ""} restante${hintsLeft !== 1 ? "s" : ""}</p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${q.options.map((o) => `<button class="option ${selected === o.id ? "picked" : ""}" data-exam-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${canHint ? `<button class="secondary hint-btn" id="showHintBtn">💡 Pista (${hintsLeft})</button>` : ""}
        ${ui.currentHintShown ? `<div class="hint-box">💡 <strong>Pista:</strong> ${escapeHtml(hintText)}</div>` : ""}
        <button class="secondary" id="showSummaryBtn">📋 Resumen del nivel</button>
      </div>
      ${ui.showSummary ? summaryHTML() : ""}
      <div class="exam-nav">
        <button class="secondary" id="examPrev" ${ui.questionIndex === 0 ? "disabled" : ""}>Anterior</button>
        <button class="primary" id="examNext" ${selected ? "" : "disabled"}>${last ? "Enviar examen" : "Siguiente"}</button>
      </div>
    </section>`;
}

function resultsHTML() {
  const pack = ui.examPack;
  if (!pack) return "<p>Sin resultado.</p>";
  const { result, xpGained, alreadyAwarded, unlockedLevelId } = pack;
  const recs = recommendReviews(ui.bundle.progress, ui.bundle.course);
  return `
    <section class="results">
      <h2>${result.passed ? "Nivel aprobado" : "No aprobado todavía"}</h2>
      <p class="score">${result.correct} / ${result.total}</p>
      <p>${result.passed ? "Alcanzaste el umbral de " + result.passScore + "." : "Necesitás " + result.passScore + " correctas para desbloquear el siguiente nivel."}</p>
      <p>${alreadyAwarded ? "Este examen ya había otorgado XP: no se sumó otra vez." : (xpGained ? ("+" + xpGained + " XP") : "Sin XP en este intento.")}</p>
      ${unlockedLevelId ? `<p><strong>Se desbloqueó el siguiente nivel.</strong></p>` : ""}
      <h3>Corrección</h3>
      <ol class="review-list">
        ${result.details.map((d) => `
          <li class="${d.correct ? "ok" : "bad"}">
            <p>${escapeHtml(d.prompt)}</p>
            <p>Tu respuesta: ${escapeHtml(d.selectedText || "(sin responder)")}</p>
            ${d.correct ? "" : `<p>Correcta: ${escapeHtml(d.correctText)}</p>`}
            <p class="muted">${escapeHtml(d.explanation)} · ${escapeHtml(d.relatedConcept)}</p>
          </li>`).join("")}
      </ol>
      <h3>Repaso recomendado</h3>
      <ul class="recs">${recs.map((r) => `<li>${escapeHtml(r.title)} — ${escapeHtml(r.detail)}</li>`).join("")}</ul>
      <div class="exam-nav">
        ${result.passed && unlockedLevelId ? `<button class="primary" id="goNextLevel">Continuar al siguiente nivel</button>` : `<button class="primary" id="retryExam">Reintentar examen</button>`}
        <button class="secondary" id="backPath">Volver al camino</button>
      </div>
    </section>`;
}

export function startSkipExam(targetLevelId) {
  const { course } = ui.bundle;
  const exam = createSkipExam(course, targetLevelId);
  if (!exam) {
    alert("No se puede saltear este nivel.");
    return;
  }
  const ok = confirm(`¿Deseás rendir el examen integrador para acceder a ${exam.targetLevelTitle}?\n\nEste examen contiene ${exam.questions.length} preguntas de todos los niveles anteriores (${exam.priorLevelsCount} niveles previos) y se aprueba con ${exam.passScore} respuestas correctas.`);
  if (!ok) return;

  ui.levelId = targetLevelId;
  ui.view = "study";
  ui.phase = "skip_exam";
  ui.skipExam = exam;
  ui.questionIndex = 0;
  ui.examAnswers = {};
  ui.examPack = null;
  ui.hintsUsed = 0;
  ui.currentHintShown = false;
  ui.showSummary = false;
  renderStudy();
}

function skipExamHTML() {
  const exam = ui.skipExam;
  if (!exam) return "<p>Examen no encontrado.</p>";
  const q = exam.questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  const selected = ui.examAnswers[q.id];
  const last = n === exam.questions.length;
  const hintText = q.hint || q.relatedConcept || "";
  const canHint = hintText && ui.hintsUsed < ui.maxHints && !ui.currentHintShown;
  const hintsLeft = ui.maxHints - ui.hintsUsed;

  return `
    <section class="exam skip-exam">
      <div class="skip-exam-header">
        <span class="tag">⚡ Examen de Suficiencia Integrador</span>
        <h2>${escapeHtml(exam.title)}</h2>
        <p class="muted">${escapeHtml(exam.description)}</p>
      </div>
      <p class="muted">Pregunta ${n}/${exam.questions.length} · Aprobás con ${exam.passScore}/${exam.questions.length} · 💡 ${hintsLeft} pista${hintsLeft !== 1 ? "s" : ""} restante${hintsLeft !== 1 ? "s" : ""}</p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${q.options.map((o) => `<button class="option ${selected === o.id ? "picked" : ""}" data-exam-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${canHint ? `<button class="secondary hint-btn" id="showHintBtn">💡 Pista (${hintsLeft})</button>` : (ui.hintsUsed >= ui.maxHints && !ui.currentHintShown ? `<span class="muted">Sin pistas restantes (máx 3)</span>` : "")}
        ${ui.currentHintShown ? `<div class="hint-box">💡 <strong>Pista:</strong> ${escapeHtml(hintText)}</div>` : ""}
        <button class="secondary" id="showSummaryBtn">📋 Resumen de temas anteriores</button>
      </div>
      ${ui.showSummary ? priorSummaryHTML() : ""}
      <div class="exam-nav">
        <button class="secondary" id="examPrev" ${ui.questionIndex === 0 ? "disabled" : ""}>Anterior</button>
        <button class="primary" id="examNext" ${selected ? "" : "disabled"}>${last ? "Enviar examen de suficiencia" : "Siguiente"}</button>
      </div>
    </section>`;
}

function priorSummaryHTML() {
  const { course } = ui.bundle;
  const priorLevels = getPriorLevels(course, ui.levelId);
  return `
    <div class="summary-panel">
      <h3>📋 Resumen de contenidos de niveles anteriores</h3>
      <div class="summary-content">
        ${priorLevels.map((lvl) => {
          const blocks = sortedBlocks(lvl);
          return `
            <div class="level-summary-item" style="margin-bottom:12px;border-bottom:1px solid #283554;padding-bottom:8px">
              <strong>📘 ${escapeHtml(lvl.title)}</strong>
              <ul style="padding-left:18px;margin:4px 0">
                ${blocks.map((b) => {
                  const concepts = (b.quiz?.questions || []).map((q) => q.relatedConcept || "").filter(Boolean);
                  const unique = [...new Set(concepts)];
                  return `<li><strong>${escapeHtml(b.theory?.title || b.title)}</strong>: ${unique.slice(0, 4).map((c) => escapeHtml(c)).join(", ")}</li>`;
                }).join("")}
              </ul>
            </div>`;
        }).join("")}
      </div>
      <button class="secondary" id="closeSummaryBtn">Cerrar resumen</button>
    </div>`;
}

function skipResultsHTML() {
  const pack = ui.examPack;
  if (!pack) return "<p>Sin resultado.</p>";
  const { result, xpGained } = pack;
  const targetLevel = getLevelById(ui.bundle.course, ui.levelId);

  return `
    <section class="results">
      <h2>${result.passed ? "🎉 ¡Examen Integrador Aprobado!" : "❌ No alcanzaste el puntaje requerido"}</h2>
      <p class="score">${result.correct} / ${result.total}</p>
      <p>${result.passed
        ? `¡Excelente! Aprobaste con éxito evaluando los contenidos de todos los niveles anteriores. Se ha desbloqueado <strong>${escapeHtml(targetLevel?.title || "el nivel")}</strong>.`
        : `Necesitás ${result.passScore} respuestas correctas para saltear a este nivel. Te recomendamos estudiar los niveles en orden.`}</p>
      <p>${xpGained ? `+${xpGained} XP ganados` : "Sin XP en este intento."}</p>
      <h3>Corrección</h3>
      <ol class="review-list">
        ${result.details.map((d) => `
          <li class="${d.correct ? "ok" : "bad"}">
            <p>${escapeHtml(d.prompt)}</p>
            <p>Tu respuesta: ${escapeHtml(d.selectedText || "(sin responder)")}</p>
            ${d.correct ? "" : `<p>Correcta: ${escapeHtml(d.correctText)}</p>`}
            <p class="muted">${escapeHtml(d.explanation)} · ${escapeHtml(d.relatedConcept)}</p>
          </li>`).join("")}
      </ol>
      <div class="exam-nav">
        ${result.passed
          ? `<button class="primary" id="enterTargetLevel">Ingresar a ${escapeHtml(targetLevel?.title || "Nivel")}</button>`
          : `<button class="primary" id="retrySkipExam">Reintentar examen</button>`}
        <button class="secondary" id="backPath">Volver al camino</button>
      </div>
    </section>`;
}

function bindStudyActions() {
  document.getElementById("toQuizBtn")?.addEventListener("click", () => {
    ui.phase = "quiz";
    ui.questionIndex = 0;
    ui.feedback = null;
    ui.currentHintShown = false;
    renderStudy();
  });
  // Hint button
  document.getElementById("showHintBtn")?.addEventListener("click", () => {
    if (ui.hintsUsed < ui.maxHints) {
      ui.hintsUsed += 1;
      ui.currentHintShown = true;
      renderStudy();
    }
  });
  // Summary button
  document.getElementById("showSummaryBtn")?.addEventListener("click", () => {
    ui.showSummary = !ui.showSummary;
    renderStudy();
  });
  document.getElementById("closeSummaryBtn")?.addEventListener("click", () => {
    ui.showSummary = false;
    renderStudy();
  });
  mainEl.querySelectorAll("[data-answer]").forEach((btn) => {
    btn.onclick = async () => {
      const block = currentBlock();
      const question = block.quiz.questions[ui.questionIndex];
      const out = answerQuiz(ui.bundle.progress, question, btn.dataset.answer);
      await persist(out.progress);
      ui.feedback = out;
      ui.currentHintShown = false;
      renderStudy();
    };
  });
  document.getElementById("quizContinueBtn")?.addEventListener("click", async () => {
    const block = currentBlock();
    const questions = block.quiz.questions;
    ui.feedback = null;
    ui.currentHintShown = false;
    if (ui.questionIndex < questions.length - 1) {
      ui.questionIndex += 1;
    } else {
      const level = currentLevel();
      await persist(completeBlock(ui.bundle.progress, level.id, block.id));
      const blocks = sortedBlocks(level);
      if (ui.blockIndex < blocks.length - 1) {
        ui.blockIndex += 1;
        ui.phase = "theory";
        ui.questionIndex = 0;
      } else {
        ui.phase = "exam";
        ui.questionIndex = 0;
        ui.examAnswers = {};
        ui.hintsUsed = 0;
      }
    }
    await persist(touchSession(ui.bundle.progress, {
      view: "study",
      levelId: ui.levelId,
      phase: ui.phase,
      blockIndex: ui.blockIndex,
      questionIndex: ui.questionIndex,
    }));
    renderStudy();
  });
  mainEl.querySelectorAll("[data-exam-answer]").forEach((btn) => {
    btn.onclick = () => {
      const q = ui.phase === "skip_exam"
        ? ui.skipExam.questions[ui.questionIndex]
        : currentLevel().exam.questions[ui.questionIndex];
      ui.examAnswers[q.id] = btn.dataset.examAnswer;
      renderStudy();
    };
  });
  document.getElementById("examPrev")?.addEventListener("click", () => {
    if (ui.questionIndex > 0) {
      ui.questionIndex -= 1;
      ui.currentHintShown = false;
    }
    renderStudy();
  });
  document.getElementById("examNext")?.addEventListener("click", async () => {
    if (ui.phase === "skip_exam") {
      const exam = ui.skipExam;
      if (ui.questionIndex < exam.questions.length - 1) {
        ui.questionIndex += 1;
        ui.currentHintShown = false;
        renderStudy();
        return;
      }
      const out = applySkipExamResult(ui.bundle.progress, ui.bundle.course, ui.levelId, exam, ui.examAnswers);
      await persist(touchSession(out.progress, { view: "study", phase: "skip_results", levelId: ui.levelId }));
      ui.examPack = out;
      ui.phase = "skip_results";
      renderStudy();
      return;
    }

    const exam = currentLevel().exam;
    if (ui.questionIndex < exam.questions.length - 1) {
      ui.questionIndex += 1;
      ui.currentHintShown = false;
      renderStudy();
      return;
    }
    const out = applyExamResult(ui.bundle.progress, ui.bundle.course, currentLevel(), exam, ui.examAnswers);
    await persist(touchSession(out.progress, { view: "study", phase: "results", levelId: ui.levelId }));
    ui.examPack = out;
    ui.phase = "results";
    renderStudy();
  });
  document.getElementById("retryExam")?.addEventListener("click", () => {
    ui.phase = "exam";
    ui.questionIndex = 0;
    ui.examAnswers = {};
    ui.examPack = null;
    ui.hintsUsed = 0;
    ui.currentHintShown = false;
    renderStudy();
  });
  document.getElementById("goNextLevel")?.addEventListener("click", () => {
    const nextId = ui.examPack?.unlockedLevelId;
    if (nextId) openLevel(nextId);
  });
  document.getElementById("backPath")?.addEventListener("click", async () => {
    ui.view = "subject";
    document.body.classList.remove("focus-mode");
    await renderSubjectDetail(ui.subjectId, ui.courseId);
  });
  // Skip-level exam handlers
  bindSkipExamActions();
}

function bindSkipExamActions() {
  document.getElementById("enterTargetLevel")?.addEventListener("click", () => {
    openLevel(ui.levelId);
  });
  document.getElementById("retrySkipExam")?.addEventListener("click", () => {
    startSkipExam(ui.levelId);
  });
}

function currentLevel() {
  return getLevelById(ui.bundle.course, ui.levelId);
}
function currentBlock() {
  return sortedBlocks(currentLevel())[ui.blockIndex];
}
function isDone(progress, levelId, blockId) {
  return ((progress.completedBlocks || {})[levelId] || []).includes(blockId);
}
function canJumpBlock(progress, level, index) {
  const blocks = sortedBlocks(level);
  for (let k = 0; k < index; k++) {
    if (!isDone(progress, level.id, blocks[k].id)) return false;
  }
  return true;
}
function labelStatus(status) {
  if (status === "passed") return "Aprobado";
  if (status === "in_progress") return "En progreso";
  if (status === "available") return "Disponible";
  return "Bloqueado";
}

function showMaterialPreview(material) {
  let panel = document.getElementById("materialPreviewPanel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "materialPreviewPanel";
    panel.className = "material-preview";
    document.body.appendChild(panel);
  }
  panel.innerHTML = `
    <div class="preview-header">
      <h3>${escapeHtml(material.name)}</h3>
      <button id="closeMaterialPreview" class="secondary">✕ Cerrar</button>
    </div>
    <pre class="preview-content">${escapeHtml(material.content || "(Sin contenido)")}</pre>`;
  panel.style.display = "block";
  document.getElementById("closeMaterialPreview").onclick = () => {
    panel.style.display = "none";
  };
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s || "";
  return d.innerHTML;
}

window.getAcademiaContext = () => ({
  view: ui.view,
  profileId: getActiveProfileId(),
  subjectId: ui.subjectId || getActiveSubjectId(),
  levelId: ui.view === "study" ? ui.levelId : null,
  levelTitle: ui.view === "study" && ui.bundle ? getLevelById(ui.bundle.course, ui.levelId)?.title : null,
  subjectTitle: document.querySelector("#main h1")?.textContent || "",
});
window.academiaGoHome = async () => {
  document.body.classList.remove("focus-mode");
  ui.view = "dashboard";
  ui.bundle = null;
  ui.levelId = null;
  await renderMain();
};
window.renderMainPanel = renderMain;
window.openAcademiaSubject = openSubject;
window.startSkipExam = startSkipExam;

const origRenderSubjects = window.renderSubjects;
if (origRenderSubjects) {
  window.renderSubjects = async function () {
    await origRenderSubjects();
    if (ui.view === "dashboard" || ui.view === "welcome") renderMain();
  };
}
const origRenderProfiles = window.renderProfiles;
if (origRenderProfiles) {
  window.renderProfiles = async function () {
    await origRenderProfiles();
    ui.view = "dashboard";
    ui.bundle = null;
    renderMain();
  };
}

if (getActiveSubjectId()) {
  ui.subjectId = getActiveSubjectId();
  window._currentSubjectId = ui.subjectId;
}

renderMain();
