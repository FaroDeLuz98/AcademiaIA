@echo off
title Academia IA
cd /d "%~dp0"

echo ===================================================================
echo                     ACADEMIA IA - SERVIDOR
echo ===================================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js no esta instalado.
    echo Descargalo desde https://nodejs.org/
    pause
    exit /b 1
)

node server.js
pause
