import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import "fake-indexeddb/auto";

if (typeof globalThis.localStorage === "undefined") {
  const store = {};
  globalThis.localStorage = {
    getItem(key) { return store[key] ?? null; },
    setItem(key, val) { store[key] = String(val); },
    removeItem(key) { delete store[key]; },
    clear() { for (const k of Object.keys(store)) delete store[k]; },
  };
}

const {
  addProfile,
  getAllProfiles,
  deleteProfile,
  addSubject,
  addMaterial,
  getMaterials,
} = await import("../src/storage.js");

const {
  saveCourse,
  getCoursesBySubject,
  getProgressByCourse,
  saveProgress,
  buildExportPayload,
  importPayload,
} = await import("../src/courseStore.js");

const {
  validateCourse,
  answerQuiz,
  completeBlock,
  applyExamResult,
  getLevelStatus,
  canStartExam,
  createInitialProgress,
} = await import("../src/courseEngine.js");

const { createDemoCourseDefinition } = await import("../src/demoCourse.js");

beforeEach(async () => {
  const profiles = await getAllProfiles();
  for (const p of profiles) await deleteProfile(p.id);
  localStorage.clear();
});

function answerAllCorrect(questions) {
  const answers = {};
  for (const q of questions) answers[q.id] = q.correctOptionId;
  return answers;
}

describe("Demo course JSON", () => {
  it("validates as a complete reusable course", () => {
    const def = createDemoCourseDefinition();
    assert.equal(validateCourse(def), true);
    assert.equal(def.levels.length, 3);
    for (const level of def.levels) {
      assert.equal(level.blocks.length, 3);
      for (const block of level.blocks) {
        assert.equal(block.quiz.questions.length, 5);
        assert.equal(block.quiz.questions[0].options.length, 4);
      }
      assert.equal(level.exam.questions.length, 15);
      assert.equal(level.exam.passScore, 12);
    }
  });
});

describe("Course store and isolation", () => {
  it("creates a course associated to profile and subject", async () => {
    const profileId = await addProfile("Ana");
    const subjectId = await addSubject(profileId, "Economía", "1");
    const saved = await saveCourse({
      profileId,
      subjectId,
      definition: createDemoCourseDefinition(),
      source: "demo",
    });
    const list = await getCoursesBySubject(profileId, subjectId);
    assert.equal(list.length, 1);
    assert.equal(list[0].id, saved.course.id);
    const progress = await getProgressByCourse(saved.course.id);
    assert.equal(progress.profileId, profileId);
    assert.equal(progress.subjectId, subjectId);
    assert.deepEqual(progress.unlockedLevelIds, ["demo-l1"]);
  });

  it("does not mix progress between profiles", async () => {
    const a = await addProfile("A");
    const b = await addProfile("B");
    const subA = await addSubject(a, "Eco", "");
    const subB = await addSubject(b, "Eco", "");
    const courseA = await saveCourse({ profileId: a, subjectId: subA, definition: createDemoCourseDefinition(), source: "demo" });
    await saveCourse({ profileId: b, subjectId: subB, definition: createDemoCourseDefinition(), source: "demo" });
    const level = courseA.course.definition.levels[0];
    const q = level.blocks[0].quiz.questions[0];
    const answered = answerQuiz(courseA.progress, q, q.correctOptionId);
    await saveProgress(answered.progress);
    const progressA = await getProgressByCourse(courseA.course.id);
    const coursesB = await getCoursesBySubject(b, subB);
    const progressB = await getProgressByCourse(coursesB[0].id);
    assert.ok(progressA.xp > 0);
    assert.equal(progressB.xp, 0);
  });

  it("keeps uploaded documents after creating a course", async () => {
    const profileId = await addProfile("Docs");
    const subjectId = await addSubject(profileId, "Eco", "");
    await addMaterial({ profileId, subjectId, name: "apunte.txt", fileType: ".txt", content: "oferta y demanda" });
    await saveCourse({ profileId, subjectId, definition: createDemoCourseDefinition(), source: "demo" });
    const mats = await getMaterials(profileId, subjectId);
    assert.equal(mats.length, 1);
    assert.equal(mats[0].content, "oferta y demanda");
  });
});

describe("Quizzes, exams, XP and unlock", () => {
  it("navigates blocks, grades quizzes and unlocks the next level on a passing exam", async () => {
    const def = createDemoCourseDefinition();
    let progress = createInitialProgress(1, 2, 3, def);
    const level = def.levels[0];
    assert.equal(getLevelStatus(def, progress, "demo-l2"), "locked");
    assert.equal(canStartExam(level, progress), false);

    for (const block of level.blocks) {
      for (const question of block.quiz.questions) {
        const out = answerQuiz(progress, question, question.correctOptionId);
        progress = out.progress;
        assert.equal(out.result.correct, true);
      }
      progress = completeBlock(progress, level.id, block.id);
    }
    assert.equal(canStartExam(level, progress), true);
    assert.equal(progress.xp, 10 * 15);

    const first = applyExamResult(progress, def, level, level.exam, answerAllCorrect(level.exam.questions));
    progress = first.progress;
    assert.equal(first.result.passed, true);
    assert.equal(first.result.correct, 15);
    assert.equal(first.unlockedLevelId, "demo-l2");
    assert.equal(getLevelStatus(def, progress, "demo-l2"), "available");
    const expectedExamXp = 15 * 4 + 30;
    assert.equal(first.xpGained, expectedExamXp);

    const second = applyExamResult(progress, def, level, level.exam, answerAllCorrect(level.exam.questions));
    assert.equal(second.xpGained, 0);
    assert.equal(second.alreadyAwarded, true);
    assert.equal(second.progress.xp, progress.xp);
  });

  it("fails the exam below 12/15 and does not unlock", () => {
    const def = createDemoCourseDefinition();
    let progress = createInitialProgress(1, 2, 3, def);
    const level = def.levels[0];
    const answers = {};
    level.exam.questions.forEach((q, i) => {
      answers[q.id] = i < 11 ? q.correctOptionId : q.options.find((o) => o.id !== q.correctOptionId).id;
    });
    const out = applyExamResult(progress, def, level, level.exam, answers);
    assert.equal(out.result.correct, 11);
    assert.equal(out.result.passed, false);
    assert.equal(out.unlockedLevelId, null);
    assert.equal(getLevelStatus(def, out.progress, "demo-l2"), "locked");
  });

  it("shows immediate quiz feedback concept and explanation", () => {
    const def = createDemoCourseDefinition();
    const progress = createInitialProgress(1, 2, 3, def);
    const question = def.levels[0].blocks[0].quiz.questions[0];
    const wrong = question.options.find((o) => o.id !== question.correctOptionId).id;
    const out = answerQuiz(progress, question, wrong);
    assert.equal(out.result.correct, false);
    assert.ok(out.result.explanation.length > 0);
    assert.ok(out.result.relatedConcept.length > 0);
    assert.equal(out.xpGained, 0);
  });
});

describe("Persistence and export/import", () => {
  it("restores XP and unlock after reload", async () => {
    const profileId = await addProfile("Persist");
    const subjectId = await addSubject(profileId, "Eco", "");
    const saved = await saveCourse({ profileId, subjectId, definition: createDemoCourseDefinition(), source: "demo" });
    const def = saved.course.definition;
    const level = def.levels[0];
    let progress = saved.progress;
    for (const block of level.blocks) {
      for (const question of block.quiz.questions) {
        progress = answerQuiz(progress, question, question.correctOptionId).progress;
      }
      progress = completeBlock(progress, level.id, block.id);
    }
    progress = applyExamResult(progress, def, level, level.exam, answerAllCorrect(level.exam.questions)).progress;
    await saveProgress(progress);

    const reloaded = await getProgressByCourse(saved.course.id);
    assert.equal(reloaded.xp, progress.xp);
    assert.ok(reloaded.passedLevelIds.includes("demo-l1"));
    assert.ok(reloaded.unlockedLevelIds.includes("demo-l2"));
  });

  it("exports and imports courses, progress and documents", async () => {
    const profileId = await addProfile("Export");
    const subjectId = await addSubject(profileId, "Eco", "");
    await addMaterial({ profileId, subjectId, name: "tema.txt", fileType: ".txt", content: "notas" });
    const saved = await saveCourse({ profileId, subjectId, definition: createDemoCourseDefinition(), source: "demo" });
    saved.progress.xp = 40;
    saved.progress.passedLevelIds = ["demo-l1"];
    await saveProgress(saved.progress);

    const payload = await buildExportPayload(profileId);
    assert.equal(payload.courses.length, 1);
    assert.equal(payload.materials[0].content, "notas");

    const imported = await importPayload(payload);
    assert.ok(imported.profileId);
    const newSubjectId = Object.values(imported.subjectIdMap)[0];
    const courses = await getCoursesBySubject(imported.profileId, newSubjectId);
    assert.equal(courses.length, 1);
    const progress = await getProgressByCourse(courses[0].id);
    assert.equal(progress.xp, 40);
    assert.deepEqual(progress.passedLevelIds, ["demo-l1"]);
    const mats = await getMaterials(imported.profileId, newSubjectId);
    assert.equal(mats[0].content, "notas");
  });
});
