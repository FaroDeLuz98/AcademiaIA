import { describe, it } from "node:test";
import assert from "node:assert/strict";

const {
  createSkipExam,
  applySkipExamResult,
  getPriorLevels,
  shuffleOptions,
  createInitialProgress,
  sortedLevels,
  gradeExam,
} = await import("../src/courseEngine.js");

const { createEconomicsCourseDefinition } = await import("../src/economicsCourse.js");

describe("Nuevas funcionalidades: Pistas, Barajado y Salto de Niveles", () => {
  const course = createEconomicsCourseDefinition();

  it("las respuestas correctas no son todas la opción 'a' (están barajadas)", () => {
    let total = 0;
    let nonA = 0;
    for (const level of course.levels) {
      for (const block of level.blocks) {
        for (const q of block.quiz.questions) {
          total++;
          if (q.correctOptionId !== "a") nonA++;
        }
      }
      for (const q of level.exam.questions) {
        total++;
        if (q.correctOptionId !== "a") nonA++;
      }
    }
    assert(total > 200, "Debe haber más de 200 preguntas");
    // Al menos el 60% de las preguntas no debe ser 'a'
    const pctNonA = (nonA / total) * 100;
    assert(pctNonA > 60, `Se esperaba >60% respuestas distintas de 'a', obtenido: ${pctNonA.toFixed(1)}%`);
  });

  it("shuffleOptions cambia el orden de las opciones manteniendo IDs y correctOptionId válido", () => {
    const q = {
      id: "test-q1",
      prompt: "¿Qué es el dinero?",
      options: [
        { id: "a", text: "Opción A" },
        { id: "b", text: "Opción B" },
        { id: "c", text: "Opción C" },
        { id: "d", text: "Opción D" },
      ],
      correctOptionId: "c",
    };
    const shuffled = shuffleOptions(q);
    assert.equal(shuffled.options.length, 4);
    assert(shuffled.options.some((o) => o.id === "c"), "La opción correcta sigue existiendo");
  });

  it("getPriorLevels devuelve todos los niveles anteriores al objetivo", () => {
    const priorToL3 = getPriorLevels(course, "money-l3");
    assert.equal(priorToL3.length, 2);
    assert.equal(priorToL3[0].id, "money-l1");
    assert.equal(priorToL3[1].id, "money-l2");

    const priorToL1 = getPriorLevels(course, "money-l1");
    assert.equal(priorToL1.length, 0);
  });

  it("createSkipExam genera un examen integrador con preguntas de todos los niveles anteriores", () => {
    const skipExam = createSkipExam(course, "money-l4");
    assert(skipExam, "Debe crearse el examen de salto");
    assert.equal(skipExam.targetLevelId, "money-l4");
    assert.equal(skipExam.priorLevelsCount, 3);
    assert(skipExam.questions.length >= 10, "Debe tener al menos 10 preguntas");
    assert(skipExam.passScore > 0, "Debe tener puntaje de aprobación");
  });

  it("applySkipExamResult aprueba y desbloquea el nivel objetivo y todos los anteriores", () => {
    let progress = createInitialProgress("p1", 1, "c1", course);
    const skipExam = createSkipExam(course, "money-l3");
    
    // Responder todas correctamente
    const answers = {};
    for (const q of skipExam.questions) {
      answers[q.id] = q.correctOptionId;
    }

    const res = applySkipExamResult(progress, course, "money-l3", skipExam, answers);
    assert(res.result.passed, "El examen debe estar aprobado");
    assert(res.progress.unlockedLevelIds.includes("money-l3"), "Nivel 3 debe estar desbloqueado");
    assert(res.progress.passedLevelIds.includes("money-l1"), "Nivel 1 debe estar aprobado");
    assert(res.progress.passedLevelIds.includes("money-l2"), "Nivel 2 debe estar aprobado");
    assert(res.xpGained > 0, "Debe ganar XP");
  });

  it("applySkipExamResult reprueba si no alcanza el puntaje y no desbloquea el nivel", () => {
    let progress = createInitialProgress("p1", 1, "c1", course);
    const skipExam = createSkipExam(course, "money-l3");

    // Responder todo mal (o vacío)
    const answers = {};
    for (const q of skipExam.questions) {
      answers[q.id] = "wrong_choice";
    }

    const res = applySkipExamResult(progress, course, "money-l3", skipExam, answers);
    assert(!res.result.passed, "El examen no debe estar aprobado");
    assert(!res.progress.unlockedLevelIds.includes("money-l3"), "Nivel 3 NO debe estar desbloqueado");
  });
});
