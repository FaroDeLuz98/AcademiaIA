// tests/profile.test.mjs
import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import "fake-indexeddb/auto";

// localStorage shim for Node
if (typeof globalThis.localStorage === "undefined") {
  const store = {};
  globalThis.localStorage = {
    getItem(key) { return store[key] ?? null; },
    setItem(key, val) { store[key] = String(val); },
    removeItem(key) { delete store[key]; },
    clear() { for (const k of Object.keys(store)) delete store[k]; },
  };
}

const {
  openDB,
  addProfile,
  getAllProfiles,
  updateProfile,
  deleteProfile,
  addSubject,
  getSubjectsByProfile,
  setActiveProfileId,
  getActiveProfileId,
} = await import("../src/storage.js");

// Reset the database before each test by deleting all profiles
beforeEach(async () => {
  const profiles = await getAllProfiles();
  for (const p of profiles) {
    await deleteProfile(p.id);
  }
  localStorage.clear();
});

describe("Profile CRUD", () => {
  it("should create a profile and retrieve it", async () => {
    const id = await addProfile("Test User");
    assert.ok(id, "addProfile should return an id");
    const profiles = await getAllProfiles();
    assert.ok(profiles.length >= 1, "Should have at least one profile");
    const found = profiles.find((p) => p.id === id);
    assert.ok(found, "Profile should be found");
    assert.equal(found.name, "Test User");
  });

  it("should update a profile name", async () => {
    const id = await addProfile("Original");
    await updateProfile(id, "Updated");
    const profiles = await getAllProfiles();
    const found = profiles.find((p) => p.id === id);
    assert.equal(found.name, "Updated");
  });

  it("should delete a profile and cascade delete subjects", async () => {
    const profileId = await addProfile("ToDelete");
    await addSubject(profileId, "Math", "Level 1");
    await addSubject(profileId, "Science", "Level 2");

    // Verify subjects exist
    const subjectsBefore = await getSubjectsByProfile(profileId);
    assert.equal(subjectsBefore.length, 2);

    // Delete profile
    await deleteProfile(profileId);

    // Verify profile is gone
    const profiles = await getAllProfiles();
    assert.ok(!profiles.find((p) => p.id === profileId), "Profile should be deleted");

    // Verify subjects are cascade-deleted
    const subjectsAfter = await getSubjectsByProfile(profileId);
    assert.equal(subjectsAfter.length, 0, "Subjects should be cascade-deleted");
  });

  it("should persist active profile in localStorage", async () => {
    const id = await addProfile("Active User");
    setActiveProfileId(id);
    const retrieved = getActiveProfileId();
    assert.equal(retrieved, id, "Active profile ID should persist");
  });
});
