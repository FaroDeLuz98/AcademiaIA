import { test, expect } from "@playwright/test";

test.describe.configure({ mode: "serial" });

test("verifica pistas (máx 3), resumen y examen de salto de nivel", async ({ page }) => {
  await page.goto("http://127.0.0.1:8000/");

  // Reset base de datos
  await page.evaluate(async () => {
    indexedDB.deleteDatabase("academia_ia");
    localStorage.clear();
  });
  await page.reload();

  // 1. Crear perfil y materia
  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Tester");
  await page.click('#profileForm button[type="submit"]');

  await page.click("#addSubjectBtn");
  await page.fill("#subjectNameInput", "Economía");
  await page.click('#subjectForm button[type="submit"]');

  await page.getByRole("button", { name: "Estudiar" }).click();

  // 2. Importar Academia del Dinero
  await page.locator(".course-catalog-card", { hasText: "Academia del Dinero" })
    .getByRole("button", { name: "Importar curso" }).click();

  await expect(page.getByRole("heading", { name: "Camino de niveles" })).toBeVisible();

  // 3. Verificar que los niveles bloqueados tienen el botón de Saltear
  const skipBtnL2 = page.locator('button[data-skip-level="money-l2"]');
  await expect(skipBtnL2).toBeVisible();
  await expect(skipBtnL2).toContainText("Saltear a este nivel");

  // 4. Entrar al Nivel 1 a estudiar
  await page.locator("#continueLevelBtn").click();
  await page.getByRole("button", { name: "Ir al quiz guiado" }).click();

  // 5. Probar botón Pista y botón Resumen en el Quiz
  const hintBtn = page.locator("#showHintBtn");
  await expect(hintBtn).toBeVisible();
  await expect(hintBtn).toContainText("Pista (3 restantes)");

  // Usar pista 1
  await hintBtn.click();
  await expect(page.locator(".hint-box")).toBeVisible();

  // Probar botón Resumen
  const summaryBtn = page.locator("#showSummaryBtn");
  await expect(summaryBtn).toBeVisible();
  await summaryBtn.click();
  await expect(page.locator(".summary-panel")).toBeVisible();
  await expect(page.locator(".summary-panel h3")).toContainText("Resumen:");

  // Cerrar resumen
  await page.locator("#closeSummaryBtn").click();
  await expect(page.locator(".summary-panel")).toHaveCount(0);

  // 6. Volver al camino de niveles
  await page.locator("#backToSubject").click();
  await expect(page.getByRole("heading", { name: "Camino de niveles" })).toBeVisible();

  // 7. Probar Salto de Nivel: hacer click en el examen de salto al Nivel 2
  // Aceptamos el diálogo de confirmación automáticamente
  page.on("dialog", (dialog) => dialog.accept());
  await skipBtnL2.click();

  // Verificar que se entra al Examen de Salto con preguntas integradoras
  await expect(page.getByRole("heading", { name: /Salto de nivel/ })).toBeVisible();
  await expect(page.locator(".skip-exam-header")).toBeVisible();
  await expect(page.locator(".skip-exam-header")).toContainText("Examen de Suficiencia Integrador");

  // Verificar que el examen tiene botón de Pistas (límite 3)
  const examHintBtn = page.locator("#showHintBtn");
  await expect(examHintBtn).toBeVisible();
  await expect(examHintBtn).toContainText("Pista (3)");

  // Usar pista en el examen
  await examHintBtn.click();
  await expect(page.locator(".hint-box")).toBeVisible();
  await expect(page.locator(".hint-box")).toContainText("Pista:");
});
