import { test, expect } from "@playwright/test";
import { createDemoCourseDefinition } from "../src/demoCourse.js";

test.describe.configure({ mode: "serial" });

test("perfil, materias aisladas y curso demo", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(async () => {
    indexedDB.deleteDatabase("academia_ia");
    localStorage.clear();
  });
  await page.reload();

  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Alice");
  await page.click('#profileForm button[type="submit"]');
  await expect(page.locator('li.profile-item:has-text("Alice")')).toBeVisible();

  await page.click("#addSubjectBtn");
  await page.fill("#subjectNameInput", "Economía");
  await page.fill("#subjectLevelInput", "Nivel 1");
  await page.click('#subjectForm button[type="submit"]');
  await expect(page.locator('li.subject-item:has-text("Economía")')).toBeVisible();
  await expect(page.getByRole("heading", { name: /Hola, Alice/ })).toBeVisible();

  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Bob");
  await page.click('#profileForm button[type="submit"]');
  await page.locator("li.profile-item", { hasText: "Bob" }).getByRole("button", { name: "Seleccionar" }).click();
  await expect(page.locator("#subjectList")).toContainText("No hay materias");
  await expect(page.locator('li.subject-item:has-text("Economía")')).toHaveCount(0);

  await page.locator("li.profile-item", { hasText: "Alice" }).getByRole("button", { name: "Seleccionar" }).click();
  await expect(page.locator('li.subject-item:has-text("Economía")')).toBeVisible();

  await page.getByRole("button", { name: "Estudiar" }).click();
  await expect(page.getByRole("heading", { name: "Economía" })).toBeVisible();
  await page.locator(".course-catalog-card", { hasText: "Técnicas de estudio" })
    .getByRole("button", { name: "Importar curso" }).click();
  await expect(page.getByRole("heading", { name: "Camino de niveles" })).toBeVisible();
  await expect(page.getByRole("button", { name: /Técnicas de estudio/ })).toBeEnabled();
  await expect(page.getByRole("button", { name: /Comprensión/ })).toBeDisabled();

  await page.locator("#continueLevelBtn").click();
  await expect(page.getByRole("heading", { name: "Atención y entorno" })).toBeVisible();
  await page.getByRole("button", { name: "Ir al quiz guiado" }).click();
  await expect(page.getByRole("heading", { name: /objetivo principal/ })).toBeVisible();
  await page.getByRole("button", { name: /Dirigir la atención/ }).click();
  await expect(page.locator(".feedback.ok")).toBeVisible();
  await expect(page.getByText("Concepto:")).toBeVisible();
});

test("examen aprueba, da XP una sola vez y desbloquea", async ({ page }) => {
  const def = createDemoCourseDefinition();
  await page.goto("/");
  await page.evaluate(async (definition) => {
    indexedDB.deleteDatabase("academia_ia");
    localStorage.clear();
    await new Promise((r) => setTimeout(r, 50));
  }, def);
  await page.reload();

  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Ana");
  await page.click('#profileForm button[type="submit"]');
  await page.click("#addSubjectBtn");
  await page.fill("#subjectNameInput", "Estudio");
  await page.click('#subjectForm button[type="submit"]');
  await page.getByRole("button", { name: "Estudiar" }).click();
  await page.locator(".course-catalog-card", { hasText: "Técnicas de estudio" })
    .getByRole("button", { name: "Importar curso" }).click();
  await expect(page.locator("#continueLevelBtn")).toBeVisible();

  const after = await page.evaluate(async (definition) => {
    const { getActiveProfileId, getActiveSubjectId } = await import("./src/storage.js");
    const { getCoursesBySubject, getProgressByCourse, saveProgress } = await import("./src/courseStore.js");
    const { answerQuiz, completeBlock, applyExamResult } = await import("./src/courseEngine.js");
    const profileId = getActiveProfileId();
    const subjectId = getActiveSubjectId();
    const courses = await getCoursesBySubject(profileId, subjectId);
    const course = courses[0];
    let progress = await getProgressByCourse(course.id);
    const level = definition.levels[0];
    for (const block of level.blocks) {
      for (const question of block.quiz.questions) {
        progress = answerQuiz(progress, question, question.correctOptionId).progress;
      }
      progress = completeBlock(progress, level.id, block.id);
    }
    const answers = {};
    for (const q of level.exam.questions) answers[q.id] = q.correctOptionId;
    const first = applyExamResult(progress, definition, level, level.exam, answers);
    await saveProgress(first.progress);
    const second = applyExamResult(first.progress, definition, level, level.exam, answers);
    await saveProgress(second.progress);
    const reloaded = await getProgressByCourse(course.id);
    return {
      xp: reloaded.xp,
      firstXp: first.xpGained,
      secondXp: second.xpGained,
      unlocked: reloaded.unlockedLevelIds,
      passed: reloaded.passedLevelIds,
    };
  }, def);

  expect(after.passed).toContain("demo-l1");
  expect(after.unlocked).toContain("demo-l2");
  expect(after.secondXp).toBe(0);
  expect(after.xp).toBe(after.firstXp + 10 * 15);

  await page.reload();
  await page.getByRole("button", { name: "Estudiar" }).click();
  await expect(page.getByText("Niveles aprobados")).toBeVisible();
  await expect(page.getByRole("button", { name: /Comprensión/ })).toBeEnabled();
  await expect(page.locator("#xp")).toContainText(String(after.xp));
});

test("importa Academia del Dinero, muestra el camino y entra en modo focus", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(async () => {
    indexedDB.deleteDatabase("academia_ia");
    localStorage.clear();
  });
  await page.reload();

  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Eco");
  await page.click('#profileForm button[type="submit"]');
  await page.click("#addSubjectBtn");
  await page.fill("#subjectNameInput", "Economía");
  await page.click('#subjectForm button[type="submit"]');
  await page.getByRole("button", { name: "Estudiar" }).click();

  const card = page.locator(".course-catalog-card", { hasText: "Academia del Dinero" });
  await expect(card).toContainText("9 niveles");
  await expect(card).toContainText("Recomendado para Economía");
  await card.getByRole("button", { name: "Importar curso" }).click();

  await expect(page.getByRole("heading", { name: "Camino de niveles" })).toBeVisible();
  await expect(page.locator(".level-node")).toHaveCount(9);
  await expect(page.locator(".level-node").first()).toContainText("Fundamentos y evolución del dinero");
  await expect(page.locator(".level-node").first()).toContainText("Disponible");
  await expect(page.locator(".level-node").nth(1)).toContainText("Bloqueado");

  await page.locator('[data-open-level="money-l1"]').click();
  await expect(page.getByRole("heading", { name: "Fundamentos y evolución del dinero" })).toBeVisible();
  await expect(page.locator(".theory-html").first()).toBeVisible();
  await expect(page.locator(".theory-html").first()).toContainText("funciones básicas del dinero");
  await expect(page.locator("body")).toHaveClass(/focus-mode/);
  await expect(page.locator("#profilePanel")).toBeHidden();
  await page.getByRole("button", { name: "Mostrar paneles" }).click();
  await expect(page.locator("body")).not.toHaveClass(/focus-mode/);
  await expect(page.locator("#profilePanel")).toBeVisible();
  await page.getByRole("button", { name: "← Camino" }).click();
  await expect(page.locator(".level-node")).toHaveCount(9);
});

test("importa progreso anterior solo al confirmar", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(async () => {
    indexedDB.deleteDatabase("academia_ia");
    localStorage.clear();
    localStorage.setItem(
      "academia-dinero-v1",
      JSON.stringify({
        xp: 420,
        parts: { "1-0": 1, "1-1": 1, "2-0": 1 },
        exams: { 1: { best: 86, passed: true, bonus: true, source: "final" } },
        ans: {},
        errHistory: {},
        conceptStats: {},
        hist: [],
      })
    );
  });
  await page.reload();

  await page.click("#addProfileBtn");
  await page.fill("#profileNameInput", "Legacy");
  await page.click('#profileForm button[type="submit"]');
  await page.click("#addSubjectBtn");
  await page.fill("#subjectNameInput", "Economía");
  await page.click('#subjectForm button[type="submit"]');
  await page.getByRole("button", { name: "Estudiar" }).click();
  await page.locator(".course-catalog-card", { hasText: "Academia del Dinero" })
    .getByRole("button", { name: "Importar curso" }).click();

  const panel = page.locator(".legacy-import");
  await expect(panel).toBeVisible();
  await expect(panel).toContainText("Niveles aprobados: 1");
  await expect(panel).toContainText("Bloques completados: 3");
  await page.on("dialog", (dialog) => dialog.accept());
  await panel.getByRole("button", { name: "Importar progreso anterior" }).click();

  await expect(panel).toHaveCount(0);
  await expect(page.locator(".level-node").first()).toContainText("Aprobado");
  await expect(page.locator('.level-node:has-text("Fundamentos") .lvl-cta')).toHaveText("Repasar");
  await expect(page.locator('[data-open-level="money-l2"]')).toBeEnabled();
  await expect(page.locator(".stats")).toContainText("1/9");
});
