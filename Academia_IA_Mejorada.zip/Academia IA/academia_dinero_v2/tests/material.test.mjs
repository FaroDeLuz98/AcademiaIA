// tests/material.test.mjs
import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import "fake-indexeddb/auto";

// localStorage shim for Node
if (typeof globalThis.localStorage === "undefined") {
  const store = {};
  globalThis.localStorage = {
    getItem(key) { return store[key] ?? null; },
    setItem(key, val) { store[key] = String(val); },
    removeItem(key) { delete store[key]; },
    clear() { for (const k of Object.keys(store)) delete store[k]; },
  };
}

const {
  addProfile,
  getAllProfiles,
  deleteProfile,
  addSubject,
  getSubjectsByProfile,
  deleteSubject,
  addMaterial,
  getMaterials,
  updateMaterial,
  deleteMaterial,
} = await import("../src/storage.js");

// Clean up before each test
beforeEach(async () => {
  const profiles = await getAllProfiles();
  for (const p of profiles) {
    await deleteProfile(p.id);
  }
  localStorage.clear();
});

describe("Material CRUD", () => {
  it("should add a material and retrieve it", async () => {
    const profileId = await addProfile("Mat User");
    const subjectId = await addSubject(profileId, "History", "101");
    const matId = await addMaterial({
      profileId,
      subjectId,
      name: "notes.txt",
      fileType: ".txt",
      content: "Some notes",
    });
    assert.ok(matId, "addMaterial should return an id");
    const materials = await getMaterials(profileId, subjectId);
    assert.equal(materials.length, 1);
    assert.equal(materials[0].name, "notes.txt");
    assert.equal(materials[0].content, "Some notes");
  });

  it("should scope materials to profile and subject", async () => {
    const profileA = await addProfile("Alice");
    const profileB = await addProfile("Bob");
    const subA = await addSubject(profileA, "Math", "1");
    const subB = await addSubject(profileB, "Science", "2");

    await addMaterial({ profileId: profileA, subjectId: subA, name: "a.txt", fileType: ".txt", content: "A" });
    await addMaterial({ profileId: profileB, subjectId: subB, name: "b.txt", fileType: ".txt", content: "B" });

    const matsA = await getMaterials(profileA, subA);
    const matsB = await getMaterials(profileB, subB);

    assert.equal(matsA.length, 1);
    assert.equal(matsA[0].name, "a.txt");
    assert.equal(matsB.length, 1);
    assert.equal(matsB[0].name, "b.txt");

    // Cross-check: profile A should not see profile B's materials
    const crossCheck = await getMaterials(profileA, subB);
    assert.equal(crossCheck.length, 0, "Materials should be scoped");
  });

  it("should update a material name", async () => {
    const profileId = await addProfile("Updater");
    const subjectId = await addSubject(profileId, "Art", "1");
    const matId = await addMaterial({
      profileId,
      subjectId,
      name: "old.txt",
      fileType: ".txt",
      content: "content",
    });
    await updateMaterial(matId, { name: "new.txt" });
    const materials = await getMaterials(profileId, subjectId);
    assert.equal(materials[0].name, "new.txt");
  });

  it("should delete a material", async () => {
    const profileId = await addProfile("Deleter");
    const subjectId = await addSubject(profileId, "Music", "1");
    const matId = await addMaterial({
      profileId,
      subjectId,
      name: "song.txt",
      fileType: ".txt",
      content: "do re mi",
    });
    await deleteMaterial(matId);
    const materials = await getMaterials(profileId, subjectId);
    assert.equal(materials.length, 0);
  });

  it("should cascade delete materials when subject is deleted", async () => {
    const profileId = await addProfile("CascadeUser");
    const subjectId = await addSubject(profileId, "Physics", "1");
    await addMaterial({ profileId, subjectId, name: "ch1.txt", fileType: ".txt", content: "gravity" });
    await addMaterial({ profileId, subjectId, name: "ch2.txt", fileType: ".txt", content: "force" });

    // Verify materials exist
    const before = await getMaterials(profileId, subjectId);
    assert.equal(before.length, 2);

    // Delete subject
    await deleteSubject(subjectId);

    // Verify subjects deleted
    const subjects = await getSubjectsByProfile(profileId);
    assert.equal(subjects.length, 0);

    // Verify materials cascade-deleted
    const after = await getMaterials(profileId, subjectId);
    assert.equal(after.length, 0, "Materials should be cascade-deleted with subject");
  });
});
