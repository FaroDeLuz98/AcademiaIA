import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import "fake-indexeddb/auto";

if (typeof globalThis.localStorage === "undefined") {
  const store = {};
  globalThis.localStorage = {
    getItem(key) { return store[key] ?? null; },
    setItem(key, val) { store[key] = String(val); },
    removeItem(key) { delete store[key]; },
    clear() { for (const k of Object.keys(store)) delete store[k]; },
  };
}

const { addProfile, getAllProfiles, deleteProfile, addSubject } = await import("../src/storage.js");
const { saveCourse, saveProgress, getCoursesBySubject, getProgressByCourse } =
  await import("../src/courseStore.js");
const {
  validateCourse,
  sortedLevels,
  sortedBlocks,
  answerQuiz,
  completeBlock,
  applyExamResult,
  canStartExam,
  createInitialProgress,
  getLevelStatus,
  getLevelDisplayStatus,
  getLevelExamSummary,
} = await import("../src/courseEngine.js");
const { createEconomicsCourseDefinition, ECONOMICS_COURSE_ID } =
  await import("../src/economicsCourse.js");
const {
  LEGACY_MONEY_KEY,
  readLegacyMoneyState,
  summarizeLegacyMoneyState,
  mergeLegacyMoneyProgress,
} = await import("../src/moneyProgressImport.js");

beforeEach(async () => {
  const profiles = await getAllProfiles();
  for (const p of profiles) await deleteProfile(p.id);
  localStorage.clear();
});

function answerAllCorrect(questions) {
  const answers = {};
  for (const q of questions) answers[q.id] = q.correctOptionId;
  return answers;
}

function completeAndPass(course, progress, level) {
  let next = progress;
  for (const block of sortedBlocks(level)) {
    for (const question of block.quiz.questions) {
      next = answerQuiz(next, question, question.correctOptionId).progress;
    }
    next = completeBlock(next, level.id, block.id);
  }
  assert.equal(canStartExam(level, next), true);
  return applyExamResult(next, course, level, level.exam, answerAllCorrect(level.exam.questions)).progress;
}

describe("Academia del Dinero course", () => {
  it("imports the nine original levels with their quizzes and exams", () => {
    const course = createEconomicsCourseDefinition();
    assert.equal(course.id, ECONOMICS_COURSE_ID);
    assert.equal(validateCourse(course), true);
    assert.equal(course.levels.length, 9);

    const levelIds = new Set();
    const blockIds = new Set();
    const questionIds = new Set();
    let quizQuestions = 0;
    let examQuestions = 0;

    for (const level of course.levels) {
      assert.ok(!levelIds.has(level.id));
      levelIds.add(level.id);
      assert.equal(level.blocks.length, 3);
      for (const block of level.blocks) {
        assert.ok(!blockIds.has(block.id));
        blockIds.add(block.id);
        assert.equal(block.quiz.questions.length, 5);
        for (const q of block.quiz.questions) {
          assert.ok(!questionIds.has(q.id));
          questionIds.add(q.id);
          assert.ok(q.options.length >= 2);
          assert.ok(q.explanation.length > 0);
        }
        quizQuestions += block.quiz.questions.length;
      }
      assert.equal(level.exam.questions.length, 15);
      assert.equal(level.exam.passScore, 12);
      for (const q of level.exam.questions) {
        assert.ok(!questionIds.has(q.id));
        questionIds.add(q.id);
      }
      examQuestions += level.exam.questions.length;
    }

    assert.equal(quizQuestions, 135);
    assert.equal(examQuestions, 135);
  });

  it("preserves the original titles, theory and explanations", () => {
    const course = createEconomicsCourseDefinition();
    const levels = sortedLevels(course);
    assert.equal(levels[0].title, "Fundamentos y evolución del dinero");
    assert.equal(levels[8].title, "Demanda de dinero, ingreso y tasa de interés");

    const theory = levels[0].blocks[0].theory.paragraphs.join(" ");
    assert.ok(theory.length > 500);
    assert.ok(/<[a-z][\s\S]*>/i.test(theory), "la teoría importada conserva HTML enriquecido");

    const first = levels[0].blocks[0].quiz.questions[0];
    assert.ok(first.prompt.length > 10);
    assert.ok(first.explanation.length > 10);
    assert.ok(first.relatedConcept.length > 0);
  });

  it("uses the shared engine to unlock all nine levels", () => {
    const course = createEconomicsCourseDefinition();
    let progress = createInitialProgress(1, 2, 3, course);
    const levels = sortedLevels(course);
    assert.equal(getLevelDisplayStatus(course, progress, "money-l1"), "available");
    assert.equal(getLevelDisplayStatus(course, progress, "money-l2"), "locked");

    for (let i = 0; i < levels.length; i += 1) {
      const level = levels[i];
      assert.equal(getLevelStatus(course, progress, level.id), "available");
      progress = completeAndPass(course, progress, level);
      assert.ok(progress.passedLevelIds.includes(level.id));
      const follower = levels[i + 1];
      if (follower) {
        assert.equal(getLevelStatus(course, progress, follower.id), "available");
      }
    }

    assert.equal(progress.passedLevelIds.length, 9);
    assert.equal(progress.xp, 135 * 10 + 9 * (15 * 4 + 30));
    assert.equal(getLevelExamSummary(progress, "money-l1").bestPercent, 100);
    assert.equal(getLevelExamSummary(progress, "money-l1").passed, true);
  });

  it("keeps economics progress isolated per profile and subject", async () => {
    const a = await addProfile("Ana");
    const b = await addProfile("Beto");
    const subA = await addSubject(a, "Economía", "1");
    const subB = await addSubject(b, "Economía", "1");
    const savedA = await saveCourse({
      profileId: a,
      subjectId: subA,
      definition: createEconomicsCourseDefinition(),
      source: "imported",
    });
    const savedB = await saveCourse({
      profileId: b,
      subjectId: subB,
      definition: createEconomicsCourseDefinition(),
      source: "imported",
    });
    assert.equal(savedA.course.definition.id, ECONOMICS_COURSE_ID);
    assert.deepEqual(savedA.progress.unlockedLevelIds, ["money-l1"]);

    const question = savedA.course.definition.levels[0].blocks[0].quiz.questions[0];
    const answered = answerQuiz(savedA.progress, question, question.correctOptionId).progress;
    answered.passedLevelIds = ["money-l1"];
    answered.unlockedLevelIds = ["money-l1", "money-l2"];
    await saveProgress(answered);

    const progressA = await getProgressByCourse(savedA.course.id);
    const coursesB = await getCoursesBySubject(b, subB);
    const progressB = await getProgressByCourse(savedB.course.id);
    assert.equal(progressA.xp, 10);
    assert.equal(progressB.xp, 0);
    assert.deepEqual(progressB.passedLevelIds, []);
  });
});

describe("Legacy Academia del Dinero progress import", () => {
  const legacyState = {
    xp: 420,
    parts: { "1-0": 1, "1-1": 1, "2-0": 1 },
    exams: {
      1: { best: 86, passed: true, bonus: true, source: "final" },
      2: { best: 50, passed: false, bonus: false, source: "final" },
    },
    ans: {},
    errHistory: {},
    conceptStats: {},
    hist: [],
  };

  it("is opt-in and reports the stored summary without touching progress", () => {
    const course = createEconomicsCourseDefinition();
    const progress = createInitialProgress(1, 2, 3, course);
    assert.equal(readLegacyMoneyState(), null);
    assert.equal(summarizeLegacyMoneyState(null).available, false);

    localStorage.setItem(LEGACY_MONEY_KEY, JSON.stringify(legacyState));
    const summary = summarizeLegacyMoneyState(readLegacyMoneyState());
    assert.equal(summary.available, true);
    assert.equal(summary.passedLevels, 1);
    assert.equal(summary.completedParts, 3);
    assert.equal(summary.xp, 420);
    assert.deepEqual(progress.passedLevelIds, []);
    assert.equal(progress.xp, 0);
  });

  it("maps old parts and exams into blocks, levels, XP and exam grades", () => {
    const course = createEconomicsCourseDefinition();
    const progress = createInitialProgress(1, 2, 3, course);
    const merged = mergeLegacyMoneyProgress(progress, course, legacyState);

    assert.deepEqual(merged.completedBlocks["money-l1"], ["add-l1-b1", "add-l1-b2"]);
    assert.deepEqual(merged.completedBlocks["money-l2"], ["add-l2-b1"]);
    assert.deepEqual(merged.passedLevelIds, ["money-l1"]);
    assert.ok(merged.unlockedLevelIds.includes("money-l2"));
    assert.equal(merged.xp, 420);
    assert.equal(merged.importedFrom, "academia-del-dinero");
    assert.ok(merged.importedAt);
    assert.equal(merged.lastSession.levelId, "money-l2");

    const l1 = getLevelExamSummary(merged, "money-l1");
    assert.equal(l1.attempts, 1);
    assert.equal(l1.passed, true);
    assert.equal(l1.bestPercent, 87);
    const l2 = getLevelExamSummary(merged, "money-l2");
    assert.equal(l2.attempts, 1);
    assert.equal(l2.passed, false);
    assert.equal(l2.bestPercent, 53);

    assert.equal(getLevelDisplayStatus(course, merged, "money-l1"), "passed");
    assert.equal(getLevelDisplayStatus(course, merged, "money-l2"), "in_progress");
    assert.equal(getLevelDisplayStatus(course, merged, "money-l3"), "locked");
  });

  it("never overwrites more advanced existing progress", () => {
    const course = createEconomicsCourseDefinition();
    const progress = createInitialProgress(1, 2, 3, course);
    progress.xp = 900;
    progress.passedLevelIds = ["money-l1", "money-l2", "money-l3"];
    progress.unlockedLevelIds = ["money-l1", "money-l2", "money-l3", "money-l4"];
    progress.completedBlocks["money-l1"] = ["add-l1-b1", "add-l1-b2", "add-l1-b3"];

    const merged = mergeLegacyMoneyProgress(progress, course, legacyState);
    assert.equal(merged.xp, 900);
    assert.deepEqual(merged.completedBlocks["money-l1"], ["add-l1-b1", "add-l1-b2", "add-l1-b3"]);
    assert.deepEqual(merged.passedLevelIds, ["money-l1", "money-l2", "money-l3"]);
    assert.ok(merged.unlockedLevelIds.includes("money-l4"));
  });

  it("ignores malformed or empty legacy data", () => {
    const course = createEconomicsCourseDefinition();
    const progress = createInitialProgress(1, 2, 3, course);
    assert.equal(mergeLegacyMoneyProgress(progress, course, null), progress);
    const merged = mergeLegacyMoneyProgress(progress, course, { parts: {}, exams: {}, xp: 0 });
    assert.deepEqual(merged.passedLevelIds, []);
    assert.equal(merged.xp, 0);
  });
});
