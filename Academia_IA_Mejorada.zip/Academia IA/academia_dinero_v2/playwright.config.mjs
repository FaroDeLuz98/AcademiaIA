export default {
  testDir: "tests",
  testMatch: "ui*.test.mjs",
  timeout: 60000,
  use: {
    baseURL: "http://127.0.0.1:8000",
    headless: true,
  },
  webServer: {
    command: "npx http-server . -p 8000 -c-1",
    port: 8000,
    reuseExistingServer: true,
  },
};
