// src/app.js
// Interfaz principal: dashboard, materia y sesión de estudio.

import {
  getActiveProfileId,
  getActiveSubjectId,
  setActiveSubjectId,
  getAllProfiles,
  getSubjectsByProfile,
  getMaterials,
} from "./storage.js";
import {
  getStudyBundle,
  getProfileStudyData,
  saveCourse,
  saveProgress,
} from "./courseStore.js";
import { createDemoCourseDefinition } from "./demoCourse.js";
import { createEconomicsCourseDefinition } from "./economicsCourse.js";
import {
  sortedLevels,
  sortedBlocks,
  getLevelStatus,
  getLevelDisplayStatus,
  getLevelExamSummary,
  getCourseProgressPercent,
  getLevelProgressPercent,
  currentAvailableLevel,
  getTheoryViewModel,
  answerQuiz,
  completeBlock,
  canStartExam,
  applyExamResult,
  getPendingAiReview,
  saveAiReviewConversation,
  completeAiReview,
  isAiReviewCheckpoint,
  recommendReviews,
  touchSession,
  profileStats,
  getLevelById,
  createSkipExam,
  applySkipExamResult,
  createSkipLessonExam,
  applySkipLessonResult,
  getPriorLevels,
  shuffleOptions,
} from "./courseEngine.js";
import { getWallet, syncWallet, buyHint, revealHint, hasUsedHint, hasPodcast, buyPodcast, HINT_PRICE, PODCAST_PRICE } from "./rewards.js";
import { getAiSessionConfig, getAiProviderName, shouldBalanceOptions, initAiSettings } from "./aiSettings.js";
import { lessonTranscript, playLessonAudio, stopLessonAudio, togglePauseLessonAudio, isAudioAvailable } from "./lessonAudio.js";
import {
  readLegacyMoneyState,
  summarizeLegacyMoneyState,
  mergeLegacyMoneyProgress,
} from "./moneyProgressImport.js";

const mainEl = document.getElementById("main");
const xpEl = document.getElementById("xp");
const pointsEl = document.getElementById("pointsShopBtn");
initAiSettings();
document.addEventListener("academia-ai-changed", () => { ui.failedBalancedQuestions.clear(); if (ui?.view === "study") renderStudy(); });

const ui = {
  view: "dashboard",
  subjectId: null,
  courseId: null,
  bundle: null,
  focusMode: true,
  levelId: null,
  phase: "theory",
  blockIndex: 0,
  questionIndex: 0,
  examAnswers: {},
  feedback: null,
  examPack: null,
  aiBusy: false,
  aiError: "",
  reviewUnlockedLevelId: null,
  optionOrders: new Map(),
  balancedOptions: new Map(),
  balancingQuestions: new Set(),
  failedBalancedQuestions: new Set(),
  audioStatus: "stopped",
  currentHintShown: false,
  showSummary: false,
  showQuizTheory: false,
  skipExamLevel: null,
  skipExamAnswers: {},
  skipExamQuestionIndex: 0,
  skipExamPack: null,
};

export async function renderMain() {
  await updateXPDisplay();
  const profileId = getActiveProfileId();
  if (!profileId) {
    ui.view = "welcome";
    mainEl.innerHTML = welcomeHTML();
    return;
  }
  if (ui.view === "study" && ui.bundle) {
    renderStudy();
    return;
  }
  if (ui.view === "subject" && (ui.subjectId || getActiveSubjectId())) {
    ui.subjectId = ui.subjectId || getActiveSubjectId();
    await renderSubjectDetail(ui.subjectId);
    return;
  }
  await renderDashboard();
}

async function updateXPDisplay() {
  const pid = getActiveProfileId();
  if (!pid) {
    xpEl.textContent = "⚡ 0 XP";
    if (pointsEl) pointsEl.textContent = "🪙 0 puntos · 💡 3 pistas";
    return;
  }
  const data = profileStats(await getProfileStudyData(pid));
  xpEl.textContent = "⚡ " + (data.xp || 0) + " XP";
  syncWallet(pid, data.xp);
  updateWalletBadge();
}

function updateWalletBadge() {
  const w = getWallet(getActiveProfileId());
  if (pointsEl) pointsEl.textContent = `🪙 ${w.balance} puntos · 💡 ${w.hints} pistas`;
}

function studyQuestionKey(q) {
  return `${ui.bundle?.course?.id || ui.courseId || 'curso'}:${q.id}`;
}

function lessonKey(block) {
  return `${ui.bundle?.course?.id || ui.courseId || 'curso'}:${block.id}`;
}

// Fisher–Yates y opciones estables para cada pregunta durante la sesión.
// Las respuestas se corrigen por ID, nunca por posición A/B/C/D.
function optionsFor(q) {
  const key = `${ui.courseId}:${ui.phase}:${q.id}`;
  if (!ui.optionOrders.has(key)) {
    let shuffled = shuffleOptions(q).options;
    const correctPos = shuffled.findIndex(o => o.id === q.correctOptionId);
    if (shuffled.length > 1 && ui.lastCorrectPos === correctPos) {
      shuffled = [...shuffled.slice(1), shuffled[0]];
    }
    ui.lastCorrectPos = shuffled.findIndex(o => o.id === q.correctOptionId);
    ui.optionOrders.set(key, shuffled);
  }
  initializeBalancedOptions(q);
  const options = ui.optionOrders.get(key);
  const balanced = ui.balancedOptions.get(`${ui.courseId}:${q.id}`);
  return shouldBalanceOptions() && balanced ? options.map(o => ({ ...o, text: balanced.get(o.id) || o.text })) : options;
}

function balanceKey(q) {
  // Cache invalidada automáticamente al editar el texto del curso.
  const source = [q.prompt, q.correctOptionId, ...q.options.map(o => o.id + ':' + o.text)].join('|');
  let hash = 2166136261;
  for (let i = 0; i < source.length; i++) hash = Math.imul(hash ^ source.charCodeAt(i), 16777619);
  return `academia-balanced-v2:${ui.courseId}:${q.id}:${(hash >>> 0).toString(16)}`;
}
function initializeBalancedOptions(q) {
  const key = `${ui.courseId}:${q.id}`;
  if (ui.balancedOptions.has(key)) return;
  try {
    const cached = JSON.parse(localStorage.getItem(balanceKey(q)) || 'null');
    if (Array.isArray(cached) && cached.length === q.options.length && cached.every(o => q.options.some(p => p.id === o.id) && typeof o.text === 'string' && o.text.length <= 500)) {
      ui.balancedOptions.set(key, new Map(cached.map(o => [o.id, o.text])));
    }
  } catch {}
}
async function balanceCurrentQuestion() {
  if (!shouldBalanceOptions() || !['quiz', 'exam', 'skip_exam'].includes(ui.phase)) return;
  const q = ui.phase === 'quiz' ? currentBlock()?.quiz?.questions?.[ui.questionIndex] : ui.phase === 'exam' ? currentLevel()?.exam?.questions?.[ui.questionIndex] : ui.skipExam?.questions?.[ui.questionIndex];
  if (!q || (ui.phase === 'quiz' && ui.feedback) || ui.examAnswers[q.id]) return;
  const key = `${ui.courseId}:${q.id}`;
  initializeBalancedOptions(q);
  if (ui.balancedOptions.has(key) || ui.balancingQuestions.has(key) || ui.failedBalancedQuestions.has(key)) return;
  const lengths = q.options.map(o => o.text.trim().length);
  if (Math.max(...lengths) - Math.min(...lengths) <= Math.max(8, Math.ceil(lengths.find((_, i) => q.options[i].id === q.correctOptionId) * 0.15))) return;
  ui.balancingQuestions.add(key);
  try {
    const response = await fetch('/api/ai-balance', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ai: getAiSessionConfig(), question: q }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'No se pudieron ajustar las opciones.');
    if (Array.isArray(result.options)) {
      ui.balancedOptions.set(key, new Map(result.options.map(o => [o.id, o.text])));
      try { localStorage.setItem(balanceKey(q), JSON.stringify(result.options)); } catch {}
      const active = ui.phase === 'quiz' ? currentBlock()?.quiz?.questions?.[ui.questionIndex] : ui.phase === 'exam' ? currentLevel()?.exam?.questions?.[ui.questionIndex] : ui.skipExam?.questions?.[ui.questionIndex];
      if (active?.id === q.id && !ui.feedback && !ui.examAnswers[q.id]) renderStudy();
    }
  } catch (e) { ui.failedBalancedQuestions.add(key); console.info('Opciones originales conservadas:', e.message); }
  finally { ui.balancingQuestions.delete(key); }
}

function hintTextFor(q) {
  const raw = String(q.hint || '').trim();
  const concept = q.relatedConcept || q.concept || 'el tema de la lección';
  if (raw && !/^Pensá en el concepto:/i.test(raw)) return raw;
  const question = String(q.prompt || '').toLowerCase();
  if (/verdadero o falso|correcta o incorrecta/i.test(question))
    return `Revisá si la afirmación siempre se cumple o si existe una excepción. Tema para recordar: ${concept}.`;
  if (/ejemplo|caso|situaci[oó]n|pag[aá]s|compra|venta/i.test(question))
    return `Identificá qué está pasando en la situación y relacioná ese hecho con ${concept}; no te guíes solo por una palabra.`;
  if (/no es|incorrecta|excepto|falsa/i.test(question))
    return `Buscá la alternativa que contradiga la definición de ${concept}, en vez de elegir la más familiar.`;
  return `Recordá la definición de ${concept} y descartá las opciones que no la cumplen. Buscá la idea, no la letra.`;
}

function hintControlsHTML(q) {
  const wallet = getWallet(getActiveProfileId());
  const shown = hasUsedHint(getActiveProfileId(), studyQuestionKey(q));
  return `
    <span class="hint-status" title="Las tres pistas gratuitas son para todo tu perfil">💡 ${wallet.hints} pistas disponibles en total</span>
    ${!shown && wallet.hints ? `<button class="secondary hint-btn" id="showHintBtn">Usar pista (${wallet.hints} restantes)</button>` : ''}
    ${!shown && !wallet.hints ? `<button class="secondary hint-btn" id="buyHintBtn">🪙 Comprar pista · ${HINT_PRICE} puntos</button>` : ''}
    ${shown ? `<div class="hint-box">💡 <strong>Pista:</strong> ${escapeHtml(hintTextFor(q))}</div>` : ''}
  `;
}

function teachingExplanationHTML(result, example = null) {
  const selected = result.selectedText;
  const correctAnswer = result.correctText;
  const explain = result.explanation || 'Revisá esta idea en la teoría de la lección.';
  const concept = result.relatedConcept || 'Tema de la pregunta';
  return `
    <div class="reasoning-steps">
      <h3>Entendé la respuesta</h3>
      ${!result.correct && selected ? `<p class="answer-selected">Tu elección: <strong>${escapeHtml(selected)}</strong></p>` : ''}
      <div class="reasoning-step"><span class="step-number">1</span><div><strong>La idea que se evalúa</strong><p>${escapeHtml(concept)}</p></div></div>
      <div class="reasoning-step"><span class="step-number">2</span><div><strong>Por qué</strong><p>${escapeHtml(explain)}</p></div></div>
      <div class="reasoning-step"><span class="step-number">3</span><div><strong>Respuesta y conclusión</strong><p>${escapeHtml(correctAnswer)}</p></div></div>
      ${example?.body ? `<div class="recall-example"><strong>Ejemplo de la lección: ${escapeHtml(example.title || 'Aplicación')}</strong><p>${escapeHtml(example.body)}</p></div>` : ''}
      ${!result.correct ? `<p class="study-tip">Para el próximo intento, repasá este concepto y explicá con tus palabras por qué esta respuesta encaja.</p>` : ''}
    </div>`;
}

function reviewExplanationHTML(d) {
  return `<div class="review-explain"><strong>Respuesta correcta: ${escapeHtml(d.correctText)}</strong><p><strong>Por qué:</strong> ${escapeHtml(d.explanation || 'Revisá este concepto en la teoría.')}</p><p class="muted">Concepto para repasar: ${escapeHtml(d.relatedConcept || 'General')}</p></div>`;
}

function showStoreModal(message = '') {
  const pid = getActiveProfileId();
  if (!pid) { alert('Creá un perfil para utilizar la tienda de puntos.'); return; }
  let overlay = document.getElementById('rewardShopOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'rewardShopOverlay';
    overlay.className = 'shop-overlay';
    document.body.appendChild(overlay);
  }
  const wallet = getWallet(pid);
  overlay.innerHTML = `
    <section class="shop-panel" role="dialog" aria-modal="true" aria-label="Tienda de puntos">
      <button class="secondary shop-close" id="closeRewardShop" aria-label="Cerrar tienda">✕ Cerrar</button>
      <p class="muted">RECOMPENSAS DE ESTUDIO</p><h2>🪙 Tienda de puntos</h2>
      <div class="shop-balance"><strong>${wallet.balance}</strong> puntos disponibles <span>· 💡 ${wallet.hints} pistas</span></div>
      <p class="muted">Ganás 1 punto por cada XP nuevo. Gastar puntos no reduce tus XP ni tu progreso. No se obtienen puntos extra repitiendo las mismas preguntas.</p>
      <div class="shop-product"><div><strong>💡 Una pista adicional</strong><p>Arrancás con solo 3 pistas gratuitas para todo el perfil. Cada pista extra se compra por separado.</p></div><button class="primary" id="shopBuyHint">${HINT_PRICE} puntos</button></div>
      <div class="shop-product"><div><strong>🎧 Audio de cada lección</strong><p>Cuesta ${PODCAST_PRICE} puntos por lección. Al comprarla, aparece el botón «Leer / Escuchar» en esa lección para siempre. Utiliza la voz de tu dispositivo.</p></div></div>
      ${message ? `<p class="shop-message" role="status">${escapeHtml(message)}</p>` : ''}
    </section>`;
  overlay.style.display = 'grid';
  overlay.querySelector('#closeRewardShop').onclick = () => { overlay.style.display = 'none'; };
  overlay.onclick = e => { if (e.target === overlay) overlay.style.display = 'none'; };
  overlay.querySelector('#shopBuyHint').onclick = () => {
    const out = buyHint(pid);
    updateWalletBadge();
    showStoreModal(out.ok ? 'Compraste una pista adicional.' : `No tenés puntos suficientes: necesitás ${HINT_PRICE - out.wallet.balance} más.`);
    if (ui.view === 'study') renderStudy();
  };
}

pointsEl?.addEventListener('click', () => showStoreModal());

function welcomeHTML() {
  return `
    <div class="welcome-icon">🎓</div>
    <h1>¡Bienvenido a Academia IA!</h1>
    <p>Tu plataforma educativa personalizada. Creá un perfil para comenzar.</p>
    <div class="feature-grid">
      <div class="feature-card"><div class="icon">👤</div><h4>Perfiles</h4><p>Estudiantes separados, progreso separado.</p></div>
      <div class="feature-card"><div class="icon">📚</div><h4>Materias</h4><p>Cada materia tiene su propio camino de niveles.</p></div>
      <div class="feature-card"><div class="icon">🧠</div><h4>Estudio</h4><p>Teoría, quizzes guiados y exámenes finales.</p></div>
      <div class="feature-card"><div class="icon">🏆</div><h4>Progreso</h4><p>XP, desbloqueo y continuidad entre sesiones.</p></div>
    </div>`;
}

async function renderDashboard() {
  ui.view = "dashboard";
  const profileId = getActiveProfileId();
  const profiles = await getAllProfiles();
  const profile = profiles.find((p) => p.id === profileId);
  const subjects = await getSubjectsByProfile(profileId);
  const studyData = await getProfileStudyData(profileId);
  const stats = profileStats(studyData);
  let totalMaterials = 0;
  const subjectCards = [];
  for (const s of subjects) {
    const mats = await getMaterials(profileId, s.id);
    totalMaterials += mats.length;
    const bundles = studyData.filter((b) => b.progress?.subjectId === s.id);
    const percent = bundles.reduce(
      (best, b) => Math.max(best, getCourseProgressPercent(b.course, b.progress)),
      0
    );
    subjectCards.push({ s, mats: mats.length, percent });
  }
  const continueTarget = stats.lastSession;

  mainEl.innerHTML = `
    <div class="muted">PERFIL ACTIVO</div>
    <h1>Hola, ${escapeHtml(profile?.name || "estudiante")}</h1>
    <p class="muted">Elegí una materia o continuá donde dejaste.</p>
    <div class="stats">
      <div class="stat"><strong>${stats.xp}</strong><span class="label">XP acumulados</span></div>
      <div class="stat"><strong>${getWallet(profileId).balance}</strong><span class="label">Puntos para gastar</span></div>
      <div class="stat"><strong>${getWallet(profileId).hints}</strong><span class="label">Pistas disponibles</span></div>
      <div class="stat"><strong>${stats.passedLevels}</strong><span class="label">Niveles aprobados</span></div>
      <div class="stat"><strong>${stats.percent}%</strong><span class="label">Progreso</span></div>
      <div class="stat"><strong>${totalMaterials}</strong><span class="label">Materiales</span></div>
    </div>
    ${continueTarget ? `<button class="primary" id="continueStudyBtn">Continuar estudiando</button>` : ""}
    ${subjects.length === 0 ? `
      <div class="empty-note">
        <p>📚 No tenés materias todavía.</p>
        <p class="muted">Usá <strong>+ Crear materia</strong> en la barra lateral.</p>
      </div>` : `
      <h2>Tus materias</h2>
      <div class="feature-grid">
        ${subjectCards.map(({ s, mats, percent }) => `
          <button type="button" class="feature-card subject-card" data-open-subject="${s.id}">
            <h4>📘 ${escapeHtml(s.name)}</h4>
            <p>${s.level ? escapeHtml(s.level) : "Camino de aprendizaje"}</p>
            <div class="progress" aria-hidden="true"><div style="width:${percent}%"></div></div>
            <p class="muted">${percent}% · ${mats} material(es)</p>
          </button>`).join("")}
      </div>`}
  `;
  mainEl.querySelector("#continueStudyBtn")?.addEventListener("click", () => {
    openSubject(continueTarget.subjectId, { resume: true });
  });
  mainEl.querySelectorAll("[data-open-subject]").forEach((btn) => {
    btn.addEventListener("click", () => openSubject(Number(btn.dataset.openSubject)));
  });
}

export async function openSubject(subjectId, options = {}) {
  stopLessonAudio();
  ui.subjectId = subjectId;
  setActiveSubjectId(subjectId);
  window._currentSubjectId = subjectId;
  if (window.refreshMaterials) window.refreshMaterials(subjectId);
  if (window.renderSubjects) window.renderSubjects();
  document.body.classList.remove("focus-mode");
  if (options.resume) {
    const profileId = getActiveProfileId();
    const bundles = await getStudyBundle(profileId, subjectId);
    const bundle = pickBundle(bundles, options.courseId);
    if (bundle?.progress?.lastSession?.levelId) {
      ui.courseId = bundle.courseRecord.id;
      ui.bundle = bundle;
      ui.levelId = bundle.progress.lastSession.levelId;
      ui.phase = bundle.progress.lastSession.phase || "theory";
      ui.blockIndex = bundle.progress.lastSession.blockIndex || 0;
      ui.questionIndex = bundle.progress.lastSession.questionIndex || 0;
      ui.examAnswers = bundle.progress.lastSession.examAnswers || {};
      ui.feedback = null;
      ui.examPack = null;
      if (ui.phase === 'results' || ui.phase === 'ai_complete') ui.phase = 'theory';
      if (ui.phase === "ai_review" && !getPendingAiReview(bundle.progress, ui.levelId)) ui.phase = "theory";
      if (bundle.progress.lastSession.view === "study") {
        ui.view = "study";
        await renderMain();
        if (ui.phase === 'ai_review') beginReviewConversation();
        return;
      }
    }
  }
  ui.view = "subject";
  await renderSubjectDetail(subjectId, options.courseId);
}

function pickBundle(bundles, courseId) {
  if (!bundles || !bundles.length) return null;
  if (courseId != null) {
    const found = bundles.find((b) => b.courseRecord.id === courseId);
    if (found) return found;
  }
  const recency = (b) => {
    const at = b.progress?.lastSession?.at;
    return at ? new Date(at).getTime() : 0;
  };
  return [...bundles].sort((a, b) => recency(b) - recency(a))[0];
}

const COURSE_CATALOG = [
  {
    key: "economics",
    title: "Academia del Dinero",
    description: "Curso completo de 9 niveles con teoría, quizzes guiados y examen final. Contenido original de Academia del Dinero.",
    levelCount: 9,
    source: "imported",
    signature: "academia-del-dinero",
    create: createEconomicsCourseDefinition,
  },
  {
    key: "demo",
    title: "Técnicas de estudio, comprensión y exámenes",
    description: "Curso de demostración con 3 niveles para probar el motor educativo completo.",
    levelCount: 3,
    source: "demo",
    signature: "demo-study-skills",
    create: createDemoCourseDefinition,
  },
];

function courseSignatureOf(definition) {
  return definition?.id || definition?.title || "";
}

function examScoreLabel(summary) {
  if (!summary.attempts) return "Examen: sin rendir";
  return `Examen: ${summary.bestPercent}%${summary.passed ? " ✓" : ""}`;
}

async function renderSubjectDetail(subjectId, courseId) {
  const profileId = getActiveProfileId();
  const subjects = await getSubjectsByProfile(profileId);
  const subject = subjects.find((s) => s.id === subjectId);
  if (!subject) {
    ui.view = "dashboard";
    await renderDashboard();
    return;
  }
  const materials = await getMaterials(profileId, subjectId);
  const bundles = await getStudyBundle(profileId, subjectId);
  const bundle = pickBundle(bundles, courseId ?? ui.courseId);
  ui.courseId = bundle?.courseRecord?.id ?? null;
  ui.bundle = bundle;
  const course = bundle?.course;
  const progress = bundle?.progress;
  const levels = course ? sortedLevels(course) : [];
  const percent = course ? getCourseProgressPercent(course, progress) : 0;
  const current = course ? currentAvailableLevel(course, progress) : null;
  const recs = progress ? recommendReviews(progress, course) : [];
  const isEconomicsSubject = /econom/i.test(subject.name);
  const importedSignatures = new Set(bundles.map((b) => courseSignatureOf(b.course)));
  const availableCatalog = COURSE_CATALOG.filter((entry) => !importedSignatures.has(entry.signature));
  const legacySummary = summarizeLegacyMoneyState(readLegacyMoneyState());
  const showLegacyImport =
    courseSignatureOf(course) === "academia-del-dinero" &&
    legacySummary.available &&
    legacySummary.hasData &&
    !progress?.importedAt;

  const courseSwitcher = bundles.length > 1
    ? `<div class="course-tabs">
        <span class="muted">Curso:</span>
        ${bundles.map((b) => `
          <button type="button" class="nav-chip ${b.courseRecord.id === ui.courseId ? "active" : ""}" data-select-course="${b.courseRecord.id}">
            ${escapeHtml(b.course.title)}
          </button>`).join("")}
      </div>`
    : "";

  const catalogHTML = availableCatalog.length
    ? `<div class="course-catalog">
        <h3>${course ? "Importar otro curso a esta materia" : "Cursos disponibles para importar"}</h3>
        <p class="muted">Cada curso se agrega solo a esta materia y este perfil. No se aplica automáticamente a otros perfiles.</p>
        <div class="feature-grid">
          ${availableCatalog.map((entry) => `
            <div class="feature-card course-catalog-card">
              <h4>${escapeHtml(entry.title)}</h4>
              <p>${escapeHtml(entry.description)}</p>
              <p class="muted">${entry.levelCount} niveles${entry.key === "economics" && isEconomicsSubject ? " · Recomendado para Economía" : ""}</p>
              <button type="button" class="primary" data-start-course="${entry.key}">Importar curso</button>
            </div>`).join("")}
        </div>
      </div>`
    : "";

  const legacyHTML = showLegacyImport
    ? `<div class="legacy-import">
        <h3>Progreso anterior de Academia del Dinero</h3>
        <p>Encontramos datos guardados por la aplicación original en este navegador. Podés importarlos a este curso cuando quieras.</p>
        <p class="muted">Niveles aprobados: ${legacySummary.passedLevels} · Bloques completados: ${legacySummary.completedParts} · XP: ${legacySummary.xp}. No se importa nada hasta que lo confirmes.</p>
        <button type="button" class="secondary" id="importLegacyProgressBtn">Importar progreso anterior</button>
      </div>`
    : "";

  mainEl.innerHTML = `
    <button class="secondary" id="backToDashboard">← Volver al panel</button>
    <h1>📘 ${escapeHtml(subject.name)}</h1>
    <p class="muted">${subject.level ? escapeHtml(subject.level) + " · " : ""}${materials.length} material(es)</p>
    ${course ? `
    <div class="stats">
      <div class="stat"><strong>${percent}%</strong><span class="label">Avance del curso</span></div>
      <div class="stat"><strong>${progress?.xp || 0}</strong><span class="label">XP en esta materia</span></div>
      <div class="stat"><strong>${(progress?.passedLevelIds || []).length}/${levels.length}</strong><span class="label">Niveles aprobados</span></div>
    </div>` : ""}
    ${courseSwitcher}
    ${course ? `
      <div class="path-head">
        <h2>Camino de niveles</h2>
        <div class="path-actions">
          <button class="primary" id="continueLevelBtn">${(progress.passedLevelIds || []).length >= levels.length ? "Curso aprobado" : ((progress.passedLevelIds || []).length || (progress.examAttempts || []).length ? "Continuar" : "Comenzar")}</button>
        </div>
      </div>
      <ol class="level-path">
        ${levels.map((level, i) => {
          const status = getLevelDisplayStatus(course, progress, level.id);
          const lp = getLevelProgressPercent(level, progress);
          const exam = getLevelExamSummary(progress, level.id);
          const currentMark = current && current.id === level.id && status !== "passed";
          const isLocked = status === "locked";
          const pendingReview = getPendingAiReview(progress, level.id);
          const blocks = sortedBlocks(level);
          const isLvlDone = status === "passed";

          const lessonsHtml = `
            <div class="level-lessons">
              ${blocks.map((b, bIdx) => {
                const bDone = isDone(progress, level.id, b.id);
                const bCanOpen = !isLocked && canJumpBlock(progress, level, bIdx);
                const bTitle = b.theory?.title || b.title || `Lección ${bIdx + 1}`;
                return `
                  <div class="lesson-chip-row ${bDone ? 'is-done' : bCanOpen ? 'is-open' : 'is-locked'}">
                    <span class="lesson-name">
                      ${bDone ? '✓' : bCanOpen ? '○' : '🔒'} <strong>${bIdx + 1}.</strong> ${escapeHtml(bTitle)}
                    </span>
                    <div class="lesson-actions">
                      ${bCanOpen ? `
                        <button type="button" class="secondary mini" data-open-block="${level.id}:${bIdx}">
                          ${bDone ? 'Repasar' : 'Estudiar'}
                        </button>
                      ` : `
                        <button type="button" class="secondary skip-btn mini" data-skip-lesson="${level.id}:${bIdx}" title="Rendir examen previo para saltear hasta esta lección">
                          ⚡ Saltear lección
                        </button>
                      `}
                    </div>
                  </div>
                `;
              }).join("")}
              ${!canStartExam(level, progress) && !isLvlDone ? `
                <div class="lesson-chip-row exam-row">
                  <span class="lesson-name">🔒 <strong>Examen Final</strong> de ${escapeHtml(level.title)}</span>
                  <button type="button" class="secondary skip-btn mini" data-skip-lesson="${level.id}:${blocks.length}" title="Rendir examen integrador para saltear lecciones e ir directo al examen">
                    ⚡ Saltear lecciones al Examen
                  </button>
                </div>
              ` : ''}
            </div>
          `;

          return `<li class="level-node ${status} ${currentMark ? "current" : ""}">
            <button type="button" data-open-level="${level.id}" ${isLocked ? "disabled" : ""}>
              <span class="lvl-index">${status === "passed" ? "✓" : i + 1}</span>
              <span class="lvl-body">
                <strong>${escapeHtml(level.title)}</strong>
                <small>${pendingReview ? '🧠 Repaso con IA pendiente' : `${labelStatus(status)} · ${lp}% · ${examScoreLabel(exam)}`}</small>
                <span class="mini-progress"><span style="width:${lp}%"></span></span>
              </span>
              <span class="lvl-cta">${status === "locked" ? "Bloqueado" : pendingReview ? "Charlar con la IA" : status === "passed" ? "Repasar" : status === "in_progress" ? "Continuar" : "Comenzar"}</span>
            </button>
            ${isLocked ? `<button type="button" class="secondary skip-btn level-skip" data-skip-level="${level.id}">⚡ Saltear nivel completo (Examen previo)</button>` : ""}
            ${lessonsHtml}
          </li>`;
        }).join("")}
      </ol>
      <h3>Recomendaciones</h3>
      <ul class="recs">${recs.map((r) => `<li><strong>${escapeHtml(r.title)}</strong> — ${escapeHtml(r.detail)}</li>`).join("")}</ul>
      ${legacyHTML}
    ` : `
      <div class="study-cta">
        <h2>Elegí un curso para esta materia</h2>
        <p>Academia IA usa un mismo motor para todos los cursos. Podés importar Academia del Dinero, probar el curso demo o, más adelante, generar niveles con Gemini a partir de tus documentos.</p>
      </div>
    `}
    ${catalogHTML}
    <h2>📎 Materiales</h2>
    ${materials.length === 0 ? `<p class="muted">Subí PDFs, DOCX o TXT desde la barra lateral. Más adelante Gemini podrá armar un curso a partir de ellos.</p>` : `
      <div class="feature-grid">
        ${materials.map((m) => `
          <button type="button" class="feature-card" data-mat-id="${m.id}">
            <h4>${escapeHtml(m.name)}</h4>
            <p class="muted">${m.createdAt ? new Date(m.createdAt).toLocaleDateString() : ""}</p>
          </button>`).join("")}
      </div>`}
  `;

  document.getElementById("backToDashboard").onclick = () => {
    document.body.classList.remove("focus-mode");
    ui.view = "dashboard";
    renderMain();
  };
  document.getElementById("continueLevelBtn")?.addEventListener("click", () => {
    const target = currentAvailableLevel(course, progress);
    if (target) openLevel(target.id);
  });
  mainEl.querySelectorAll("[data-select-course]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = Number(btn.dataset.selectCourse);
      ui.courseId = id;
      renderSubjectDetail(subjectId, id);
    });
  });
  mainEl.querySelectorAll("[data-start-course]").forEach((btn) => {
    btn.addEventListener("click", () => startCourseByKey(btn.dataset.startCourse));
  });
  document.getElementById("importLegacyProgressBtn")?.addEventListener("click", importLegacyProgress);
  mainEl.querySelectorAll("[data-open-level]").forEach((btn) => {
    btn.addEventListener("click", () => openLevel(btn.dataset.openLevel));
  });
  mainEl.querySelectorAll("[data-skip-level]").forEach((btn) => {
    btn.addEventListener("click", () => startSkipExam(btn.dataset.skipLevel));
  });
  mainEl.querySelectorAll("[data-open-block]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const parts = btn.dataset.openBlock.split(":");
      const lvlId = parts[0];
      const bIdx = Number(parts[1]);
      openLevel(lvlId);
      ui.blockIndex = bIdx;
      ui.phase = "theory";
      ui.questionIndex = 0;
      renderStudy();
    });
  });
  mainEl.querySelectorAll("[data-skip-lesson]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const parts = btn.dataset.skipLesson.split(":");
      const lvlId = parts[0];
      const bIdx = Number(parts[1]);
      startSkipLessonExam(lvlId, bIdx);
    });
  });
  mainEl.querySelectorAll("[data-mat-id]").forEach((card) => {
    card.onclick = () => {
      const mat = materials.find((m) => m.id === Number(card.dataset.matId));
      if (mat) showMaterialPreview(mat);
    };
  });
}

async function startCourseByKey(key) {
  const entry = COURSE_CATALOG.find((c) => c.key === key);
  const profileId = getActiveProfileId();
  const subjectId = ui.subjectId;
  if (!entry || !profileId || !subjectId) return;
  const existing = await getStudyBundle(profileId, subjectId);
  const already = existing.find((b) => courseSignatureOf(b.course) === entry.signature);
  if (already) {
    ui.courseId = already.courseRecord.id;
    await renderSubjectDetail(subjectId, ui.courseId);
    return;
  }
  const saved = await saveCourse({
    profileId,
    subjectId,
    definition: entry.create(),
    source: entry.source,
  });
  ui.courseId = saved.course.id;
  await renderSubjectDetail(subjectId, ui.courseId);
  await updateXPDisplay();
}

async function importLegacyProgress() {
  const profileId = getActiveProfileId();
  const subjectId = ui.subjectId;
  if (!ui.bundle || !profileId || !subjectId) return;
  const legacy = readLegacyMoneyState();
  const summary = summarizeLegacyMoneyState(legacy);
  if (!summary.available || !summary.hasData) {
    window.alert("No encontramos un progreso anterior de Academia del Dinero en este navegador.");
    return;
  }
  const ok = window.confirm(
    `Se importará el progreso guardado de Academia del Dinero a este curso.\n\n` +
      `Niveles aprobados: ${summary.passedLevels}\n` +
      `Bloques completados: ${summary.completedParts}\n` +
      `XP: ${summary.xp}\n\n` +
      "El progreso comprobado se conserva y no se modifica ningún otro curso ni perfil. ¿Continuar?"
  );
  if (!ok) return;
  const merged = mergeLegacyMoneyProgress(ui.bundle.progress, ui.bundle.course, legacy);
  await persist(merged);
  await renderSubjectDetail(subjectId, ui.courseId);
}

async function persist(progress) {
  const id = await saveProgress(progress);
  progress.id = id;
  ui.bundle.progress = progress;
  await updateXPDisplay();
}

async function openLevel(levelId) {
  const { course, progress } = ui.bundle;
  if (getLevelStatus(course, progress, levelId) === "locked") return;
  const level = getLevelById(course, levelId);
  stopLessonAudio();
  ui.levelId = levelId;
  ui.view = "study";
  ui.phase = getPendingAiReview(progress, levelId) ? "ai_review" : "theory";
  ui.aiBusy = false;
  ui.aiError = "";
  ui.reviewUnlockedLevelId = null;
  ui.blockIndex = 0;
  ui.questionIndex = 0;
  ui.examAnswers = {};
  ui.feedback = null;
  ui.examPack = null;
  ui.optionOrders = new Map();
  ui.lastCorrectPos = -1;
  const blocks = sortedBlocks(level);
  const firstOpen = blocks.findIndex((b) => !((progress.completedBlocks || {})[levelId] || []).includes(b.id));
  ui.blockIndex = firstOpen >= 0 ? firstOpen : 0;
  await persist(touchSession(progress, { view: "study", levelId, phase: ui.phase, blockIndex: ui.blockIndex, questionIndex: 0 }));
  renderStudy();
  if (ui.phase === "ai_review") beginReviewConversation();
}

function renderStudy() {
  const { course, progress } = ui.bundle;
  const level = getLevelById(course, ui.levelId);
  if (!level) return;
  document.body.classList.toggle("focus-mode", ui.focusMode);

  if (ui.phase === "skip_exam" || ui.phase === "skip_results") {
    mainEl.innerHTML = `
      <div class="study-top">
        <button class="secondary" id="backToSubject">← Camino</button>
        <div class="study-title">
          <div class="muted">${escapeHtml(course.title)}</div>
          <h1>⚡ Salto de nivel: ${escapeHtml(level.title)}</h1>
        </div>
        <button class="secondary" id="toggleFocus">${ui.focusMode ? "Mostrar paneles" : "Ocultar paneles"}</button>
      </div>
      ${ui.phase === "skip_exam" ? skipExamHTML() : skipResultsHTML()}
    `;
    document.getElementById("backToSubject").onclick = async () => {
    stopLessonAudio();
      ui.view = "subject";
      document.body.classList.remove("focus-mode");
      await persist(touchSession(ui.bundle.progress, { view: "path" }));
      await renderSubjectDetail(ui.subjectId, ui.courseId);
    };
    document.getElementById("toggleFocus")?.addEventListener("click", () => {
      ui.focusMode = !ui.focusMode;
      document.body.classList.toggle("focus-mode", ui.focusMode);
      const btn = document.getElementById("toggleFocus");
      if (btn) btn.textContent = ui.focusMode ? "Mostrar paneles" : "Ocultar paneles";
    });
    bindStudyActions();
    void balanceCurrentQuestion();
    return;
  }

  const blocks = sortedBlocks(level);
  const block = blocks[ui.blockIndex];

  let body = "";
  if (ui.phase === "theory") body = theoryHTML(course, block);
  else if (ui.phase === "quiz") body = quizHTML(block);
  else if (ui.phase === "exam") body = examHTML(level);
  else if (ui.phase === "results") body = resultsHTML();
  else if (ui.phase === "ai_review") body = aiReviewHTML();
  else if (ui.phase === "ai_complete") body = aiCompleteHTML();

  mainEl.innerHTML = `
    <div class="study-top">
      <button class="secondary" id="backToSubject">← Camino</button>
      <div class="study-title">
        <div class="muted">${escapeHtml(course.title)}</div>
        <h1>${escapeHtml(level.title)}</h1>
      </div>
      <button class="secondary" id="toggleFocus">${ui.focusMode ? "Mostrar paneles" : "Ocultar paneles"}</button>
    </div>
    <nav class="study-nav">
      ${blocks.map((b, i) => {
        const examLocked = ui.phase === "exam";
        const canJump = canJumpBlock(progress, level, i);
        const done = isDone(progress, level.id, b.id);
        const active = ui.blockIndex === i && (ui.phase === "theory" || ui.phase === "quiz");
        return `
          <button class="nav-chip ${active ? "active" : ""} ${done ? "done" : ""}" 
                  ${examLocked ? "disabled" : canJump ? `data-jump-block="${i}"` : `data-study-skip-block="${i}"`} 
                  title="${canJump ? 'Ir a esta lección' : 'Rendir examen previo para saltear a esta lección'}">
            ${done ? "✓ " : !canJump ? "⚡ " : ""}${i + 1}. ${escapeHtml(b.theory?.title || b.title || "Bloque")}${!canJump ? " (Saltear)" : ""}
          </button>`;
      }).join("")}
      ${canStartExam(level, progress) ? `
        <button class="nav-chip ${["exam", "results", "ai_review", "ai_complete"].includes(ui.phase) ? "active" : ""}" id="jumpExam" ${ui.phase === "exam" ? "disabled" : ""}>
          Examen final
        </button>
      ` : `
        <button class="nav-chip ${["exam", "results", "ai_review", "ai_complete"].includes(ui.phase) ? "active" : ""}" id="jumpExamSkip" data-study-skip-exam="true" title="Rendir examen integrador para saltear lecciones e ir directo al examen final">
          ⚡ Saltear lecciones al Examen
        </button>
      `}
    </nav>
    ${body}
  `;

  // No se reinicia el examen mientras hay una evaluación oral pendiente.
  document.getElementById("jumpExam")?.toggleAttribute("disabled", Boolean(getPendingAiReview(progress, level.id)));
  document.getElementById("backToSubject").onclick = async () => {
    stopLessonAudio();
    ui.view = "subject";
    document.body.classList.remove("focus-mode");
    await persist(touchSession(ui.bundle.progress, { view: "path" }));
    await renderSubjectDetail(ui.subjectId, ui.courseId);
  };
  document.getElementById("toggleFocus")?.addEventListener("click", () => {
    ui.focusMode = !ui.focusMode;
    document.body.classList.toggle("focus-mode", ui.focusMode);
    const btn = document.getElementById("toggleFocus");
    if (btn) btn.textContent = ui.focusMode ? "Mostrar paneles" : "Ocultar paneles";
  });
  mainEl.querySelectorAll("[data-jump-block]").forEach((btn) => {
    btn.onclick = () => {
      stopLessonAudio();
      ui.blockIndex = Number(btn.dataset.jumpBlock);
      ui.phase = "theory";
      ui.feedback = null;
      ui.questionIndex = 0;
      renderStudy();
    };
  });
  document.getElementById("jumpExam")?.addEventListener("click", () => {
    ui.phase = "exam";
    ui.questionIndex = 0;
    ui.examAnswers = {};
    ui.examPack = null;
    renderStudy();
  });
  bindStudyActions();
  void balanceCurrentQuestion();
}

function sanitizeTheoryHtml(html) {
  return String(html)
    .replace(/<\s*(script|iframe|object|embed|link|meta)\b[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/<\s*(script|iframe|object|embed|link|meta)\b[^>]*\/?\s*>/gi, "")
    .replace(/\son\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/\s(href|src)\s*=\s*(?:"\s*javascript:[^"]*"|'\s*javascript:[^']*')/gi, "");
}

function theoryHTML(course, block) {
  const vm = getTheoryViewModel(block, course.methodology);
  const unlocked = hasPodcast(getActiveProfileId(), lessonKey(block));
  return `
    <article class="theory">
      <h2>${escapeHtml(vm.title)}</h2>
      <section class="podcast-card" aria-label="Podcast de la lección">
        <div class="podcast-heading"><span class="podcast-icon">🎧</span><div><strong>Escuchá esta lección</strong><p>Audio narrado con la voz de tu dispositivo, disponible después de comprarlo con puntos.</p></div></div>
        ${unlocked ? `<div class="podcast-actions"><button class="primary" id="readLessonBtn">▶ Leer / Escuchar</button><button class="secondary" id="pauseLessonBtn" disabled>Pausar</button><button class="secondary" id="stopLessonBtn" disabled>Detener</button></div><p class="muted podcast-state" id="podcastState">Audio desbloqueado para siempre en esta lección.</p>`
          : `<div class="podcast-actions"><button class="primary" id="buyPodcastBtn">🪙 Desbloquear audio · ${PODCAST_PRICE} puntos</button><span class="muted">Compra única por lección</span></div>`}
      </section>
      ${vm.paragraphs.map((p) => (/<[a-z][\s\S]*>/i.test(String(p)) ? `<div class="theory-html">${sanitizeTheoryHtml(p)}</div>` : `<p>${escapeHtml(p)}</p>`)).join("")}
      ${vm.examples.map((ex) => `<div class="callout"><strong>${escapeHtml(ex.title)}</strong><p>${escapeHtml(ex.body)}</p></div>`).join("")}
      ${vm.cases.map((c) => `<div class="callout case"><strong>${escapeHtml(c.title)}</strong><p>${escapeHtml(c.body)}</p></div>`).join("")}
      ${vm.formulas.map((f) => `<div class="formula"><strong>${escapeHtml(f.name)}</strong><pre>${escapeHtml(f.expression)}</pre><p class="muted">${escapeHtml(f.note || "")}</p></div>`).join("")}
      ${vm.procedure.length ? `<ol class="procedure">${vm.procedure.map((s) => `<li><strong>${escapeHtml(s.step)}</strong> ${escapeHtml(s.detail)}</li>`).join("")}</ol>` : ""}
      ${vm.code ? `<pre class="code-block">${escapeHtml(vm.code.source)}</pre>
        <ul class="walkthrough">${vm.code.walkthrough.map((w) => `<li><code>L${w.line}</code> ${escapeHtml(w.comment)}</li>`).join("")}</ul>` : ""}
      <button class="primary" id="toQuizBtn">Ir al quiz guiado</button>
    </article>`;
}

function quizHTML(block) {
  const questions = block.quiz.questions;
  const q = questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  if (ui.feedback) {
    const fb = ui.feedback;
    return `
      <section class="quiz">
        <p class="muted">Pregunta ${n} de ${questions.length}</p>
        <h2>${escapeHtml(q.prompt)}</h2>
        <div class="feedback ${fb.result.correct ? "ok" : "bad"}">
          <strong>${fb.result.correct ? "Correcto" : "Incorrecto"}</strong>
          ${fb.xpGained ? `<span class="xp-gain">+${fb.xpGained} XP</span>` : ""}
          ${teachingExplanationHTML(fb.result, (block.theory?.examples || [])[0] || null)}
        </div>
        <div class="quiz-tools"><button class="secondary" id="toggleQuizTheoryBtn">📖 ${ui.showQuizTheory ? "Cerrar teórico" : "Consultar teórico"}</button></div>
        ${ui.showQuizTheory ? quizTheoryHTML(block) : ""}
        <button class="primary" id="quizContinueBtn">Continuar</button>
      </section>`;
  }
  return `
    <section class="quiz">
      <p class="muted">Pregunta ${n} de ${questions.length} · respuesta inmediata</p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${optionsFor(q).map((o) => `<button class="option" data-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${hintControlsHTML(q)}
        <button class="secondary" id="toggleQuizTheoryBtn">📖 ${ui.showQuizTheory ? "Cerrar teórico" : "Consultar teórico"}</button>
        <button class="secondary" id="showSummaryBtn">📋 Resumen del nivel</button>
      </div>
      ${ui.showQuizTheory ? quizTheoryHTML(block) : ""}
      ${ui.showSummary ? summaryHTML() : ""}
    </section>`;
}

function quizTheoryHTML(block) {
  const html = theoryHTML(ui.bundle.course, block);
  return `<div class="quiz-theory-panel" id="quizTheoryPanel" aria-label="Teoría de la lección"><div class="quiz-theory-header"><h3>📖 Repasá antes de responder</h3><span>Solo disponible en los quizzes, no en los exámenes finales.</span></div>${html.replace(/<section class="podcast-card"[\s\S]*?<\/section>/, "").replace(/<button class="primary" id="toQuizBtn">Ir al quiz guiado<\/button>/, "")}</div>`;
}

function summaryHTML() {
  const { course, progress } = ui.bundle;
  const level = getLevelById(course, ui.levelId);
  if (!level) return "";
  const blocks = sortedBlocks(level);
  return `
    <div class="summary-panel">
      <h3>📋 Resumen: ${escapeHtml(level.title)}</h3>
      <ul class="summary-list">
        ${blocks.map((b, i) => {
          const done = isDone(progress, level.id, b.id);
          const title = b.theory?.title || b.title || "Bloque " + (i + 1);
          const concepts = (b.quiz?.questions || []).map(q => q.relatedConcept || "").filter(Boolean);
          const uniqueConcepts = [...new Set(concepts)];
          return `<li class="${done ? "done" : ""}">
            <strong>${done ? "✓" : "○"} ${escapeHtml(title)}</strong>
            ${uniqueConcepts.length ? `<p class="muted">Conceptos: ${uniqueConcepts.map(c => escapeHtml(c)).join(", ")}</p>` : ""}
          </li>`;
        }).join("")}
      </ul>
      <button class="secondary" id="closeSummaryBtn">Cerrar resumen</button>
    </div>`;
}

function examHTML(level) {
  const exam = level.exam;
  const q = exam.questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  const selected = ui.examAnswers[q.id];
  const last = n === exam.questions.length;
  return `
    <section class="exam">
      <p class="muted">Examen final · ${n}/${exam.questions.length} · aprobás con ${exam.passScore}/${exam.questions.length} </p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${optionsFor(q).map((o) => `<button class="option ${selected === o.id ? "picked" : ""}" data-exam-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${hintControlsHTML(q)}

      </div>

      <div class="exam-nav">
        <button class="secondary" id="examPrev" ${ui.questionIndex === 0 ? "disabled" : ""}>Anterior</button>
        <button class="primary" id="examNext" ${selected ? "" : "disabled"}>${last ? "Enviar examen" : "Siguiente"}</button>
      </div>
    </section>`;
}

function resultsHTML() {
  const pack = ui.examPack;
  if (!pack) return "<p>Sin resultado.</p>";
  const { result, xpGained, alreadyAwarded, unlockedLevelId } = pack;
  const recs = recommendReviews(ui.bundle.progress, ui.bundle.course);
  const review = getPendingAiReview(ui.bundle.progress, ui.levelId);
  return `
    <section class="results">
      <h2>${result.passed ? "Nivel aprobado" : "No aprobado todavía"}</h2>
      <p class="score">${result.correct} / ${result.total}</p>
      <p>${result.passed ? "Alcanzaste el umbral de " + result.passScore + "." : "Necesitás " + result.passScore + " correctas para desbloquear el siguiente nivel."}</p>
      <p>${alreadyAwarded ? "Este examen ya había otorgado XP: no se sumó otra vez." : (xpGained ? ("+" + xpGained + " XP") : "Sin XP en este intento.")}</p>
      ${unlockedLevelId ? `<p><strong>Se desbloqueó el siguiente nivel.</strong></p>` : ""}
      ${review ? `<div class="ai-review-callout"><strong>🧠 Falta el repaso con IA</strong><p>${review.examPassed ? 'Aprobaste la parte de opciones. Para completar el nivel, explicá los conceptos que fallaste en una charla con la IA.' : 'Antes de volver a rendir, vas a conversar con la IA sobre tus errores. Después tendrás que aprobar el examen.'}</p><button class="primary" id="startAiReview">Empezar charla de repaso</button></div>` : ''}
      <h3>Corrección</h3>
      <ol class="review-list">
        ${result.details.map((d) => `
          <li class="${d.correct ? "ok" : "bad"}">
            <p>${escapeHtml(d.prompt)}</p>
            <p>Tu respuesta: ${escapeHtml(d.selectedText || "(sin responder)")}</p>
            ${reviewExplanationHTML(d)}
          </li>`).join("")}
      </ol>
      <h3>Repaso recomendado</h3>
      <ul class="recs">${recs.map((r) => `<li>${escapeHtml(r.title)} — ${escapeHtml(r.detail)}</li>`).join("")}</ul>
      <div class="exam-nav">
        ${review ? `<span class="muted">Primero completá el repaso con la IA para continuar.</span>` : result.passed && unlockedLevelId ? `<button class="primary" id="goNextLevel">Continuar al siguiente nivel</button>` : result.passed ? `<span class="muted">Ya completaste este nivel.</span>` : `<button class="primary" id="retryExam">Reintentar examen</button>`}
        <button class="secondary" id="backPath">Volver al camino</button>
      </div>
    </section>`;
}

function aiReviewHTML() {
  const review = getPendingAiReview(ui.bundle.progress, ui.levelId);
  if (!review) return `<section class="ai-review"><h2>Repaso completado</h2><button class="primary" id="backPath">Volver al camino</button></section>`;
  const messages = review.messages || [];
  const hasSubstantiveAnswer = messages.some((m) => m.role === 'user' && m.text.trim().length >= 35);
  return `<section class="ai-review" aria-label="Repaso final con IA">
    <header class="ai-review-header"><span class="tag">🧠 Repaso obligatorio</span><h2>Demostrá lo que entendiste</h2>
    <p>${escapeHtml(getAiProviderName())} va a preguntarte sobre ${review.topics.length === 1 ? 'el tema en el que te equivocaste' : `los ${review.topics.length} temas en los que te equivocaste`}. Respondé con tus palabras y ejemplos. Podés preguntar todo lo que necesites.</p></header>
    <div class="ai-review-topics"><strong>Temas a reforzar</strong><ul>${review.topics.map(t => `<li>${escapeHtml(t.relatedConcept || t.prompt)}</li>`).join('')}</ul></div>
    <div class="ai-chat-log" id="aiChatLog" role="log" aria-live="polite">
      ${messages.length ? messages.map(m => `<div class="ai-message ${m.role === 'user' ? 'mine' : 'tutor'}"><strong>${m.role === 'user' ? 'Vos' : escapeHtml(getAiProviderName()) + ' · tutor'}</strong><p>${escapeHtml(m.text)}</p></div>`).join('') : '<p class="muted">La conversación empieza con una pregunta de tu tutor de IA.</p>'}
      ${ui.aiBusy ? '<p class="ai-chat-wait">La IA está pensando…</p>' : ''}
    </div>
    ${ui.aiError ? `<div class="ai-chat-error" role="alert">${escapeHtml(ui.aiError)}</div>` : ''}
    <label class="ai-text-label" for="aiStudentText">Tu explicación o pregunta</label>
    <textarea id="aiStudentText" maxlength="1800" rows="3" placeholder="Por ejemplo: creo que este concepto significa... porque..." ${ui.aiBusy ? 'disabled' : ''}></textarea>
    <div class="ai-chat-buttons">
      <button class="primary" id="aiSendMessage" ${ui.aiBusy ? 'disabled' : ''}>Enviar a IA</button>
      <button class="secondary" id="aiCheckUnderstanding" ${ui.aiBusy || !hasSubstantiveAnswer ? 'disabled' : ''} title="La IA revisará si realmente comprendiste los conceptos">✅ Ya entendí · evaluame</button>
    </div>
    <p class="muted">«Ya entendí» no aprueba automáticamente. Tu tutor de IA revisa tus explicaciones y puede hacerte otra pregunta. El repaso no cuesta pistas ni puntos.</p>
  </section>`;
}

function aiCompleteHTML() {
  const completed = ui.bundle.progress.aiReviews?.[ui.levelId];
  return `<section class="ai-review ai-done"><span class="tag">✓ Comprensión verificada</span>
    <h2>¡Repaso completado!</h2><p>La IA comprobó tu explicación sobre los conceptos que habías fallado.</p>
    ${completed?.feedback ? `<p class="ai-completion-feedback">${escapeHtml(completed.feedback)}</p>` : ''}
    ${completed?.examPassed ? `<p>El examen estaba aprobado. Ahora el nivel quedó completado.</p>` : `<p>Ya repasaste los errores. Ahora necesitás volver a rendir y aprobar el examen final.</p>`}
    <div class="exam-nav">${ui.reviewUnlockedLevelId ? `<button class="primary" id="aiGoNext">Ir al siguiente nivel</button>` : !completed?.examPassed ? `<button class="primary" id="aiRetryExam">Volver al examen final</button>` : ''}<button class="secondary" id="backPath">Volver al camino</button></div>
  </section>`;
}

async function geminiRequest(mode, messages, review, levelId) {
  if (location.protocol === 'file:') throw new Error('El repaso con IA necesita que abras la academia desde el servidor de Node.js, no directamente como archivo HTML.');
  const response = await fetch('/api/ai-review', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...{ ai: getAiSessionConfig() }, mode, levelTitle: getLevelById(ui.bundle.course, levelId)?.title, topics: review.topics, messages }),
  });
  let result;
  try { result = await response.json(); } catch { throw new Error('El servidor no respondió correctamente. Iniciá el servidor Node.js actualizado.'); }
  if (!response.ok) throw new Error(result.error || 'No se pudo contactar con la IA.');
  return result;
}

async function beginReviewConversation() {
  const review = getPendingAiReview(ui.bundle?.progress, ui.levelId);
  if (!review || review.messages?.length || ui.aiBusy) return;
  const levelId = ui.levelId;
  ui.aiBusy = true; ui.aiError = ''; renderStudy();
  try {
    const answer = await geminiRequest('start', [], review, levelId);
    if (ui.levelId !== levelId || !getPendingAiReview(ui.bundle.progress, levelId)) return;
    await persist(saveAiReviewConversation(ui.bundle.progress, levelId, [{ role: 'model', text: answer.reply }]));
  } catch (error) { ui.aiError = error.message; }
  finally { ui.aiBusy = false; if (ui.view === 'study' && ui.levelId === levelId) renderStudy(); }
}

async function sendAiReviewMessage(mode) {
  const review = getPendingAiReview(ui.bundle?.progress, ui.levelId);
  if (!review || ui.aiBusy) return;
  const textarea = document.getElementById('aiStudentText');
  const drafted = textarea?.value.trim() || '';
  const messages = [...(review.messages || [])];
  if (drafted) messages.push({ role: 'user', text: drafted });
  if (mode === 'chat' && !drafted && messages.at(-1)?.role !== 'user') { ui.aiError = 'Escribí una explicación o pregunta a la IA.'; renderStudy(); return; }
  if (mode === 'check' && !messages.some(m => m.role === 'user' && m.text.length >= 35)) { ui.aiError = 'Primero explicá el tema con tus propias palabras.'; renderStudy(); return; }
  const levelId = ui.levelId;
  ui.aiBusy = true; ui.aiError = '';
  // Guardamos también el último mensaje por si el servicio está temporalmente caído.
  await persist(saveAiReviewConversation(ui.bundle.progress, levelId, messages));
  renderStudy();
  try {
    const answer = await geminiRequest(mode, messages, review, levelId);
    if (ui.levelId !== levelId || !getPendingAiReview(ui.bundle.progress, levelId)) return;
    const updatedMessages = [...messages, { role: 'model', text: answer.reply }];
    await persist(saveAiReviewConversation(ui.bundle.progress, levelId, updatedMessages));
    if (mode === 'check' && answer.mastered) {
      const out = completeAiReview(ui.bundle.progress, ui.bundle.course, levelId, answer);
      await persist(out.progress);
      ui.reviewUnlockedLevelId = out.unlockedLevelId;
      ui.phase = 'ai_complete';
      await persist(touchSession(ui.bundle.progress, { view: 'study', phase: 'ai_complete', levelId }));
    }
  } catch (error) { ui.aiError = error.message; }
  finally { ui.aiBusy = false; if (ui.view === 'study' && ui.levelId === levelId) renderStudy(); }
}

function startSkipLessonExam(targetLevelId, targetBlockIndex) {
  const exam = createSkipLessonExam(ui.bundle.course, targetLevelId, targetBlockIndex);
  if (!exam) { alert('No hay contenidos anteriores suficientes para rendir este salto.'); return; }
  if (!confirm(`Para acceder a ${exam.targetTitle} tendrás que aprobar ${exam.passScore} de ${exam.questions.length} preguntas. ¿Empezar examen?`)) return;
  stopLessonAudio();
  ui.levelId = targetLevelId;
  ui.blockIndex = targetBlockIndex;
  ui.view = 'study';
  ui.phase = 'skip_exam';
  ui.skipExam = exam;
  ui.examAnswers = {};
  ui.examPack = null;
  ui.questionIndex = 0;
  ui.optionOrders = new Map();
  ui.lastCorrectPos = -1;
  ui.showSummary = false;
  renderStudy();
}

export function startSkipExam(targetLevelId) {
  const { course } = ui.bundle;
  const exam = createSkipExam(course, targetLevelId);
  if (!exam) {
    alert("No se puede saltear este nivel.");
    return;
  }
  const ok = confirm(`¿Deseás rendir el examen integrador para acceder a ${exam.targetLevelTitle}?\n\nEste examen contiene ${exam.questions.length} preguntas de todos los niveles anteriores (${exam.priorLevelsCount} niveles previos) y se aprueba con ${exam.passScore} respuestas correctas.`);
  if (!ok) return;

  stopLessonAudio();
  ui.levelId = targetLevelId;
  ui.view = "study";
  ui.phase = "skip_exam";
  ui.skipExam = exam;
  ui.questionIndex = 0;
  ui.examAnswers = {};
  ui.examPack = null;
  ui.optionOrders = new Map();
  ui.lastCorrectPos = -1;
  ui.currentHintShown = false;
  ui.showSummary = false;
  renderStudy();
}

function skipExamHTML() {
  const exam = ui.skipExam;
  if (!exam) return "<p>Examen no encontrado.</p>";
  const q = exam.questions[ui.questionIndex];
  const n = ui.questionIndex + 1;
  const selected = ui.examAnswers[q.id];
  const last = n === exam.questions.length;

  return `
    <section class="exam skip-exam">
      <div class="skip-exam-header">
        <span class="tag">⚡ Examen de Suficiencia Integrador</span>
        <h2>${escapeHtml(exam.title)}</h2>
        <p class="muted">${escapeHtml(exam.description)}</p>
      </div>
      <p class="muted">Pregunta ${n}/${exam.questions.length} · Aprobás con ${exam.passScore}/${exam.questions.length} </p>
      <h2>${escapeHtml(q.prompt)}</h2>
      <div class="options">
        ${optionsFor(q).map((o) => `<button class="option ${selected === o.id ? "picked" : ""}" data-exam-answer="${o.id}">${escapeHtml(o.text)}</button>`).join("")}
      </div>
      <div class="quiz-tools">
        ${hintControlsHTML(q)}

      </div>

      <div class="exam-nav">
        <button class="secondary" id="examPrev" ${ui.questionIndex === 0 ? "disabled" : ""}>Anterior</button>
        <button class="primary" id="examNext" ${selected ? "" : "disabled"}>${last ? "Enviar examen de suficiencia" : "Siguiente"}</button>
      </div>
    </section>`;
}

function priorSummaryHTML() {
  const { course } = ui.bundle;
  const priorLevels = getPriorLevels(course, ui.levelId);
  return `
    <div class="summary-panel">
      <h3>📋 Resumen de contenidos de niveles anteriores</h3>
      <div class="summary-content">
        ${priorLevels.map((lvl) => {
          const blocks = sortedBlocks(lvl);
          return `
            <div class="level-summary-item">
              <strong>📘 ${escapeHtml(lvl.title)}</strong>
              <ul class="summary-list">
                ${blocks.map((b) => {
                  const concepts = (b.quiz?.questions || []).map((q) => q.relatedConcept || "").filter(Boolean);
                  const unique = [...new Set(concepts)];
                  return `<li><strong>${escapeHtml(b.theory?.title || b.title)}</strong>: ${unique.slice(0, 4).map((c) => escapeHtml(c)).join(", ")}</li>`;
                }).join("")}
              </ul>
            </div>`;
        }).join("")}
      </div>
      <button class="secondary" id="closeSummaryBtn">Cerrar resumen</button>
    </div>`;
}

function skipResultsHTML() {
  const pack = ui.examPack;
  if (!pack) return "<p>Sin resultado.</p>";
  const { result, xpGained } = pack;
  const targetLevel = getLevelById(ui.bundle.course, ui.levelId);
  const skipTitle = ui.skipExam?.isLessonSkip ? ui.skipExam.targetTitle : targetLevel?.title;

  return `
    <section class="results">
      <h2>${result.passed ? "🎉 ¡Examen Integrador Aprobado!" : "❌ No alcanzaste el puntaje requerido"}</h2>
      <p class="score">${result.correct} / ${result.total}</p>
      <p>${result.passed
        ? `¡Excelente! Aprobaste con éxito evaluando los contenidos de todos los niveles anteriores. Se ha desbloqueado <strong>${escapeHtml(targetLevel?.title || "el nivel")}</strong>.`
        : `Necesitás ${result.passScore} respuestas correctas para saltear a este nivel. Te recomendamos estudiar los niveles en orden.`}</p>
      <p>${xpGained ? `+${xpGained} XP ganados` : "Sin XP en este intento."}</p>
      <h3>Corrección</h3>
      <ol class="review-list">
        ${result.details.map((d) => `
          <li class="${d.correct ? "ok" : "bad"}">
            <p>${escapeHtml(d.prompt)}</p>
            <p>Tu respuesta: ${escapeHtml(d.selectedText || "(sin responder)")}</p>
            ${reviewExplanationHTML(d)}
          </li>`).join("")}
      </ol>
      <div class="exam-nav">
        ${result.passed
          ? `<button class="primary" id="enterTargetLevel">Ingresar a ${escapeHtml(skipTitle || "Nivel")}</button>`
          : `<button class="primary" id="retrySkipExam">Reintentar examen</button>`}
        <button class="secondary" id="backPath">Volver al camino</button>
      </div>
    </section>`;
}

function bindStudyActions() {
  document.getElementById('startAiReview')?.addEventListener('click', async () => {
    ui.phase = 'ai_review'; ui.aiError = ''; ui.aiBusy = false;
    await persist(touchSession(ui.bundle.progress, { view: 'study', phase: 'ai_review', levelId: ui.levelId }));
    renderStudy();
    beginReviewConversation();
  });
  document.getElementById('aiSendMessage')?.addEventListener('click', () => sendAiReviewMessage('chat'));
  document.getElementById('aiCheckUnderstanding')?.addEventListener('click', () => sendAiReviewMessage('check'));
  document.getElementById('aiStudentText')?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendAiReviewMessage('chat'); }
  });
  document.getElementById('aiRetryExam')?.addEventListener('click', () => {
    ui.phase = 'exam'; ui.questionIndex = 0; ui.examAnswers = {}; ui.examPack = null;
    ui.optionOrders = new Map(); ui.lastCorrectPos = -1; renderStudy();
  });
  document.getElementById('aiGoNext')?.addEventListener('click', () => {
    if (ui.reviewUnlockedLevelId) openLevel(ui.reviewUnlockedLevelId);
  });
  document.getElementById("toggleQuizTheoryBtn")?.addEventListener("click", () => { ui.showQuizTheory = !ui.showQuizTheory; renderStudy(); });
  document.getElementById("toQuizBtn")?.addEventListener("click", () => {
    stopLessonAudio();
    ui.phase = "quiz";
    ui.showQuizTheory = false;
    ui.questionIndex = 0;
    ui.feedback = null;
    ui.currentHintShown = false;
    ui.showQuizTheory = false;
    renderStudy();
  });
  // Cada pista se descuenta del monedero global del perfil una sola vez.
  document.getElementById("showHintBtn")?.addEventListener("click", () => {
    const q = ui.phase === 'quiz' ? currentBlock().quiz.questions[ui.questionIndex]
      : ui.phase === 'skip_exam' ? ui.skipExam.questions[ui.questionIndex]
      : currentLevel().exam.questions[ui.questionIndex];
    const used = revealHint(getActiveProfileId(), studyQuestionKey(q));
    if (!used.ok) { showStoreModal('Ya usaste tus tres pistas gratuitas. Podés comprar otra con puntos.'); return; }
    updateWalletBadge();
    renderStudy();
  });
  document.getElementById('buyHintBtn')?.addEventListener('click', () => showStoreModal());
  document.getElementById('buyPodcastBtn')?.addEventListener('click', () => {
    const key = lessonKey(currentBlock());
    const out = buyPodcast(getActiveProfileId(), key);
    if (!out.ok) { showStoreModal(`Te faltan ${PODCAST_PRICE - out.wallet.balance} puntos para comprar el audio de esta lección.`); return; }
    updateWalletBadge();
    renderStudy();
  });
  const audioState = (status) => {
    ui.audioStatus = status;
    const caption = document.getElementById('podcastState');
    if (caption) caption.textContent = status === 'playing' ? 'Reproduciendo lección…' : status === 'paused' ? 'Audio en pausa.' : 'Audio terminado. Podés reproducirlo otra vez.';
    const pauseBtn = document.getElementById('pauseLessonBtn');
    const stopBtn = document.getElementById('stopLessonBtn');
    if (pauseBtn) { pauseBtn.disabled = status === 'ended'; pauseBtn.textContent = status === 'paused' ? 'Reanudar' : 'Pausar'; }
    if (stopBtn) stopBtn.disabled = status === 'ended';
  };
  document.getElementById('readLessonBtn')?.addEventListener('click', () => {
    if (!isAudioAvailable()) { alert('Este navegador no admite la lectura en voz alta. Probá con Chrome, Edge o un navegador compatible.'); return; }
    playLessonAudio(lessonTranscript(currentBlock(), ui.bundle.course.methodology), audioState);
  });
  document.getElementById('pauseLessonBtn')?.addEventListener('click', () => togglePauseLessonAudio(audioState));
  document.getElementById('stopLessonBtn')?.addEventListener('click', () => { stopLessonAudio(); audioState('ended'); });
  // Summary button
  document.getElementById("showSummaryBtn")?.addEventListener("click", () => {
    ui.showSummary = !ui.showSummary;
    renderStudy();
  });
  document.getElementById("closeSummaryBtn")?.addEventListener("click", () => {
    ui.showSummary = false;
    renderStudy();
  });
  mainEl.querySelectorAll("[data-answer]").forEach((btn) => {
    btn.onclick = async () => {
      const block = currentBlock();
      const question = block.quiz.questions[ui.questionIndex];
      const out = answerQuiz(ui.bundle.progress, question, btn.dataset.answer);
      await persist(out.progress);
      ui.feedback = out;
      ui.currentHintShown = false;
      renderStudy();
    };
  });
  document.getElementById("quizContinueBtn")?.addEventListener("click", async () => {
    const block = currentBlock();
    const questions = block.quiz.questions;
    ui.feedback = null;
    ui.currentHintShown = false;
    if (ui.questionIndex < questions.length - 1) {
      ui.questionIndex += 1;
    } else {
      ui.showQuizTheory = false;
      const level = currentLevel();
      await persist(completeBlock(ui.bundle.progress, level.id, block.id));
      const blocks = sortedBlocks(level);
      if (ui.blockIndex < blocks.length - 1) {
        ui.blockIndex += 1;
        ui.phase = "theory";
        ui.questionIndex = 0;
      } else {
        ui.phase = "exam";
        ui.questionIndex = 0;
        ui.examAnswers = {};
        ui.optionOrders = new Map();
        ui.lastCorrectPos = -1;
      }
    }
    await persist(touchSession(ui.bundle.progress, {
      view: "study",
      levelId: ui.levelId,
      phase: ui.phase,
      blockIndex: ui.blockIndex,
      questionIndex: ui.questionIndex,
    }));
    renderStudy();
  });
  mainEl.querySelectorAll("[data-exam-answer]").forEach((btn) => {
    btn.onclick = () => {
      const q = ui.phase === "skip_exam"
        ? ui.skipExam.questions[ui.questionIndex]
        : currentLevel().exam.questions[ui.questionIndex];
      ui.examAnswers[q.id] = btn.dataset.examAnswer;
      renderStudy();
    };
  });
  document.getElementById("examPrev")?.addEventListener("click", () => {
    if (ui.questionIndex > 0) {
      ui.questionIndex -= 1;
      ui.currentHintShown = false;
    }
    renderStudy();
  });
  document.getElementById("examNext")?.addEventListener("click", async () => {
    if (ui.phase === "skip_exam") {
      const exam = ui.skipExam;
      if (ui.questionIndex < exam.questions.length - 1) {
        ui.questionIndex += 1;
        ui.currentHintShown = false;
        renderStudy();
        return;
      }
      const out = exam.isLessonSkip
        ? applySkipLessonResult(ui.bundle.progress, ui.bundle.course, ui.levelId, exam.targetBlockIndex, exam, ui.examAnswers)
        : applySkipExamResult(ui.bundle.progress, ui.bundle.course, ui.levelId, exam, ui.examAnswers);
      await persist(touchSession(out.progress, { view: "study", phase: "skip_results", levelId: ui.levelId }));
      ui.examPack = out;
      ui.phase = "skip_results";
      renderStudy();
      return;
    }

    const exam = currentLevel().exam;
    if (ui.questionIndex < exam.questions.length - 1) {
      ui.questionIndex += 1;
      ui.currentHintShown = false;
      renderStudy();
      return;
    }
    const out = applyExamResult(ui.bundle.progress, ui.bundle.course, currentLevel(), exam, ui.examAnswers);
    await persist(touchSession(out.progress, { view: "study", phase: "results", levelId: ui.levelId }));
    ui.examPack = out;
    ui.phase = "results";
    renderStudy();
  });
  document.getElementById("retryExam")?.addEventListener("click", () => {
    ui.phase = "exam";
    ui.questionIndex = 0;
    ui.examAnswers = {};
    ui.examPack = null;
    ui.optionOrders = new Map();
    ui.lastCorrectPos = -1;
    ui.currentHintShown = false;
    renderStudy();
  });
  document.getElementById("goNextLevel")?.addEventListener("click", () => {
    const nextId = ui.examPack?.unlockedLevelId;
    if (nextId) openLevel(nextId);
  });
  document.getElementById("backPath")?.addEventListener("click", async () => {
    stopLessonAudio();
    ui.view = "subject";
    document.body.classList.remove("focus-mode");
    await renderSubjectDetail(ui.subjectId, ui.courseId);
  });
  // Skip-level exam handlers
  bindSkipExamActions();
}

function bindSkipExamActions() {
  document.getElementById("enterTargetLevel")?.addEventListener("click", async () => {
    const blockIndex = ui.skipExam?.isLessonSkip ? ui.skipExam.targetBlockIndex : null;
    await openLevel(ui.levelId);
    if (blockIndex !== null) {
      const blocks = sortedBlocks(currentLevel());
      if (blockIndex >= blocks.length) {
        ui.phase = 'exam';
        ui.questionIndex = 0;
        ui.examAnswers = {};
      } else {
        ui.blockIndex = blockIndex;
        ui.phase = 'theory';
      }
      renderStudy();
    }
  });
  document.getElementById("retrySkipExam")?.addEventListener("click", () => {
    if (ui.skipExam?.isLessonSkip) startSkipLessonExam(ui.levelId, ui.skipExam.targetBlockIndex);
    else startSkipExam(ui.levelId);
  });
}

function currentLevel() {
  return getLevelById(ui.bundle.course, ui.levelId);
}
function currentBlock() {
  return sortedBlocks(currentLevel())[ui.blockIndex];
}
function isDone(progress, levelId, blockId) {
  return ((progress.completedBlocks || {})[levelId] || []).includes(blockId);
}
function canJumpBlock(progress, level, index) {
  const blocks = sortedBlocks(level);
  for (let k = 0; k < index; k++) {
    if (!isDone(progress, level.id, blocks[k].id)) return false;
  }
  return true;
}
function labelStatus(status) {
  if (status === "passed") return "Aprobado";
  if (status === "in_progress") return "En progreso";
  if (status === "available") return "Disponible";
  return "Bloqueado";
}

function showMaterialPreview(material) {
  let panel = document.getElementById("materialPreviewPanel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "materialPreviewPanel";
    panel.className = "material-preview";
    document.body.appendChild(panel);
  }
  panel.innerHTML = `
    <div class="preview-header">
      <h3>${escapeHtml(material.name)}</h3>
      <button id="closeMaterialPreview" class="secondary">✕ Cerrar</button>
    </div>
    <pre class="preview-content">${escapeHtml(material.content || "(Sin contenido)")}</pre>`;
  panel.style.display = "block";
  document.getElementById("closeMaterialPreview").onclick = () => {
    panel.style.display = "none";
  };
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s || "";
  return d.innerHTML;
}

window.renderMainPanel = renderMain;
window.openAcademiaSubject = openSubject;
window.startSkipExam = startSkipExam;

const origRenderSubjects = window.renderSubjects;
if (origRenderSubjects) {
  window.renderSubjects = async function () {
    await origRenderSubjects();
    if (ui.view === "dashboard" || ui.view === "welcome") renderMain();
  };
}
const origRenderProfiles = window.renderProfiles;
if (origRenderProfiles) {
  window.renderProfiles = async function () {
    stopLessonAudio();
    await origRenderProfiles();
    ui.view = "dashboard";
    ui.bundle = null;
    renderMain();
  };
}

if (getActiveSubjectId()) {
  ui.subjectId = getActiveSubjectId();
  window._currentSubjectId = ui.subjectId;
}

renderMain();
