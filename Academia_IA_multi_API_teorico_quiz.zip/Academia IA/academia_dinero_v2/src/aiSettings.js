// Configuración por navegador. NUNCA se guarda la clave API en localStorage.
// La clave vive exclusivamente en memoria hasta recargar la página.
export const AI_PROVIDERS = {
  gemini: { name: 'Google Gemini', model: 'gemini-2.5-flash', url: 'https://aistudio.google.com/apikey' },
  openai: { name: 'OpenAI', model: 'gpt-4.1-mini', url: 'https://platform.openai.com/api-keys' },
  anthropic: { name: 'Anthropic Claude', model: 'claude-sonnet-4-5', url: 'https://console.anthropic.com/settings/keys' },
  deepseek: { name: 'DeepSeek', model: 'deepseek-chat', url: 'https://platform.deepseek.com/' },
  groq: { name: 'Groq', model: 'llama-3.3-70b-versatile', url: 'https://console.groq.com/keys' },
  openrouter: { name: 'OpenRouter', model: 'openai/gpt-4.1-mini', url: 'https://openrouter.ai/settings/keys' },
  mistral: { name: 'Mistral', model: 'mistral-small-latest', url: 'https://console.mistral.ai/api-keys/' },
  custom: { name: 'Otro (OpenAI compatible)', model: 'modelo-personalizado', url: '' },
};
const prefKey = 'academia-ia-provider-v1';
let balanceOptions = false;
try { balanceOptions = localStorage.getItem("academia-ia-balance-options") === "true"; } catch {}
export function shouldBalanceOptions() { return balanceOptions; }
let current = { provider: 'gemini', model: AI_PROVIDERS.gemini.model, apiKey: '' };
try {
  const saved = JSON.parse(localStorage.getItem(prefKey) || 'null');
  if (saved && AI_PROVIDERS[saved.provider]) {
    current.provider = saved.provider;
    current.model = typeof saved.model === 'string' && saved.model.length < 100 ? saved.model : AI_PROVIDERS[saved.provider].model;
  }
} catch {}

export function getAiSessionConfig() {
  return { provider: current.provider, model: current.model, ...(current.apiKey ? { apiKey: current.apiKey } : {}) };
}
export function getAiProviderName() { return AI_PROVIDERS[current.provider]?.name || 'IA'; }
export function initAiSettings() {
  document.getElementById('aiSettingsBtn')?.addEventListener('click', openSettings);
}
function openSettings() {
  let overlay = document.getElementById('aiSettingsOverlay');
  if (!overlay) { overlay = document.createElement('div'); overlay.id = 'aiSettingsOverlay'; overlay.className = 'shop-overlay'; document.body.appendChild(overlay); }
  overlay.style.display = "flex";
  overlay.innerHTML = `<section class="shop-panel ai-settings-panel" role="dialog" aria-modal="true" aria-labelledby="aiSettingsTitle">
      <button type="button" class="secondary shop-close" id="closeAiSettings">✕ Cerrar</button>
      <p class="muted">AJUSTES DE TUTORÍA</p><h2 id="aiSettingsTitle">⚙️ Configuración de IA</h2>
      <p>Elegí qué IA querés usar para los repasos finales. Podés utilizar tu propia clave o la que configuraste en el servidor.</p>
      <form id="aiSettingsForm">
        <label for="aiProviderInput">Proveedor</label>
        <select id="aiProviderInput">${Object.entries(AI_PROVIDERS).map(([key, provider]) => `<option value="${key}" ${key === current.provider ? 'selected' : ''}>${provider.name}</option>`).join('')}</select>
        <label for="aiModelInput">Modelo (identificador de la API)</label>
        <input id="aiModelInput" maxlength="100" required autocomplete="off" value="${esc(current.model)}" placeholder="Ej.: gemini-2.5-flash">
        <label for="aiApiKeyInput">Clave API (opcional si tu servidor ya tiene una)</label>
        <div class="key-control"><input id="aiApiKeyInput" type="password" autocomplete="off" spellcheck="false" placeholder="Pegar clave solo en esta sesión" value="${esc(current.apiKey)}"><button class="secondary" type="button" id="toggleAiKey">Mostrar</button></div>
        <p class="muted" id="aiProviderHelp"></p>
        <label class="ai-setting-check"><input id="aiAutoBalance" type="checkbox" ${balanceOptions ? "checked" : ""}> <span><strong>Equilibrar automáticamente las respuestas</strong><small>La IA intenta que las opciones falsas tengan una extensión parecida a la correcta, sin cambiar el significado. Se usa durante quizzes y exámenes, solo la primera vez por pregunta; puede consumir consultas o saldo de tu API. Si falla, se muestran las opciones originales.</small></span></label>
        <p class="ai-privacy-note">🔒 La clave introducida <strong>no se guarda en el navegador ni se exporta con tu perfil</strong>. Se envía solamente a tu servidor para la consulta. En enlaces públicos, usá HTTPS. Si recargás, tendrás que introducirla nuevamente.</p>
        <p class="muted" id="aiServerStatus">Comprobando servidor…</p>
        <div class="ai-settings-actions"><button type="submit" class="primary">Guardar configuración</button><button type="button" class="secondary" id="forgetAiKey">Olvidar clave</button></div>
        <p class="muted" id="aiSettingsMessage" role="status"></p>
      </form>
    </section>`;
  const form = overlay.querySelector('#aiSettingsForm'), provider = overlay.querySelector('#aiProviderInput');
  const model = overlay.querySelector('#aiModelInput'), key = overlay.querySelector('#aiApiKeyInput');
  const info = overlay.querySelector('#aiProviderHelp');
  function updateHelp() {
    const currentProvider = AI_PROVIDERS[provider.value];
    info.innerHTML = currentProvider.url ? `Conseguí tu clave en <a href="${currentProvider.url}" target="_blank" rel="noopener noreferrer">el portal oficial del proveedor</a>. La disponibilidad y el costo dependen de tu cuenta.` : `Para proveedores compatibles, el administrador configura AI_CUSTOM_BASE_URL en gemini_config.local; el navegador no puede definir una URL de servidor arbitraria por seguridad.`;
  }
  provider.onchange = () => { model.value = AI_PROVIDERS[provider.value].model; updateHelp(); };
  updateHelp();
  overlay.querySelector('#toggleAiKey').onclick = (e) => { key.type = key.type === 'password' ? 'text' : 'password'; e.currentTarget.textContent = key.type === 'password' ? 'Mostrar' : 'Ocultar'; };
  const close = () => { overlay.style.display = 'none'; key.value = ''; };
  overlay.querySelector('#closeAiSettings').onclick = close;
  overlay.onclick = e => { if (e.target === overlay) close(); };
  overlay.querySelector('#forgetAiKey').onclick = () => { current.apiKey = ''; key.value = ''; overlay.querySelector('#aiSettingsMessage').textContent = 'Clave borrada de esta sesión.'; };
  form.onsubmit = e => {
    e.preventDefault();
    const candidate = model.value.trim();
    if (!/^[a-zA-Z0-9_.:\/-]{1,100}$/.test(candidate)) { overlay.querySelector('#aiSettingsMessage').textContent = 'El modelo contiene caracteres no permitidos.'; return; }
    current = { provider: provider.value, model: candidate, apiKey: key.value.trim() };
    balanceOptions = Boolean(overlay.querySelector("#aiAutoBalance").checked);
    localStorage.setItem("academia-ia-balance-options", String(balanceOptions));
    localStorage.setItem(prefKey, JSON.stringify({ provider: current.provider, model: current.model }));
    document.dispatchEvent(new Event('academia-ai-changed'));
    close();
  };
  fetch('/api/ai-review', { cache: 'no-store' }).then(r => r.json()).then(data => {
    overlay.querySelector('#aiServerStatus').textContent = `Claves disponibles en el servidor: ${data.configuredProviders?.length ? data.configuredProviders.map(v => AI_PROVIDERS[v]?.name || v).join(', ') : 'ninguna (podés usar tu clave temporal)'}.`;
  }).catch(() => { overlay.querySelector('#aiServerStatus').textContent = 'Servidor sin conexión. Iniciá Academia IA con Node.js para utilizar la IA.'; });
  key.focus();
}
function esc(v) { return String(v || '').replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;'); }
