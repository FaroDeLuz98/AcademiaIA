// Narración local mediante SpeechSynthesis del navegador, sin conexión ni API externa.
import { getTheoryViewModel } from './courseEngine.js';

let current = null;
let usingNative = false;

function plainText(html) {
  const el = document.createElement('div');
  el.innerHTML = String(html ?? '');
  return (el.textContent || '').replace(/\s+/g, ' ').trim();
}

export function lessonTranscript(block, methodology) {
  const model = getTheoryViewModel(block, methodology);
  return [
    model.title,
    ...(model.paragraphs || []).map(plainText),
    ...(model.examples || []).flatMap(e => [`Ejemplo: ${e.title}.`, e.body]),
    ...(model.cases || []).flatMap(e => [`Caso práctico: ${e.title}.`, e.body]),
    ...(model.formulas || []).flatMap(f => [`Fórmula: ${f.name}.`, f.expression, f.note || '']),
    ...(model.procedure || []).map(s => `${s.step}. ${s.detail}`),
    model.code?.source ? `Código del ejemplo. ${model.code.source}` : '',
  ].map(plainText).filter(Boolean).join('. ');
}

export function isAudioAvailable() {
  return typeof window !== 'undefined' && (
    !!window.AndroidLessonReader || ('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window)
  );
}

function chunk(text, maxLength = 200) {
  const sentences = text.match(/[^.!?]+[.!?]*\s*/g) || [text];
  const parts = [];
  let currentPart = '';
  for (const sentence of sentences) {
    if (currentPart.length + sentence.length > maxLength && currentPart) {
      parts.push(currentPart.trim()); currentPart = '';
    }
    if (sentence.length > maxLength) {
      const words = sentence.split(/\s+/);
      for (const word of words) {
        if (currentPart.length + word.length > maxLength && currentPart) {
          parts.push(currentPart.trim()); currentPart = '';
        }
        currentPart += word + ' ';
      }
    } else currentPart += sentence;
  }
  if (currentPart.trim()) parts.push(currentPart.trim());
  return parts;
}

export function stopLessonAudio() {
  if (current) current.stopped = true;
  if (usingNative) window.AndroidLessonReader?.stop();
  else if (typeof window !== 'undefined' && window.speechSynthesis) window.speechSynthesis.cancel();
  current = null;
  usingNative = false;
  if (typeof window !== 'undefined') window.__academyLessonAudioEnded = null;
}

export function playLessonAudio(text, onStatus = () => {}) {
  if (!isAudioAvailable()) return false;
  stopLessonAudio();
  if (window.AndroidLessonReader) {
    const session = { stopped: false, paused: false };
    current = session;
    usingNative = true;
    window.__academyLessonAudioEnded = () => {
      if (!session.stopped && current === session) {
        current = null;
        usingNative = false;
        onStatus('ended');
      }
    };
    window.AndroidLessonReader.speak(text);
    onStatus('playing');
    return true;
  }
  const chunks = chunk(text);
  if (!chunks.length) return false;
  const session = { stopped: false, index: 0, chunks, onStatus };
  current = session;
  const synth = window.speechSynthesis;
  const speakNext = () => {
    if (session.stopped || current !== session) return;
    if (session.index >= session.chunks.length) {
      current = null;
      onStatus('ended');
      return;
    }
    const utterance = new SpeechSynthesisUtterance(session.chunks[session.index++]);
    utterance.lang = 'es-UY';
    utterance.rate = 0.94;
    const spanishVoice = synth.getVoices().find(v => /^es(-|_)/i.test(v.lang));
    if (spanishVoice) utterance.voice = spanishVoice;
    utterance.onend = speakNext;
    utterance.onerror = () => { if (!session.stopped) { current = null; onStatus('ended'); } };
    synth.speak(utterance);
  };
  onStatus('playing');
  speakNext();
  return true;
}

export function togglePauseLessonAudio(onStatus = () => {}) {
  if (!current || !isAudioAvailable()) return;
  if (usingNative) {
    if (current.paused) {
      current.paused = false;
      window.AndroidLessonReader.resume();
      onStatus('playing');
    } else {
      current.paused = true;
      window.AndroidLessonReader.pause();
      onStatus('paused');
    }
    return;
  }
  if (window.speechSynthesis.paused) {
    window.speechSynthesis.resume(); onStatus('playing');
  } else {
    window.speechSynthesis.pause(); onStatus('paused');
  }
}
