// src/profile.js
// UI & logic for managing user profiles
import { addProfile, getAllProfiles, updateProfile, deleteProfile, setActiveProfileId, getActiveProfileId } from "./storage.js";
import { deleteWallet } from './rewards.js';

const profileListEl = document.getElementById("profileList");
const profileFormEl = document.getElementById("profileForm");
const profileNameInput = document.getElementById("profileNameInput");
const profileModal = document.getElementById("profileModal");
let editingProfileId = null;

function closeModal(){
  profileModal.style.display = "none";
  profileNameInput.value = "";
  editingProfileId = null;
}
function openModal(edit = false, profile = null){
  profileModal.style.display = "block";
  if(edit && profile){
    editingProfileId = profile.id;
    profileNameInput.value = profile.name;
  } else {
    editingProfileId = null;
    profileNameInput.value = "";
  }
}

async function renderProfiles(){
  const profiles = await getAllProfiles();
  const activeId = getActiveProfileId();
  profileListEl.innerHTML = profiles.map(p=>`
    <li class="profile-item ${p.id===activeId?"active":""}">
      <span>${p.name}</span>
      <button class="secondary" data-action="select" data-id="${p.id}">Seleccionar</button>
      <button class="secondary" data-action="edit" data-id="${p.id}">Editar</button>
      <button class="secondary" data-action="delete" data-id="${p.id}">Eliminar</button>
    </li>`).join("");
  // attach listeners
  profileListEl.querySelectorAll('button').forEach(btn=>{
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id);
    btn.onclick = async()=>{
      if(action==='select'){
        await setActiveProfileId(id);
        renderProfiles();
        if(window.renderSubjects) window.renderSubjects();
        if(window.renderMainPanel) window.renderMainPanel();
      } else if(action==='edit'){
        const prof = profiles.find(p=>p.id===id);
        openModal(true, prof);
      } else if(action==='delete'){
        if(confirm('¿Eliminar el perfil y todos sus datos?')){
          await deleteProfile(id);
          deleteWallet(id);
          // if it was active, clear active
          if(activeId===id) localStorage.removeItem('academia_ia_current_profile');
          renderProfiles();
          if(window.renderSubjects) window.renderSubjects();
          if(window.renderMainPanel) window.renderMainPanel();
        }
      }
    };
  });
}

profileFormEl.onsubmit = async(e)=>{
  e.preventDefault();
  const name = profileNameInput.value.trim();
  if(!name) return;
  if(editingProfileId!==null){
    await updateProfile(editingProfileId, name);
  } else {
    const newId = await addProfile(name);
    await setActiveProfileId(newId);
  }
  closeModal();
  renderProfiles();
  if(window.renderSubjects) window.renderSubjects();
  if(window.renderMainPanel) window.renderMainPanel();
};

document.getElementById("addProfileBtn").onclick = ()=>openModal();

document.getElementById("closeProfileModal").onclick = closeModal;

// expose for other scripts
window.renderProfiles = renderProfiles;

// initial render
renderProfiles();
