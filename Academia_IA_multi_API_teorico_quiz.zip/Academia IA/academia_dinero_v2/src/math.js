// src/math.js
// Renderizador de fórmulas liviano y 100 % offline (sin KaTeX ni CDN).
// Convierte $M_2 = EM_p + DV_p + DP_p = M_1 + DP_p$ en HTML con subíndices reales,
// y distingue las fórmulas de los importes en pesos ("$5.000", "$ 3.000").
//
// Uso:
//   import { texToHtml, findMathSpans, typesetMath, autoTypeset } from "./math.js";
//   autoTypeset();   // observa el DOM y compone cualquier "$...$" que aparezca

const SYMBOLS = {
  Delta: "Δ", delta: "δ", alpha: "α", beta: "β", gamma: "γ", lambda: "λ", mu: "μ",
  pi: "π", sigma: "σ", theta: "θ", rho: "ρ", epsilon: "ε", varepsilon: "ε", omega: "ω",
  Sigma: "Σ", Omega: "Ω", phi: "φ",
  times: "×", cdot: "·", div: "÷", pm: "±", mp: "∓",
  subset: "⊂", subseteq: "⊆", supset: "⊃", in: "∈", notin: "∉", cup: "∪", cap: "∩",
  approx: "≈", neq: "≠", ne: "≠", leq: "≤", le: "≤", geq: "≥", ge: "≥", equiv: "≡",
  rightarrow: "→", to: "→", leftarrow: "←", Rightarrow: "⇒", Leftrightarrow: "⇔",
  uparrow: "↑", downarrow: "↓", infty: "∞", ldots: "…", dots: "…", cdots: "⋯",
  sum: "∑", prod: "∏", partial: "∂", nabla: "∇", degree: "°",
};
const RELATIONS = new Set(["=", "<", ">", "≈", "≠", "≤", "≥", "≡", "⊂", "⊆", "⊃", "→", "←", "⇒", "⇔", "∈", "∉"]);
const BINARY = new Set(["+", "−", "×", "÷", "±", "∓", "∪", "∩"]);
const TEXT_CMDS = new Set(["text", "mathrm", "textrm", "mathbf", "textbf", "mathit", "operatorname"]);
const SPACE_CMDS = { ",": "\u2009", ";": "\u2005", ":": "\u2005", "!": "", " ": " ", quad: "\u2003", qquad: "\u2003\u2003" };

const esc = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// ───────────────────────── Tokenizador + parser TeX mínimo ─────────────────────────

function tokenize(tex) {
  const out = [];
  for (let i = 0; i < tex.length; i++) {
    const c = tex[i];
    if (c === "\\") {
      const m = /^[A-Za-z]+/.exec(tex.slice(i + 1));
      if (m) {
        out.push({ t: "cmd", v: m[0] });
        i += m[0].length;
      } else if (i + 1 < tex.length) {
        out.push({ t: "cmd", v: tex[i + 1] });
        i += 1;
      }
    } else if (c === "{" || c === "}" || c === "^" || c === "_") {
      out.push({ t: c });
    } else if (/\s/.test(c)) {
      continue; // en modo matemático TeX ignora los espacios
    } else {
      out.push({ t: "ch", v: c });
    }
  }
  return out;
}

function readGroupText(tokens, pos) {
  // Lee {…} devolviendo el texto plano (para \text{…}); respeta espacios originales.
  let depth = 0, text = "";
  let p = pos;
  if (tokens[p]?.t !== "{") return { text: tokens[p]?.v || "", next: p + 1 };
  depth = 1; p++;
  while (p < tokens.length && depth > 0) {
    const tk = tokens[p];
    if (tk.t === "{") depth++;
    else if (tk.t === "}") { depth--; if (depth === 0) break; }
    else text += tk.v ?? tk.t;
    p++;
  }
  return { text, next: p + 1 };
}

function parseArg(tokens, pos) {
  // Un argumento es {grupo} o un único átomo.
  if (tokens[pos]?.t === "{") {
    const { html, next } = parseSeq(tokens, pos + 1, true);
    return { html, next };
  }
  const { html, next } = parseAtom(tokens, pos);
  return { html, next };
}

function charHtml(c) {
  if (/[A-Za-zΑ-Ωα-ω]/.test(c)) return `<i>${esc(c)}</i>`;
  if (c === "-") return `<span class="mo">−</span>`;
  if (c === "*") return `<span class="mo">·</span>`;
  const sym = c;
  if (BINARY.has(sym) || RELATIONS.has(sym)) return opHtml(sym);
  return esc(c);
}

function opHtml(sym) {
  const sp = "\u2005";
  return `<span class="mo">${sp}${esc(sym)}${sp}</span>`;
}

function parseAtom(tokens, pos) {
  const tk = tokens[pos];
  if (!tk) return { html: "", next: pos + 1 };

  if (tk.t === "{") {
    const { html, next } = parseSeq(tokens, pos + 1, true);
    return { html, next };
  }
  if (tk.t === "}" || tk.t === "^" || tk.t === "_") return { html: "", next: pos + 1 };

  if (tk.t === "ch") {
    // 1,5 / 0.20 / 1.100 → los números no se separan con espacios finos
    return { html: charHtml(tk.v), next: pos + 1 };
  }

  // Comandos \algo
  const name = tk.v;
  if (name === "$") return { html: "$", next: pos + 1 };
  if (name === "%") return { html: "%", next: pos + 1 };
  if (name === "&") return { html: "&amp;", next: pos + 1 };
  if (name === "#") return { html: "#", next: pos + 1 };
  if (name === "_" ) return { html: "_", next: pos + 1 };
  if (name === "{" || name === "}") return { html: name, next: pos + 1 };
  if (name === "\\") return { html: "<br>", next: pos + 1 };
  if (name in SPACE_CMDS) return { html: SPACE_CMDS[name], next: pos + 1 };

  if (TEXT_CMDS.has(name)) {
    const { text, next } = readGroupText(tokens, pos + 1);
    const cls = name === "mathbf" || name === "textbf" ? "mr b" : name === "mathit" ? "mr it" : "mr";
    return { html: `<span class="${cls}">${esc(text)}</span>`, next };
  }
  if (name === "frac" || name === "dfrac") {
    const a = parseArg(tokens, pos + 1);
    const b = parseArg(tokens, a.next);
    return {
      html: `<span class="frac"><span class="num">${a.html}</span><span class="den">${b.html}</span></span>`,
      next: b.next,
    };
  }
  if (name === "sqrt") {
    const a = parseArg(tokens, pos + 1);
    return { html: `<span class="sqrt">√<span class="rad">${a.html}</span></span>`, next: a.next };
  }
  if (name === "left" || name === "right") return { html: "", next: pos + 2 }; // \left( → (
  if (name in SYMBOLS) {
    const sym = SYMBOLS[name];
    const isOp = RELATIONS.has(sym) || BINARY.has(sym);
    return { html: isOp ? opHtml(sym) : /^[Α-Ωα-ω]$/.test(sym) ? `<i>${sym}</i>` : sym, next: pos + 1 };
  }
  return { html: esc("\\" + name), next: pos + 1 }; // comando desconocido: se muestra tal cual
}

function parseSeq(tokens, pos, untilBrace) {
  let html = "";
  let p = pos;
  let prevOp = true; // al inicio o tras un operador, "-" y "+" son signos (−5.000), no restas
  while (p < tokens.length) {
    if (untilBrace && tokens[p].t === "}") { p++; break; }
    let atom, next;
    if (prevOp && tokens[p].t === "ch" && (tokens[p].v === "-" || tokens[p].v === "+")) {
      atom = tokens[p].v === "-" ? "−" : "+";
      next = p + 1;
    } else {
      ({ html: atom, next } = parseAtom(tokens, p));
    }
    prevOp = atom.startsWith('<span class="mo">');
    p = next;
    let sub = null, sup = null;
    while (tokens[p] && (tokens[p].t === "_" || tokens[p].t === "^")) {
      const kind = tokens[p].t;
      const arg = parseArg(tokens, p + 1);
      if (kind === "_") sub = arg.html; else sup = arg.html;
      p = arg.next;
    }
    if (sub !== null && sup !== null) {
      atom += `<span class="ss"><sup>${sup}</sup><sub>${sub}</sub></span>`;
    } else if (sub !== null) atom += `<sub>${sub}</sub>`;
    else if (sup !== null) atom += `<sup>${sup}</sup>`;
    html += atom;
  }
  return { html, next: p };
}

/** Convierte una expresión TeX (sin los $) en HTML. */
export function texToHtml(tex) {
  return parseSeq(tokenize(String(tex)), 0, false).html;
}

// ───────────────────────── Detección de fórmulas vs. importes ─────────────────────────

function looksLikeMath(inner) {
  if (!inner || /^\s/.test(inner) || /\s$/.test(inner)) return false; // "$5.000 y aumenta $" → pesos
  const stripped = inner
    .replace(/\\(?:text|mathrm|textrm|mathbf|textbf|mathit|operatorname)\s*\{[^}]*\}/g, "")
    .replace(/\\[A-Za-z]+/g, "");
  if (/[a-záéíóúñü]{4,}/i.test(stripped)) return false; // hay palabras castellanas → no es fórmula
  return true;
}

/** Devuelve [{start, end, tex}] con las fórmulas $...$ encontradas en `text`. */
export function findMathSpans(text) {
  const spans = [];
  const s = String(text);
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === "\\") { i += 2; continue; }
    if (c === "$") {
      let j = i + 1, found = -1;
      while (j < s.length) {
        if (s[j] === "\\") { j += 2; continue; }
        if (s[j] === "$") { found = j; break; }
        j++;
      }
      if (found > i) {
        const inner = s.slice(i + 1, found);
        const nextCh = s[found + 1] || "";
        if (looksLikeMath(inner) && !/\d/.test(nextCh)) {
          spans.push({ start: i, end: found + 1, tex: inner });
          i = found + 1;
          continue;
        }
      }
    }
    i++;
  }
  return addBareSubscripts(s, spans);
}

// Red de seguridad: símbolos con subíndice escritos SIN signos de pesos (p. ej. "M_d", "DV_B",
// "D_{m/e}") también se componen. Solo identificadores en mayúscula de hasta 3 letras.
const BARE_RE = /(?<![A-Za-z0-9_\\])[A-Z][A-Za-z]{0,2}_(?:\{[^{}\s]{1,12}\}|[A-Za-z0-9]{1,2})(?![A-Za-z0-9_])/g;

function addBareSubscripts(s, spans) {
  if (s.indexOf("_") === -1) return spans;
  const out = [...spans];
  let last = 0;
  const gaps = [];
  for (const sp of spans) { gaps.push([last, sp.start]); last = sp.end; }
  gaps.push([last, s.length]);
  for (const [a, b] of gaps) {
    if (b <= a) continue;
    const seg = s.slice(a, b);
    for (const m of seg.matchAll(BARE_RE)) {
      out.push({ start: a + m.index, end: a + m.index + m[0].length, tex: m[0] });
    }
  }
  return out.sort((x, y) => x.start - y.start);
}

/** Texto → HTML seguro con fórmulas compuestas (escapa todo lo demás). */
export function mathHtml(text) {
  const s = String(text ?? "");
  const spans = findMathSpans(s);
  if (!spans.length) return esc(s);
  let out = "", last = 0;
  for (const sp of spans) {
    out += esc(s.slice(last, sp.start));
    out += `<span class="math" role="math">${texToHtml(sp.tex)}</span>`;
    last = sp.end;
  }
  return out + esc(s.slice(last));
}

// ───────────────────────── Composición sobre el DOM ─────────────────────────

const SKIP_SELECTOR = "script,style,textarea,input,pre,code,.math,[data-nomath]";

export function typesetMath(root = document.body) {
  if (!root || typeof document === "undefined") return 0;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue || node.nodeValue.indexOf("$") === -1) return NodeFilter.FILTER_REJECT;
      const parent = node.parentElement;
      if (!parent || parent.closest(SKIP_SELECTOR)) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    },
  });
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);

  let count = 0;
  for (const node of nodes) {
    const text = node.nodeValue;
    const spans = findMathSpans(text);
    if (!spans.length) continue;
    const frag = document.createDocumentFragment();
    let last = 0;
    for (const sp of spans) {
      if (sp.start > last) frag.appendChild(document.createTextNode(text.slice(last, sp.start)));
      const el = document.createElement("span");
      el.className = "math";
      el.setAttribute("role", "math");
      el.innerHTML = texToHtml(sp.tex);
      frag.appendChild(el);
      last = sp.end;
      count++;
    }
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    node.parentNode.replaceChild(frag, node);
  }
  return count;
}

/** Compone ahora y vuelve a componer cada vez que la app repinta contenido. */
export function autoTypeset(root = document.body) {
  if (typeof document === "undefined") return null;
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      observer.disconnect();
      typesetMath(root);
      observer.observe(root, { childList: true, subtree: true, characterData: true });
    });
  });
  typesetMath(root);
  observer.observe(root, { childList: true, subtree: true, characterData: true });
  return observer;
}

if (typeof document !== "undefined" && typeof window !== "undefined") {
  window.typesetMath = typesetMath;
  const start = () => autoTypeset(document.body);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
}
