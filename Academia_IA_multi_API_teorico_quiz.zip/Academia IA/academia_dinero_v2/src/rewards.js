// Economía de estudio por perfil: XP (histórico) ≠ puntos disponibles (gastables).
// Los tres créditos de pistas son globales para el perfil, no para cada examen.
export const FREE_HINTS = 3;
export const HINT_PRICE = 120;
export const PODCAST_PRICE = 200;
const PREFIX = 'academia-ia-rewards-v1:';
const keyFor = (profileId) => PREFIX + String(profileId);
const number = (value) => Math.max(0, Math.floor(Number(value) || 0));

export function getWallet(profileId) {
  const empty = { balance: 0, trackedXP: 0, hints: FREE_HINTS, usedHints: [], podcasts: [] };
  if (profileId == null) return empty;
  try {
    const old = JSON.parse(localStorage.getItem(keyFor(profileId)) || 'null');
    if (!old || typeof old !== 'object') return empty;
    return {
      balance: number(old.balance), trackedXP: number(old.trackedXP),
      hints: number(old.hints ?? FREE_HINTS),
      usedHints: Array.isArray(old.usedHints) ? [...new Set(old.usedHints.filter(s => typeof s === 'string'))] : [],
      podcasts: Array.isArray(old.podcasts) ? [...new Set(old.podcasts.filter(s => typeof s === 'string'))] : [],
    };
  } catch (_) { return empty; }
}

function saveWallet(profileId, wallet) {
  if (profileId == null) return wallet;
  localStorage.setItem(keyFor(profileId), JSON.stringify(wallet));
  return wallet;
}

// Mantiene intactos los XP obtenidos incluso al comprar. Nunca acredita XP repetidos.
export function syncWallet(profileId, earnedXP) {
  const wallet = getWallet(profileId);
  const total = number(earnedXP);
  if (total > wallet.trackedXP) {
    wallet.balance += total - wallet.trackedXP;
    wallet.trackedXP = total;
    saveWallet(profileId, wallet);
  }
  return wallet;
}

export function buyHint(profileId) {
  const wallet = getWallet(profileId);
  if (wallet.balance < HINT_PRICE) return { ok: false, wallet };
  wallet.balance -= HINT_PRICE;
  wallet.hints += 1;
  return { ok: true, wallet: saveWallet(profileId, wallet) };
}

export function hasUsedHint(profileId, questionKey) {
  return getWallet(profileId).usedHints.includes(String(questionKey));
}

export function revealHint(profileId, questionKey) {
  const wallet = getWallet(profileId);
  const key = String(questionKey);
  if (wallet.usedHints.includes(key)) return { ok: true, newUse: false, wallet };
  if (wallet.hints < 1) return { ok: false, newUse: false, wallet };
  wallet.hints -= 1;
  wallet.usedHints.push(key);
  return { ok: true, newUse: true, wallet: saveWallet(profileId, wallet) };
}

export function hasPodcast(profileId, lessonKey) {
  return getWallet(profileId).podcasts.includes(String(lessonKey));
}

export function buyPodcast(profileId, lessonKey) {
  const wallet = getWallet(profileId);
  const key = String(lessonKey);
  if (wallet.podcasts.includes(key)) return { ok: true, alreadyOwned: true, wallet };
  if (wallet.balance < PODCAST_PRICE) return { ok: false, alreadyOwned: false, wallet };
  wallet.balance -= PODCAST_PRICE;
  wallet.podcasts.push(key);
  return { ok: true, alreadyOwned: false, wallet: saveWallet(profileId, wallet) };
}

export function importWallet(profileId, exportedWallet) {
  if (!exportedWallet || typeof exportedWallet !== 'object') return;
  const normalized = {
    balance: number(exportedWallet.balance), trackedXP: number(exportedWallet.trackedXP),
    hints: number(exportedWallet.hints ?? FREE_HINTS),
    usedHints: Array.isArray(exportedWallet.usedHints) ? exportedWallet.usedHints.filter(v => typeof v === 'string') : [],
    podcasts: Array.isArray(exportedWallet.podcasts) ? exportedWallet.podcasts.filter(v => typeof v === 'string') : [],
  };
  saveWallet(profileId, normalized);
}

export function deleteWallet(profileId) {
  if (profileId != null) localStorage.removeItem(keyFor(profileId));
}
