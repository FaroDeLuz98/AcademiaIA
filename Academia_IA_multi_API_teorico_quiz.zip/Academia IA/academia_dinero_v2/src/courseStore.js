// src/courseStore.js
// Cursos y progreso por perfil + materia.

import {
  openDB,
  COURSE_STORE,
  PROGRESS_STORE,
  addProfile,
  getAllProfiles,
  addSubject,
  getSubjectsByProfile,
  addMaterial,
  getMaterials,
} from "./storage.js";
import { validateCourse, createInitialProgress } from "./courseEngine.js";
import { getWallet, importWallet, syncWallet } from './rewards.js';

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveCourse({ profileId, subjectId, definition, source = "json" }) {
  validateCourse(definition);
  const db = await openDB();
  const record = {
    profileId,
    subjectId,
    source,
    title: definition.title,
    methodology: definition.methodology,
    definition,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  const id = await req(db.transaction(COURSE_STORE, "readwrite").objectStore(COURSE_STORE).add(record));
  const progress = createInitialProgress(profileId, subjectId, id, definition);
  const progressId = await saveProgress(progress);
  progress.id = progressId;
  return { course: { ...record, id }, progress };
}

export async function updateCourseDefinition(courseId, definition) {
  validateCourse(definition);
  const db = await openDB();
  const store = db.transaction(COURSE_STORE, "readwrite").objectStore(COURSE_STORE);
  const current = await req(store.get(courseId));
  if (!current) throw new Error("Curso no encontrado");
  current.definition = definition;
  current.title = definition.title;
  current.methodology = definition.methodology;
  current.updatedAt = new Date().toISOString();
  await req(store.put(current));
  return current;
}

export async function getCourse(courseId) {
  const db = await openDB();
  return req(db.transaction(COURSE_STORE, "readonly").objectStore(COURSE_STORE).get(courseId));
}

export async function getCoursesBySubject(profileId, subjectId) {
  const db = await openDB();
  const store = db.transaction(COURSE_STORE, "readonly").objectStore(COURSE_STORE);
  const all = await req(store.index("profileSubject").getAll([profileId, subjectId]));
  return all.filter((c) => c.profileId === profileId && c.subjectId === subjectId);
}

export async function getCoursesByProfile(profileId) {
  const db = await openDB();
  const store = db.transaction(COURSE_STORE, "readonly").objectStore(COURSE_STORE);
  return req(store.index("profileId").getAll(profileId));
}

export async function getProgressByCourse(courseId) {
  const db = await openDB();
  const store = db.transaction(PROGRESS_STORE, "readonly").objectStore(PROGRESS_STORE);
  const list = await req(store.index("courseId").getAll(courseId));
  return list[0] || null;
}

export async function getProgressListByProfile(profileId) {
  const db = await openDB();
  const store = db.transaction(PROGRESS_STORE, "readonly").objectStore(PROGRESS_STORE);
  return req(store.index("profileId").getAll(profileId));
}

export async function saveProgress(progress) {
  const db = await openDB();
  const store = db.transaction(PROGRESS_STORE, "readwrite").objectStore(PROGRESS_STORE);
  progress.updatedAt = new Date().toISOString();
  if (progress.id != null) {
    await req(store.put(progress));
    return progress.id;
  }
  return req(store.add(progress));
}

export async function getStudyBundle(profileId, subjectId) {
  const courses = await getCoursesBySubject(profileId, subjectId);
  const bundles = [];
  for (const course of courses) {
    const progress = await getProgressByCourse(course.id);
    bundles.push({ courseRecord: course, course: course.definition, progress });
  }
  return bundles;
}

export async function getProfileStudyData(profileId) {
  const courses = await getCoursesByProfile(profileId);
  const bundles = [];
  for (const course of courses) {
    const progress = await getProgressByCourse(course.id);
    bundles.push({ courseRecord: course, course: course.definition, progress });
  }
  return bundles;
}

export async function buildExportPayload(profileId) {
  const profiles = await getAllProfiles();
  const profile = profiles.find((p) => p.id === profileId);
  if (!profile) throw new Error("Perfil no encontrado");
  const subjects = await getSubjectsByProfile(profileId);
  const materials = await getMaterials(profileId);
  const courses = await getCoursesByProfile(profileId);
  const progress = await getProgressListByProfile(profileId);
  return {
    format: "academia-ia",
    version: 3,
    exportedAt: new Date().toISOString(),
    profile,
    subjects,
    materials,
    courses,
    progress,
    wallet: syncWallet(profileId, progress.reduce((sum, p) => sum + (p.xp || 0), 0)),
  };
}

export async function importPayload(data) {
  if (!data || (data.format !== "academia-ia" && !data.profile)) {
    throw new Error("Formato inválido");
  }
  if (!data.profile || !Array.isArray(data.subjects)) {
    throw new Error("Formato inválido");
  }
  const name = (data.profile.name || "Perfil") + " (importado)";
  const profileId = await addProfile(name);
  const subjectIdMap = {};
  for (const subject of data.subjects) {
    const newId = await addSubject(profileId, subject.name, subject.level);
    subjectIdMap[subject.id] = newId;
  }
  for (const material of data.materials || []) {
    const subjectId = subjectIdMap[material.subjectId];
    if (!subjectId) continue;
    await addMaterial({
      profileId,
      subjectId,
      name: material.name,
      fileType: material.fileType,
      content: material.content,
      createdAt: material.createdAt || new Date().toISOString(),
    });
  }
  const courseIdMap = {};
  for (const course of data.courses || []) {
    const subjectId = subjectIdMap[course.subjectId];
    if (!subjectId || !course.definition) continue;
    const saved = await saveCourse({
      profileId,
      subjectId,
      definition: course.definition,
      source: course.source || "import",
    });
    courseIdMap[course.id] = saved.course.id;
    if (course.id != null) {
      const incoming = (data.progress || []).find((p) => p.courseId === course.id);
      if (incoming) {
        const merged = {
          ...saved.progress,
          ...incoming,
          id: saved.progress.id,
          profileId,
          subjectId,
          courseId: saved.course.id,
        };
        await saveProgress(merged);
      }
    }
  }
  if (data.wallet) importWallet(profileId, data.wallet);
  return { profileId, subjectIdMap, courseIdMap };
}
