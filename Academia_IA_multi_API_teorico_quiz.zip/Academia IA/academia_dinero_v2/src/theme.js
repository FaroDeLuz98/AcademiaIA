// src/theme.js
// Alterna entre tema claro y oscuro. Sin preferencia guardada, sigue al sistema.

const KEY = "academia-theme";
const root = document.documentElement;
const btn = document.getElementById("themeToggle");

function systemPrefersDark() {
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
}
function currentTheme() {
  return root.getAttribute("data-theme") || (systemPrefersDark() ? "dark" : "light");
}
function apply(theme) {
  root.setAttribute("data-theme", theme);
  try { localStorage.setItem(KEY, theme); } catch { /* modo privado: se aplica igual */ }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#0a1f1a" : "#12372f");
  if (btn) btn.setAttribute("aria-pressed", String(theme === "dark"));
}

if (btn) {
  btn.addEventListener("click", () => apply(currentTheme() === "dark" ? "light" : "dark"));
  btn.setAttribute("aria-pressed", String(currentTheme() === "dark"));
}
