// server.js - Servidor web nativo para Academia IA
// Cero dependencias externas. Inicia al instante con Node.js y abre el navegador al estar listo.

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import { fileURLToPath } from "node:url";
import { queryGeminiReview } from "./geminiReviewServer.js";
import { configuredAiProviders } from "./aiProviders.js";
import { balanceQuestion } from "./balanceQuestionServer.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Archivo de configuración fuera de la carpeta pública: nunca se entrega por HTTP.
const privateConfig = path.resolve(__dirname, "../gemini_config.local");
if (fs.existsSync(privateConfig)) {
  for (const line of fs.readFileSync(privateConfig, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*((?:GEMINI|OPENAI|ANTHROPIC|DEEPSEEK|GROQ|OPENROUTER|MISTRAL)_(?:API_KEY|MODEL)|AI_CUSTOM_(?:API_KEY|MODEL|BASE_URL))\s*=\s*(.*?)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, "");
  }
}
const counters = new Map();
let dailyRequests = { date: "", count: 0 };
function allowAiRequest(req) {
  const ip = req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const recent = (counters.get(ip) || []).filter((t) => now - t < 600000);
  if (recent.length >= 12) return false; // 12 consultas cada 10 minutos por conexión
  recent.push(now); counters.set(ip, recent);
  const today = new Date().toISOString().slice(0, 10);
  if (dailyRequests.date !== today) dailyRequests = { date: today, count: 0 };
  if (dailyRequests.count >= 120) return false;
  dailyRequests.count += 1;
  if (counters.size > 250) counters.clear();
  return true;
}
function json(res, status, value) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(value));
}
async function handleAiReview(req, res) {
  if (req.method === "GET") return json(res, 200, { configured: configuredAiProviders().length > 0, configuredProviders: configuredAiProviders() });
  if (req.method !== "POST") return json(res, 405, { error: "Método no admitido" });
  const origin = req.headers.origin;
  if (origin) {
    try {
      const ownOrigin = `${req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http'}://${req.headers.host}`;
      if (new URL(origin).host !== new URL(ownOrigin).host) return json(res, 403, { error: "Origen no autorizado." });
    } catch { return json(res, 403, { error: "Origen no autorizado." }); }
  }
  if (!allowAiRequest(req)) return json(res, 429, { error: "Demasiadas consultas. Probá más tarde." });
  let raw = "";
  try {
    for await (const chunk of req) {
      raw += chunk;
      if (raw.length > 50000) return json(res, 413, { error: "Solicitud demasiado extensa." });
    }
    const payload = JSON.parse(raw);
    const result = req.url?.startsWith("/api/ai-balance") ? await balanceQuestion(payload) : await queryGeminiReview(payload);
    return json(res, 200, result);
  } catch (error) { return json(res, error.status || 400, { error: error instanceof SyntaxError ? "JSON inválido." : error.message }); }
}
let PORT = Number(process.env.PORT) || 8000;
const HOST = "0.0.0.0";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".pdf": "application/pdf",
  ".txt": "text/plain; charset=utf-8",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
};

const server = http.createServer((req, res) => {
  let parsedUrl;
  try { parsedUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`); }
  catch { return json(res, 400, { error: "URL inválida." }); }
  if (parsedUrl.pathname === "/api/ai-review" || parsedUrl.pathname === "/api/ai-balance") return void handleAiReview(req, res);
  if (req.method !== "GET" && req.method !== "HEAD") return json(res, 405, { error: "Método no admitido" });
  let safePath;
  try { safePath = decodeURIComponent(parsedUrl.pathname); }
  catch { return json(res, 400, { error: "Ruta inválida" }); }
  if (safePath === "/" || safePath === "") safePath = "/index.html";

  const normalized = path.normalize(safePath).replace(/^(\.\.[\/\\])+/, "");
  let filePath = path.resolve(__dirname, "." + path.sep + normalized.replace(/^[/\\]+/, ""));
  // Nunca publicar código del servidor, llaves ni archivos internos.
  const rel = path.relative(__dirname, filePath).replace(/\\/g, "/");
  if (rel.startsWith("..") || path.isAbsolute(rel) || rel.split("/").some((part) => part.startsWith(".") || part === "node_modules") || ["server.js", "geminiReviewServer.js", "aiProviders.js", "balanceQuestionServer.js", "package.json", "package-lock.json"].includes(rel)) {
    return json(res, 404, { error: "No encontrado" });
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
      res.end(`<h1>404 No Encontrado</h1><p>Archivo <code>${safePath}</code> no encontrado.</p>`);
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || "application/octet-stream";

    res.writeHead(200, {
      "Content-Type": contentType,
      "Content-Length": stats.size,
      "Cache-Control": "no-cache, no-store, must-revalidate",
    });

    if (req.method === "HEAD") return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

function startServer(portToTry) {
  server.listen(portToTry, HOST, () => {
    const url = `http://localhost:${portToTry}`;
    console.log("=======================================================");
    console.log("  🎓 ACADEMIA IA - SERVIDOR WEB ACTIVO");
    console.log(`  URL Local:   ${url}`);
    console.log(`  URL en red:  http://127.0.0.1:${portToTry}`);
    console.log("=======================================================");
    console.log("  Abriendo navegador...");
    console.log(`  Proveedores de IA disponibles: ${configuredAiProviders().join(", ") || "ninguno (podés pegar una clave temporal en ⚙️ IA)"}`);
    console.log("  Mantené esta ventana abierta mientras usás la app.");
    console.log("  Presioná Ctrl+C para detener el servidor.\n");

    // Abrir navegador una vez que el servidor está escuchando
    if (process.env.NO_OPEN !== "1") {
      if (process.platform !== "win32") return;
      exec(`start "" "${url}"`, (err) => {
        if (err) {
          console.log(`  (Copiá y abrí este enlace en tu navegador: ${url})`);
        }
      });
    }
  });
}

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.log(`[AVISO] El puerto ${PORT} está ocupado. Probando puerto ${PORT + 1}...`);
    PORT += 1;
    startServer(PORT);
  } else {
    console.error("[ERROR]", err);
  }
});

startServer(PORT);
