import test from "node:test";
import assert from "node:assert/strict";
import { findMathSpans, mathHtml } from "../src/math.js";

test("compone M2 = EMp + DVp + DPp = M1 + DPp con subíndices", () => {
  const html = mathHtml("$M_2 = EM_p + DV_p + DP_p = M_1 + DP_p$.");
  assert.ok(!html.includes("$"));
  assert.ok(!html.includes("_"));
  assert.equal((html.match(/<sub>/g) || []).length, 6);
});

test("distingue importes en pesos de fórmulas", () => {
  const t = "disminuye $DV_p$ en $5.000 y aumenta $EM_p$ en la misma cantidad";
  assert.deepEqual(findMathSpans(t).map((s) => s.tex), ["DV_p", "EM_p"]);
  assert.equal(findMathSpans("Valor $500 pesos y $800 dólares").length, 0);
});

test("respeta \\$ dentro de fórmulas y \\Delta", () => {
  assert.ok(mathHtml("$EM_p = \\$400$").includes("$400"));
  assert.ok(mathHtml("$\\Delta M$").includes("Δ"));
});

test("subíndices sin signos de pesos (M_d) también se componen", () => {
  assert.ok(mathHtml("sube M_d con Y").includes("<sub>"));
});

test("escapa HTML", () => {
  assert.ok(mathHtml("<b>$M_1$</b>").startsWith("&lt;b&gt;"));
});
