import test from 'node:test';
import assert from 'node:assert/strict';
import { requestStructuredAi, configuredAiProviders } from '../aiProviders.js';
import { balanceQuestion, validateBalancedOptions, validateBalanceQuestion } from '../balanceQuestionServer.js';

const prompt = { system: 'Respondé JSON', user: 'Dame una explicación' };
const asResult = { reply:'Bien explicado', mastered: false };
const fetchMock = (expectedUrl, expectedHeader, body) => async (url, options) => {
  assert.match(url,expectedUrl);
  assert.ok(options.headers[expectedHeader]);
  assert.equal(options.method,'POST');
  return { ok:true,json:async()=>body };
};
test('Gemini, OpenAI, Anthropic y OpenAI-compatible devuelven JSON sin revelar claves', async () => {
  const gemini = await requestStructuredAi({ ai:{ provider:'gemini',apiKey:'g-test',model:'gemini-2.5-flash'}, prompt, fetchFn:fetchMock(/generativelanguage.googleapis.com/, 'x-goog-api-key', {candidates:[{content:{parts:[{text:JSON.stringify(asResult)}]}}]}) });
  assert.deepEqual(gemini,asResult);
  for (const [provider, url] of [['openai',/api.openai.com/],['deepseek',/api.deepseek.com/],['groq',/api.groq.com/],['openrouter',/openrouter.ai/],['mistral',/api.mistral.ai/]]) {
    const actual = await requestStructuredAi({ ai:{provider,apiKey:'test-key'},prompt,fetchFn:fetchMock(url,'Authorization',{choices:[{message:{content:JSON.stringify(asResult)}}]}) });
    assert.deepEqual(actual,asResult);
  }
  const claude = await requestStructuredAi({ai:{provider:'anthropic',apiKey:'test-key'},prompt,fetchFn:fetchMock(/api.anthropic.com/,'x-api-key',{content:[{type:'text',text:JSON.stringify(asResult)}]})});
  assert.deepEqual(claude,asResult);
  assert.ok(Array.isArray(configuredAiProviders()));
});
test('No admite URL arbitraria del navegador', async()=>{
  await assert.rejects(()=>requestStructuredAi({ai:{provider:'unknown',apiKey:'secret'},prompt}),/no admitido/);
  await assert.rejects(()=>requestStructuredAi({ai:{provider:'custom',apiKey:'secret',baseUrl:'http://127.0.0.1:1/private'},prompt}),/AI_CUSTOM_BASE_URL/);
});
const q={prompt:'¿Qué corresponde a la función del dinero como medio de pago?',correctOptionId:'b',relatedConcept:'Dinero',options:[{id:'a',text:'Solo una moneda de metal'},{id:'b',text:'Una forma de intercambio aceptada habitualmente por la comunidad'},{id:'c',text:'Una cartera'},{id:'d',text:'Un objeto de lujo'}]};
test('Balancea únicamente los distractores por longitud y conserva IDs',async()=>{
  let answer = {options:[{id:'a',text:'Un objeto de metal raro que solo sirve para decoración ornamental'},{id:'b',text:'Esta respuesta no se respeta'},{id:'c',text:'Un objeto pequeño decorativo que funciona siempre como dinero'},{id:'d',text:'Un artículo costoso que solo se compra para adornar la casa'}]};
  const opts=validateBalancedOptions(validateBalanceQuestion({question:q}),answer);
  assert.equal(opts?.find(o=>o.id==='b').text,q.options[1].text);
  assert.equal(opts?.length,4);
  const fetched=await balanceQuestion({question:q,ai:{provider:'openai',apiKey:'x'}},{fetchFn:fetchMock(/api.openai.com/,'Authorization',{choices:[{message:{content:JSON.stringify(answer)}}]})});
  assert.deepEqual(fetched.options,opts);
});
test('Descarta un balance incorrecto sin alterar la pregunta original',()=>{
  const original=JSON.stringify(q);
  assert.equal(validateBalancedOptions(q,{options:[{id:'a',text:'Uno'},{id:'b',text:'Dos'},{id:'c',text:'Tres'},{id:'d',text:'Cuatro'}]}),null);
  assert.equal(JSON.stringify(q),original);
});
