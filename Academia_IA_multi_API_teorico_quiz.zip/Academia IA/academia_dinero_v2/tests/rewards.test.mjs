import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getWallet, syncWallet, buyHint, revealHint, hasUsedHint,
  buyPodcast, hasPodcast, importWallet, deleteWallet,
  HINT_PRICE, PODCAST_PRICE,
} from '../src/rewards.js';
import { shuffleOptions, gradeQuestion, createInitialProgress, applySkipLessonResult, createSkipLessonExam } from '../src/courseEngine.js';
import { createDemoCourseDefinition } from '../src/demoCourse.js';

const values = new Map();
globalThis.localStorage = {
  getItem: k => values.get(k) ?? null,
  setItem: (k, v) => values.set(k, String(v)),
  removeItem: k => values.delete(k),
};

test('shuffle conserva el ID correcto y puede aparecer en cualquiera de las cuatro posiciones', () => {
  const original = { id: 'q', correctOptionId: 'a', options: ['a', 'b', 'c', 'd'].map(id => ({id, text:id})) };
  const seen = new Set();
  for (let i = 0; i < 120; i++) {
    const q = shuffleOptions(original);
    seen.add(q.options.findIndex(o => o.id === q.correctOptionId));
    assert.equal(gradeQuestion(q, 'a').correct, true);
    assert.deepEqual(original.options.map(o => o.id), ['a','b','c','d']);
  }
  assert.equal(seen.size, 4);
});

test('tres pistas de regalo para TODO el perfil, una sola vez por pregunta', () => {
  deleteWallet(10);
  assert.equal(getWallet(10).hints, 3);
  for (let i=0; i<3; i++) assert.equal(revealHint(10, `curso:q${i}`).ok, true);
  assert.equal(getWallet(10).hints, 0);
  assert.equal(revealHint(10, 'curso:q3').ok, false);
  assert.equal(revealHint(10, 'curso:q1').newUse, false);
  assert.equal(hasUsedHint(10, 'curso:q1'), true);
  assert.equal(getWallet(11).hints, 3);
});

test('puntos acreditados según XP nuevo; compras sin alterar progreso', () => {
  deleteWallet(12);
  syncWallet(12, 500); syncWallet(12, 500);
  assert.equal(getWallet(12).balance, 500);
  assert.equal(buyHint(12).ok, true);
  assert.equal(getWallet(12).balance, 500-HINT_PRICE);
  assert.equal(getWallet(12).hints, 4);
  assert.equal(buyPodcast(12, 'demo-study-skills:lesson').ok, true);
  assert.equal(getWallet(12).balance, 500-HINT_PRICE-PODCAST_PRICE);
  assert.equal(hasPodcast(12, 'demo-study-skills:lesson'), true);
  assert.equal(buyPodcast(12, 'demo-study-skills:lesson').alreadyOwned, true);
  assert.equal(getWallet(12).balance, 500-HINT_PRICE-PODCAST_PRICE);
  syncWallet(12, 540);
  assert.equal(getWallet(12).balance, 540-HINT_PRICE-PODCAST_PRICE);
  assert.equal(getWallet(12).trackedXP, 540);
});

test('compra rechazada sin fondos, persistencia en export/import', () => {
  deleteWallet(13);
  assert.equal(buyHint(13).ok, false);
  assert.equal(buyPodcast(13, 'a').ok, false);
  importWallet(13, getWallet(12));
  assert.deepEqual(getWallet(13), getWallet(12));
});

test('examen de salto de lección no vuelve a generar XP en reintentos', () => {
  const course = createDemoCourseDefinition();
  const exam = createSkipLessonExam(course, 'demo-l1', 1);
  assert.ok(exam);
  const answers = Object.fromEntries(exam.questions.map(q => [q.id, q.correctOptionId]));
  const progress = createInitialProgress(1, 1, 1, course);
  const first = applySkipLessonResult(progress, course, 'demo-l1', 1, exam, answers);
  const second = applySkipLessonResult(first.progress, course, 'demo-l1', 1, exam, answers);
  assert.equal(first.result.passed, true);
  assert.ok(first.xpGained > 0);
  assert.equal(second.xpGained, 0);
});
