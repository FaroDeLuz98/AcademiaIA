import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createDemoCourseDefinition } from '../src/demoCourse.js';
import {
  createInitialProgress, applyExamResult, completeAiReview,
  getPendingAiReview, saveAiReviewConversation, isAiReviewCheckpoint,
} from '../src/courseEngine.js';
import { validateReviewRequest, buildReviewPrompt, queryGeminiReview } from '../geminiReviewServer.js';

const course = createDemoCourseDefinition();
const level = course.levels[2];
function answersWithErrors(errors = 2) {
  return Object.fromEntries(level.exam.questions.map((q, i) => [q.id, i < errors ? q.options.find(o => o.id !== q.correctOptionId).id : q.correctOptionId]));
}
function initial() {
  return createInitialProgress(1, 2, 3, course);
}

describe('Repaso IA por errores', () => {
  it('solo se exige en ciertos finales y si hubo errores', () => {
    assert.equal(isAiReviewCheckpoint(course.levels[0]), false);
    assert.equal(isAiReviewCheckpoint(level), true);
    assert.equal(isAiReviewCheckpoint({ id: 'custom', exam: { aiReview: true } }), true);
    assert.equal(isAiReviewCheckpoint({ id: 'demo-l3', exam: { aiReview: false } }), false);
    const { progress: perfect, needsAiReview } = applyExamResult(initial(), course, level, level.exam, answersWithErrors(0));
    assert.equal(needsAiReview, false);
    assert.ok(perfect.passedLevelIds.includes(level.id));
  });
  it('retiene desbloqueo aunque aprueba escrito con errores, hasta dominarlo', () => {
    const { progress, needsAiReview, result } = applyExamResult(initial(), course, level, level.exam, answersWithErrors(2));
    assert.equal(result.passed, true);
    assert.equal(needsAiReview, true);
    assert.equal(progress.passedLevelIds.includes(level.id), false);
    assert.equal(getPendingAiReview(progress, level.id).topics.length, 2);
    const conversation = saveAiReviewConversation(progress, level.id, [
      { role: 'model', text: '¿Cómo lo explicarías?' },
      { role: 'user', text: 'Yo explicaría que este concepto funciona por esto y por aquello.' },
    ]);
    assert.equal(conversation.aiReviews[level.id].messages.length, 2);
    assert.equal(progress.aiReviews[level.id].messages.length, 0);
    assert.throws(() => completeAiReview(conversation, course, level.id, { mastered: false }), /aún no/);
    const done = completeAiReview(conversation, course, level.id, { mastered: true, reply: 'Lo explicaste bien.' });
    assert.equal(done.progress.aiReviews[level.id].status, 'complete');
    assert.ok(done.progress.passedLevelIds.includes(level.id));
    assert.equal(getPendingAiReview(done.progress, level.id), null);
    assert.throws(() => completeAiReview(done.progress, course, level.id, { mastered: true }), /pendiente/);
  });
  it('un examen reprobado permite repasar, pero no lo marca aprobado', () => {
    const { progress, result } = applyExamResult(initial(), course, level, level.exam, answersWithErrors(10));
    assert.equal(result.passed, false);
    assert.ok(getPendingAiReview(progress, level.id));
    const done = completeAiReview(progress, course, level.id, { mastered: true });
    assert.equal(done.progress.passedLevelIds.includes(level.id), false);
  });
  it('no penaliza puntos ni XP al repasar', () => {
    const { progress } = applyExamResult(initial(), course, level, level.exam, answersWithErrors(1));
    const { progress: done } = completeAiReview(progress, course, level.id, { mastered: true });
    assert.equal(progress.xp, done.xp);
  });
});

describe('API Gemini (sin llamadas externas)', () => {
  const topics = [{ prompt: '¿Qué es el dinero?', relatedConcept: 'Definición', correctText: 'Medio de pago', selectedText: 'Solo billetes' }];
  it('exige una explicación escrita para activar la evaluación', () => {
    assert.throws(() => validateReviewRequest({ mode: 'check', topics, messages: [{ role: 'user', text: 'ya entendí' }] }), /explicá el concepto/);
    const input = { mode: 'check', topics, messages: [{ role: 'user', text: 'Yo creo que el dinero es un medio de pago aceptado por la sociedad y no solo billetes.' }] };
    const parsed = validateReviewRequest(input);
    assert.equal(parsed.mode, 'check');
    assert.match(buildReviewPrompt(parsed).systemInstruction.parts[0].text, /no prueban aprendizaje/);
    assert.throws(() => validateReviewRequest({ mode: 'chat', topics, messages: [{ role: 'model', text: 'hola' }] }), /escribí/);
  });
  it('procesa JSON de Gemini y solo aprueba en la acción verificar', async () => {
    const fakeFetch = async (_url, opts) => {
      assert.equal(opts.headers['x-goog-api-key'], 'test-secret');
      return { ok: true, json: async () => ({ candidates: [{ content: { parts: [{ text: JSON.stringify({ reply: 'Muy bien razonado', mastered: true }) }] } }] }) };
    };
    const req = { topics, messages: [{ role: 'user', text: 'Una explicación con todas las palabras necesarias sobre el dinero como medio de pago.' }] };
    const chat = await queryGeminiReview({ ...req, mode: 'chat' }, { apiKey: 'test-secret', fetchFn: fakeFetch });
    assert.equal(chat.mastered, false);
    const check = await queryGeminiReview({ ...req, mode: 'check' }, { apiKey: 'test-secret', fetchFn: fakeFetch });
    assert.equal(check.mastered, true);
  });
  it('informa cuando no hay clave de Gemini', async () => {
    await assert.rejects(() => queryGeminiReview({ mode: 'start', topics, messages: [] }, { apiKey: '' }), /no está configurado/);
  });
});
