// Proveedores autorizados: ningún cliente puede indicar una URL arbitraria.
const PROVIDERS = Object.freeze({
  gemini: { env: 'GEMINI_API_KEY', modelEnv: 'GEMINI_MODEL', model: 'gemini-2.5-flash' },
  openai: { env: 'OPENAI_API_KEY', modelEnv: 'OPENAI_MODEL', model: 'gpt-4.1-mini', base: 'https://api.openai.com/v1/chat/completions' },
  anthropic: { env: 'ANTHROPIC_API_KEY', modelEnv: 'ANTHROPIC_MODEL', model: 'claude-sonnet-4-5' },
  deepseek: { env: 'DEEPSEEK_API_KEY', modelEnv: 'DEEPSEEK_MODEL', model: 'deepseek-chat', base: 'https://api.deepseek.com/chat/completions' },
  groq: { env: 'GROQ_API_KEY', modelEnv: 'GROQ_MODEL', model: 'llama-3.3-70b-versatile', base: 'https://api.groq.com/openai/v1/chat/completions' },
  openrouter: { env: 'OPENROUTER_API_KEY', modelEnv: 'OPENROUTER_MODEL', model: 'openai/gpt-4.1-mini', base: 'https://openrouter.ai/api/v1/chat/completions' },
  mistral: { env: 'MISTRAL_API_KEY', modelEnv: 'MISTRAL_MODEL', model: 'mistral-small-latest', base: 'https://api.mistral.ai/v1/chat/completions' },
  custom: { env: 'AI_CUSTOM_API_KEY', modelEnv: 'AI_CUSTOM_MODEL', model: 'modelo-personalizado' },
});
export function configuredAiProviders() { return Object.entries(PROVIDERS).filter(([_, v]) => Boolean(process.env[v.env])).map(([k]) => k); }
function error(message, status = 400) { const err = new Error(message); err.status = status; return err; }
function providerSettings(ai = {}, overrideKey) {
  const provider = String(ai?.provider || 'gemini');
  const info = PROVIDERS[provider];
  if (!info) throw error('Proveedor de IA no admitido.');
  const model = String(ai?.model || process.env[info.modelEnv] || info.model).trim();
  if (!/^[a-zA-Z0-9_.:\/-]{1,100}$/.test(model)) throw error('Identificador de modelo inválido.');
  const apiKey = String(overrideKey ?? ai?.apiKey ?? process.env[info.env] ?? '').trim();
  if (apiKey.length > 2048) throw error('La clave API es demasiado larga.');
  let base = info.base;
  if (provider === 'custom') {
    base = process.env.AI_CUSTOM_BASE_URL;
    if (!base) throw error('El administrador debe indicar AI_CUSTOM_BASE_URL en gemini_config.local.', 503);
    let url;
    try { url = new URL(base); } catch { throw error('AI_CUSTOM_BASE_URL inválida.', 503); }
    // La URL solo es editable por el administrador del servidor, nunca por el visitante.
    if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname))) throw error('La API personalizada debe usar HTTPS (o HTTP local).', 503);
    if (url.username || url.password || !url.pathname.includes('/chat/completions')) throw error('URL personalizada inválida: se espera una ruta /chat/completions.', 503);
    base = url.toString();
  }
  const localCustom = provider === 'custom' && ['127.0.0.1', 'localhost', '[::1]'].includes(new URL(base).hostname);
  if (!apiKey && !localCustom) throw error(provider === 'gemini' ? 'Gemini no está configurado. Agregá tu clave en ⚙️ IA o en el servidor.' : `No hay clave API para ${provider}. Configurala en ⚙️ IA o en el servidor.`, 503);
  return { provider, model, apiKey, base };
}

export async function requestStructuredAi({ ai = {}, prompt, overrideKey, fetchFn = fetch }) {
  const { provider, model, apiKey, base } = providerSettings(ai, overrideKey);
  let endpoint, headers, request;
  if (provider === 'gemini') {
    endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    headers = { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey };
    request = { systemInstruction: { parts: [{ text: prompt.system }] }, contents: [{ role: 'user', parts: [{ text: prompt.user }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.25, maxOutputTokens: 1500 } };
  } else if (provider === 'anthropic') {
    endpoint = 'https://api.anthropic.com/v1/messages';
    headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' };
    request = { model, max_tokens: 1500, system: prompt.system, messages: [{ role: 'user', content: `${prompt.user}\nRespondé solo JSON válido.` }] };
  } else {
    endpoint = base;
    headers = { 'Content-Type': 'application/json', ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}) };
    request = { model, temperature: 0.25, max_tokens: 1500, messages: [{ role: 'system', content: `${prompt.system}\nRespondé solamente JSON válido.` }, { role: 'user', content: prompt.user }] };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 35000);
  let response;
  try { response = await fetchFn(endpoint, { method: 'POST', headers, body: JSON.stringify(request), signal: controller.signal }); }
  catch (err) { throw error(err.name === 'AbortError' ? 'La IA tardó demasiado en responder.' : 'No se pudo contactar con el proveedor de IA.', 502); }
  finally { clearTimeout(timeout); }
  if (!response.ok) {
    const message = response.status === 401 || response.status === 403 ? 'Clave API incorrecta o sin permisos.' : response.status === 429 ? 'Límite de consultas alcanzado para este proveedor.' : response.status === 404 ? 'Modelo o ruta de API no encontrado. Revisá el identificador.' : 'El proveedor rechazó la consulta. Verificá modelo, saldo y clave.';
    throw error(message, 502);
  }
  let data;
  try { data = await response.json(); } catch { throw error('El proveedor devolvió JSON inválido.', 502); }
  const output = provider === 'gemini' ? data.candidates?.[0]?.content?.parts?.filter(p => !p.thought).map(p => p.text || '').join('') : provider === 'anthropic' ? data.content?.filter(c => c.type === 'text').map(c => c.text).join('') : data.choices?.[0]?.message?.content;
  if (typeof output !== 'string') throw error('El proveedor no devolvió texto utilizable.', 502);
  try { return JSON.parse(output.trim().replace(/^```(?:json)?\s*|\s*```$/g, '')); }
  catch { throw error('La IA no devolvió JSON válido. Probá de nuevo o cambiá de modelo.', 502); }
}
