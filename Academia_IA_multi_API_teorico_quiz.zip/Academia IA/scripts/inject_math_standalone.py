# -*- coding: utf-8 -*-
"""
Inyecta el renderizador de fórmulas (src/math.js) y sus estilos en
'Academia del Dinero.html' (versión de un solo archivo).
Es idempotente: se puede ejecutar varias veces sin duplicar nada.
Uso (desde la carpeta 'Academia IA'):  python scripts/inject_math_standalone.py
"""
import re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
js = (root / "academia_dinero_v2" / "src" / "math.js").read_text(encoding="utf-8")

# math.js es un módulo ES: se convierte en un script clásico autocontenido.
js = re.sub(r"^export\s+", "", js, flags=re.M)
js = js.replace('if (typeof document !== "undefined" && typeof window !== "undefined") {',
                'if (typeof document !== "undefined" && typeof window !== "undefined") {', 1)

CSS = """
/* === Fórmulas (math.js) === */
.math{font-family:"STIX Two Text","Cambria Math","Latin Modern Math","Times New Roman",serif;font-size:1.08em;line-height:1}
.math i{font-style:italic}
.math sub,.math sup{font-size:.72em;line-height:0;position:relative;vertical-align:baseline}
.math sub{top:.32em}.math sup{top:-.42em}
.math .ss{display:inline-flex;flex-direction:column;vertical-align:middle;line-height:1}
.math .ss sup,.math .ss sub{top:0;line-height:1.05}
.math .mr{font-style:normal;font-family:inherit;font-size:.92em}
.math .frac{display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center;font-size:.92em;margin:0 .12em}
.math .frac .num{border-bottom:1.2px solid currentColor;padding:0 .25em .06em}
.math .frac .den{padding:.06em .25em 0}
/* === /Fórmulas === */
"""

targets = [root / "Academia del Dinero.html"]
for path in targets:
    if not path.exists():
        print("No existe:", path); continue
    raw = path.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    html = raw.replace("\r\n", "\n")
    # limpiar inyecciones previas
    html = re.sub(r"\n?/\* === Fórmulas \(math\.js\) === \*/.*?/\* === /Fórmulas === \*/\n?", "\n", html, flags=re.S)
    html = re.sub(r"\n?<script id=\"math-js\">.*?</script>\n?", "\n", html, flags=re.S)
    assert "</style>" in html and "</body>" in html, "estructura inesperada"
    html = html.replace("</style>", CSS + "</style>", 1)
    block = '<script id="math-js">\n(function(){\n' + js + '\n})();\n</script>\n'
    html = html.replace("</body>", block + "</body>", 1)
    if crlf: html = html.replace("\n", "\r\n")
    path.write_bytes(html.encode("utf-8"))
    print("OK:", path.name, "(", len(html), "caracteres )")
