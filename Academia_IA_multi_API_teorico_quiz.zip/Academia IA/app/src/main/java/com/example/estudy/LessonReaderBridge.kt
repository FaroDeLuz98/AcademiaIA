package com.example.estudy

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.lang.ref.WeakReference
import java.util.Locale

/** Reproducción de lecciones dentro de Android WebView sin conexión a servicios externos. */
class LessonReaderBridge(context: Context) : TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var webView: WeakReference<WebView>? = null
    private var ready = false
    private var active = false
    private var paused = false
    private var chunks: List<String> = emptyList()
    private var nextIndex = 0

    init { tts = TextToSpeech(context.applicationContext, this) }

    fun attach(view: WebView) { webView = WeakReference(view) }

    override fun onInit(status: Int) {
        handler.post {
            if (status != TextToSpeech.SUCCESS) return@post
            ready = true
            val voice = tts ?: return@post
            val uruguay = voice.setLanguage(Locale("es", "UY"))
            if (uruguay == TextToSpeech.LANG_NOT_SUPPORTED || uruguay == TextToSpeech.LANG_MISSING_DATA) {
                voice.setLanguage(Locale("es", "ES"))
            }
            voice.setSpeechRate(0.92f)
            voice.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    handler.post { speakNext() }
                }
                @Deprecated("Deprecated in API")
                override fun onError(utteranceId: String?) {
                    handler.post { finishAudio() }
                }
            })
            if (active && !paused) speakNext()
        }
    }

    @JavascriptInterface
    fun speak(text: String) {
        handler.post {
            tts?.stop()
            chunks = text.trim().split(Regex("(?<=\\s)|(?<=\\.)"))
                .fold(mutableListOf<String>()) { acc, part ->
                    if (part.isNotBlank()) {
                        if (acc.isNotEmpty() && acc.last().length + part.length < 1800) {
                            acc[acc.lastIndex] += part
                        } else {
                            acc.add(part)
                        }
                    }
                    acc
                }
            nextIndex = 0
            paused = false
            active = chunks.isNotEmpty()
            if (ready && active) speakNext()
        }
    }

    private fun speakNext() {
        if (!ready || !active || paused) return
        if (nextIndex >= chunks.size) { finishAudio(); return }
        val chunk = chunks[nextIndex++]
        tts?.speak(chunk, TextToSpeech.QUEUE_FLUSH, null, "academy-${nextIndex}")
    }

    @JavascriptInterface
    fun pause() {
        handler.post {
            if (!active || paused) return@post
            paused = true
            tts?.stop()
            nextIndex = (nextIndex - 1).coerceAtLeast(0)
        }
    }

    @JavascriptInterface
    fun resume() {
        handler.post {
            if (!active || !paused) return@post
            paused = false
            speakNext()
        }
    }

    @JavascriptInterface
    fun stop() { handler.post { reset() } }

    private fun finishAudio() {
        reset()
        webView?.get()?.evaluateJavascript("window.__academyLessonAudioEnded && window.__academyLessonAudioEnded()", null)
    }

    private fun reset() {
        active = false
        paused = false
        nextIndex = 0
        chunks = emptyList()
        tts?.stop()
    }

    fun shutdown() {
        handler.post { reset(); tts?.shutdown(); tts = null }
    }
}
