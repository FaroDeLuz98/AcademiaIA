package com.example.estudy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.example.estudy.ui.theme.EstudyTheme

class MainActivity : ComponentActivity() {
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var lessonReaderBridge: LessonReaderBridge? = null

    fun attachLessonReader(reader: LessonReaderBridge) { lessonReaderBridge = reader }

    override fun onDestroy() {
        lessonReaderBridge?.shutdown()
        super.onDestroy()
    }
    private var fileChooserLauncher: ManagedActivityResultLauncher<Intent, androidx.activity.result.ActivityResult>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EstudyTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AcademiaWebView(
                        modifier = Modifier.padding(innerPadding),
                        onInitLauncher = { launcher ->
                            fileChooserLauncher = launcher
                        },
                        onGetFileCallback = { callback ->
                            filePathCallback = callback
                        }
                    )
                }
            }
        }
    }

    fun handleFileChooserResult(resultCode: Int, data: Intent?) {
        if (filePathCallback == null) return
        val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
        filePathCallback?.onReceiveValue(results)
        filePathCallback = null
    }
}

@Composable
fun AcademiaWebView(
    modifier: Modifier = Modifier,
    onInitLauncher: (ManagedActivityResultLauncher<Intent, androidx.activity.result.ActivityResult>) -> Unit,
    onGetFileCallback: (ValueCallback<Array<Uri>>?) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? MainActivity

    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        activity?.handleFileChooserResult(result.resultCode, result.data)
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        onInitLauncher(fileChooserLauncher)
    }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    androidx.activity.compose.BackHandler(enabled = true) {
        val wv = webViewRef
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            (context as? Activity)?.finish()
        }
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                webViewRef = this

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    allowFileAccess = true
                    allowContentAccess = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    setSupportZoom(true)
                    builtInZoomControls = false
                    displayZoomControls = false
                }

                val lessonReader = LessonReaderBridge(ctx)
                lessonReader.attach(this)
                activity?.attachLessonReader(lessonReader)
                addJavascriptInterface(lessonReader, "AndroidLessonReader")

                val assetLoader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                    .build()

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: WebResourceRequest
                    ): WebResourceResponse? {
                        return assetLoader.shouldInterceptRequest(request.url)
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        super.onReceivedError(view, request, error)
                        if (request?.isForMainFrame == true) {
                            Toast.makeText(ctx, "Error cargando Academia IA: ${error?.description}", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>?,
                        fileChooserParams: FileChooserParams?
                    ): Boolean {
                        onGetFileCallback(filePathCallback)
                        val intent = fileChooserParams?.createIntent()
                        try {
                            if (intent != null) {
                                fileChooserLauncher.launch(intent)
                                return true
                            }
                        } catch (e: Exception) {
                            onGetFileCallback(null)
                            filePathCallback?.onReceiveValue(null)
                        }
                        return false
                    }
                }

                loadUrl("https://appassets.androidplatform.net/assets/index.html")
            }
        }
    )
}
