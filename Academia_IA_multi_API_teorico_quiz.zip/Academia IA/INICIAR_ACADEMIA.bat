@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Academia IA - Puntos y pistas

echo =======================================================
echo                   ACADEMIA IA
 echo =======================================================
echo.
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Para abrir la version actualizada necesitas Node.js.
    echo Instalalo desde https://nodejs.org/ y ejecuta nuevamente este archivo.
    echo La pagina HTML antigua no incluye las mejoras de puntos y podcasts.
    pause
    exit /b 1
)
cd /d "%~dp0academia_dinero_v2"
node server.js
if errorlevel 1 (
    echo.
    echo [ERROR] No se pudo iniciar Academia IA.
    pause
)
endlocal
