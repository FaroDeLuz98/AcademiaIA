# Academia IA — actualización de cuestionarios, puntos y audio

## Cambios principales

- **Preguntas:** las respuestas se mezclan para cada pregunta mediante Fisher–Yates. Cada posición es estable al volver a esa pregunta durante el mismo intento. La corrección usa el ID de la respuesta y nunca depende de la posición A/B/C/D.
- **Explicaciones:** después de contestar el quiz se muestran concepto, razonamiento, opción correcta y un ejemplo de la teoría (cuando existe); al finalizar un examen, cada pregunta tiene su explicación.
- **Tres pistas iniciales por perfil**, compartidas por todas las materias y los exámenes. No se restablecen al reintentar, cambiar de lección ni reiniciar la app. Una pista ya revelada puede volver a consultarse sin gastar otra.
- **Tienda:** podés comprar una pista adicional por **120 puntos**; una lectura en audio de una lección específica por **200 puntos**. No se venden con dinero real.
- **XP y puntos:** cada XP nuevo acredita un punto. Los XP de progreso no bajan al gastar puntos. Repetir la misma pregunta no genera XP extra. Las compras y desbloqueos se guardan localmente por perfil.
- **Podcast / Leer / Escuchar:** al comprar el audio de una lección aparece el botón «Leer / Escuchar», con Pausar y Detener. La narración se produce con la voz del dispositivo, sin generar archivos de audio ni conexión a servicios de IA. En Android la app integra TextToSpeech como alternativa para WebView. La calidad y disponibilidad de voces depende del dispositivo.
- **Exportación:** los datos del monedero, pistas y audios se incluyen al exportar el perfil para hacer una copia de seguridad.
- **Extra:** se conectó el examen para saltear una lección y se evita ganar XP repetidamente con exámenes de salto ya recompensados.

## Dónde abrir

- **Windows:** `academia_dinero_v2/INICIAR_ACADEMIA.bat`, o `INICIAR_ACADEMIA.bat` en la carpeta principal. Requiere Node.js.
- **Otros sistemas:** en `academia_dinero_v2` ejecutá `node server.js` y abrí `http://localhost:8000`.
- **Android:** el código actualizado se encuentra en `app/src/main/assets/` y la narración nativa en `app/src/main/java/com/example/estudy/`. Se necesita compilar el proyecto Android para obtener un APK actualizado.

## Pruebas realizadas

`node --test tests/rewards.test.mjs tests/math.test.mjs` (10 pruebas superadas). Los test de integración de navegador y Android no pudieron ejecutarse en este entorno: la ejecución de Chromium fue bloqueada y no hay un SDK de Android configurado.

## Nota sobre la versión independiente

`estudiar - copia/Academia del Dinero.html` es una página antigua separada. Las mejoras de este documento se aplican a la app principal `academia_dinero_v2` y los assets de Android, no a esa página antigua.

## Actualización: repaso final con Gemini

- En los exámenes finales seleccionados (niveles 3/6/9 del curso de dinero y nivel 3 del demo), los errores abren una **charla personalizada** sobre lo que faltó comprender.
- Gemini pregunta, contesta dudas y evalúa el razonamiento cuando el alumno pulsa **«Ya entendí · evaluame»**; el botón no aprueba automáticamente.
- Si el escrito estaba aprobado, para completar el nivel se requiere demostrar comprensión. Si estaba reprobado, el repaso no sustituye un nuevo intento de examen.
- El historial de repaso y su estado se guardan dentro del progreso por curso/perfil; no gastan puntos, pistas ni XP.
- La API key vive solo en el servidor Node.js mediante `gemini_config.local`, fuera de los archivos públicos. No se incluye ninguna clave real.
- **En Kali Linux:** ejecutá `INICIAR_ACADEMIA_KALI.sh` en la carpeta principal. Más instrucciones en `ACTIVAR_GEMINI_KALI.md`.
- El chat de Gemini requiere un backend Node.js; los assets Android se actualizan visualmente, pero la aplicación instalada necesita acceso a un backend compatible para que el chat funcione.

## Actualización: configuración multi-IA, distractores y repaso del teórico

- Nuevo botón **⚙️ IA** para elegir Gemini, OpenAI, Claude, DeepSeek, Groq, OpenRouter, Mistral u otro proveedor OpenAI-compatible configurado por el dueño del servidor.
- Podés introducir una clave API solo para la sesión actual sin guardarla en el navegador, o definir claves en el archivo privado `gemini_config.local` de Kali/Windows.
- Opción *Equilibrar automáticamente las respuestas*, activable desde ⚙️ IA: pide a la IA distractores con extensiones similares a la opción verdadera, conserva esta última y sus IDs, valida el formato y reutiliza el resultado en el navegador. Depende de la disponibilidad del proveedor y podría consumir cuota.
- Los quizzes ahora tienen **📖 Consultar teórico** integrado, sin perder la pregunta ni reiniciar el quiz.
- Durante exámenes finales y de suficiencia se ocultan resúmenes y teoría y se bloquea el salto a lecciones desde el examen.
- Documentación detallada en `CONFIGURAR_IA_Y_QUIZZES.md`.
