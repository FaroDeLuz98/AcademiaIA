#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/academia_dinero_v2"
if ! command -v node >/dev/null; then
  echo "Necesitás Node.js para iniciar Academia IA (sudo apt install nodejs)"
  exit 1
fi
node server.js
