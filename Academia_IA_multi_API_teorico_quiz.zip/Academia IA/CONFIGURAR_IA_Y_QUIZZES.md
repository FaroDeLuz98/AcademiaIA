# Academia IA — proveedores de IA, distractores y consulta del teórico

## Abrir desde Kali Linux
1. Descomprimí el ZIP y entrá a la carpeta `Academia IA`.
2. Ejecutá `./INICIAR_ACADEMIA_KALI.sh` (si hace falta, `chmod +x INICIAR_ACADEMIA_KALI.sh`).
3. Abrí `http://localhost:8000` (o el puerto mostrado en la terminal).
4. Hacé clic arriba en **⚙️ IA** para configurar el proveedor.

## Elegir IA y clave desde la interfaz
La nueva pantalla **⚙️ Configuración de IA** permite elegir **Gemini, OpenAI, Anthropic Claude, DeepSeek, Groq, OpenRouter y Mistral**. También incluye **Otro (OpenAI compatible)** para servicios con endpoint propio.

- Elegí proveedor y modelo. Los modelos son sugerencias y pueden cambiar según el proveedor y tu acceso.
- Si tenés una clave propia, pegala en **Clave API** y guardá. **No se guarda en localStorage, no forma parte de la exportación, ni se incluye en el ZIP**. Se conserva solo en memoria mientras la página siga abierta. Al recargarla se borra.
- Si ya configuraste una clave en el servidor, podés dejar el campo vacío.
- **Olvidar clave** limpia el valor guardado temporalmente en memoria.
- Las consultas de tutoría y de equilibrado de respuestas pueden consumir cuota o generar cargos del proveedor elegido.
- **Si compartís un túnel público**, el usuario con el enlace podrá enviar consultas usando las claves que configures en el servidor, sujetas al límite de solicitudes del proyecto. Compartí el enlace únicamente con personas de confianza. Considerá una clave con límites de gasto y revocala cuando termines las pruebas.
- Si configurás una clave desde un navegador remoto, usá únicamente un enlace **HTTPS**; no la escribas en una página de origen desconocido.

## Alternativa: claves privadas en el servidor
Desde Kali, en la carpeta principal:
```bash
cp gemini_config.ejemplo gemini_config.local
nano gemini_config.local
```
Completá solamente las variables que necesites (por ejemplo `GEMINI_API_KEY` o `OPENAI_API_KEY`). Las demás pueden quedar vacías. Guardá y reiniciá el servidor. El archivo está fuera del directorio público del sitio y excluido del repositorio mediante `.gitignore`.

Para otra IA compatible con la API de Chat Completions, configurá el endpoint del servidor en `AI_CUSTOM_BASE_URL` y el modelo en `AI_CUSTOM_MODEL`. La URL completa debe terminar en `/chat/completions` y usar HTTPS, excepto si el proveedor corre en la propia PC mediante `http://127.0.0.1` o `http://localhost`. El navegador **no puede** apuntar arbitrariamente a URLs locales o internas (medida de seguridad). Para Ollama local compatible con OpenAI, podés usar `http://127.0.0.1:11434/v1/chat/completions` y una clave vacía. Seleccioná **Otro (OpenAI compatible)** en ⚙️ IA.

## Distractores de extensión parecida
En **⚙️ IA**, activá **Equilibrar automáticamente las respuestas**. En los próximos quizzes y exámenes la aplicación solicitará al modelo reescribir **solo las opciones incorrectas**, procurando que queden dentro de ~15% de la longitud de la correcta (o diferencia de 8 caracteres cuando es muy breve). La correcta se conserva sin cambios y las evaluaciones siguen usando su ID, no su posición.

- El texto nuevo se guarda localmente por pregunta para no pagar la misma reescritura varias veces; se invalida si cambia el enunciado u opciones.
- Por seguridad, se comprueba que las opciones sigan siendo diferentes, que estén dentro de los límites de extensión y que los identificadores coincidan. **No se puede verificar automáticamente toda la exactitud conceptual de la reescritura**: supervisá los distractores con criterio docente.
- Si la IA no está configurada, falla o devuelve una estructura inválida, se utilizan las opciones originales sin bloquear el examen.
- No es un requisito utilizar IA para resolver quizzes; los estudiantes pueden continuar sin activarla.
- Los bloques visuales mantienen una altura mínima similar, para que la longitud por sí sola dé menos pistas en pantalla.

## Teórico en quiz, pero no en exámenes
Durante una **práctica (quiz guiado)** aparece el botón **📖 Consultar teórico**. Abre la lección debajo de las opciones, sin perder la pregunta, el orden de respuestas ni el progreso. Podés cerrarlo cuando quieras.

En un **examen final o de suficiencia**, ese botón no aparece, los resúmenes no se muestran y las fichas de navegación de la lección quedan desactivadas mientras se rinde el examen final. Después de entregarlo podés volver a estudiar.

## Repaso por errores
Al terminar los exámenes configurados para conversación, el tutor seleccionado te pide explicar los conceptos que fallaste. Podés seguir escribiendo y pulsar **Ya entendí · evaluame**. El botón no aprueba por sí solo: la respuesta del proveedor debe verificar comprensión.

## Limitaciones
- Necesitás Node.js para las llamadas a IA. Abrir el HTML con `file://` no es suficiente.
- Los cambios de interfaz también se copian a la versión de fuentes Android, pero el WebView Android instalado no ejecuta un servidor Node. Para usar IA desde la app Android se necesita conectar esa app a un backend remoto, todavía no implementado en esta versión.
- No se incluyen claves privadas ni gastos prepagos. Las llamadas de prueba se verificaron con respuestas simuladas, no con claves reales de los proveedores.
