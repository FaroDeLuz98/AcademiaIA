# Repaso conversacional Gemini — Academia IA

## ¿Qué se agregó?

Después de algunos exámenes finales aparece el repaso obligatorio con Gemini **si hay errores**. Por defecto: niveles **3, 6 y 9** de Academia del Dinero y nivel **3** del curso demo. Se puede configurar cada examen final poniendo `"aiReview": true` o `false` en su definición.

El alumno ve sus conceptos incorrectos, habla con Gemini, pregunta dudas, explica con sus palabras y pulsa **«Ya entendí · evaluame»**. Gemini analiza las explicaciones. Si todavía no lo domina, hace una pregunta concreta y la conversación continúa. Si el examen escrito estaba aprobado, el nivel se termina de aprobar al verificar el repaso; si estaba reprobado, deberá **volver a rendir el examen** después del repaso. Sin errores, el nivel sigue normalmente.

La conversación se guarda en el progreso del curso y puede retomarse; también se conserva en las copias del perfil. No consume puntos ni pistas. Las respuestas de Gemini no son infalibles: la evaluación es una ayuda educativa y no equivale a una certificación oficial.

## Activar Gemini (en Kali Linux)

1. Conseguí una clave para Gemini API en **https://aistudio.google.com/apikey**. Revisá las condiciones y posibles cuotas o costos de la API.
2. En la carpeta principal `Academia IA` (NO dentro de `academia_dinero_v2`) copiá `gemini_config.ejemplo` como `gemini_config.local`.
3. Editá `gemini_config.local`, reemplazá `PON_TU_CLAVE_DE_GOOGLE_AI_STUDIO_AQUI` por tu clave real y guardá.
4. Abrí una terminal en `Academia IA` y ejecutá:

```bash
chmod +x INICIAR_ACADEMIA_KALI.sh
./INICIAR_ACADEMIA_KALI.sh
```

5. Abrí `http://localhost:8000`, completá un examen final de un nivel con repaso y equivocáte en alguna pregunta para probar el flujo.

**Windows:** el mismo archivo `gemini_config.local` funciona ejecutando `INICIAR_ACADEMIA.bat`.

**Cloudflare Tunnel:** con el servidor activo, en otra terminal ejecutá `cloudflared tunnel --url http://localhost:8000`. La IA responderá desde el servidor con tu clave; no se envía la clave a los visitantes. El proyecto aplica límites de solicitudes, pero un túnel público puede generar consumo de API: no publiques el enlace abiertamente, supervisá las cuotas y restringí el acceso antes de compartirlo ampliamente.

## Seguridad y privacidad

- **Nunca pongas la clave** en los archivos HTML, JavaScript del navegador, Android, repositorios o mensajes compartidos.
- El archivo `gemini_config.local` está fuera del directorio web público. El servidor bloquea acceso HTTP a los archivos de código del servidor y no devuelve la clave.
- Para revisar un examen, la app envía a Gemini los conceptos incorrectos, el enunciado de las preguntas, las respuestas y el historial de conversación relevante. Evitá compartir datos personales o sensibles en el chat.
- La función requiere **internet y un servidor Node.js**. Abrir `index.html` directamente o usar los archivos Android sin un backend compatible no activa Gemini.
- Si la clave falta, el repaso indica que Gemini no está configurado. Si el examen requería el repaso, la finalización del nivel queda pendiente hasta completar la evaluación.

## Si querés elegir otros exámenes

En los JSON de nuevos cursos agregá al examen final `"aiReview": true` (repaso obligatorio cuando hay errores) o `"aiReview": false` (sin repaso). Los niveles 3/6/9 del curso de dinero y el 3 demo tienen el modo activado por defecto para los cursos ya importados.

## Pruebas

- `node --test tests/ai-review.test.mjs` verifica condiciones, persistencia, aprobación pendiente, reprobación y validaciones de la API usando una respuesta simulada.
- No se hicieron llamadas reales a Gemini porque no hay una clave privada configurada para probar contra la API. Para uso real es necesario configurar tu clave y contar con acceso al servicio.
